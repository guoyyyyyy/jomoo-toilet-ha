#pragma once
#include <cstdint>
namespace sq9650 {
struct Session {
 bool active=false, was_busy=false, ready=false; 
 uint32_t start=0,idle=0,sequence=0, busy_at=0, lease=0, poll=0, raw=0, retry=0;
 bool leasing=false;
 constexpr void acquired(uint32_t now){if(!ready){ready=true;idle=now;}}
 constexpr void sent(uint32_t now){was_busy=true;busy_at=now;idle=now;}
 constexpr void completed(uint32_t now,bool busy=false){idle=now;was_busy=busy;}
 constexpr void hold(uint32_t now){request(now);leasing=true;lease=now;}
 constexpr void request(uint32_t now){start=now;ready=false;active=true;idle=now;}
 constexpr void cancel(){active=false;was_busy=false;ready=false;leasing=false;}
 constexpr bool expired(uint32_t now,bool connected,bool pending,bool busy){
  if(!active)return false;
  if(was_busy && uint32_t(now-busy_at)>=120000 && (busy||pending))return true;
  if(!ready)return uint32_t(now-start)>=30000;
  if(!connected)return uint32_t(now-start)>=30000;
  if(pending||busy){if(!was_busy){idle=now;busy_at=now;}was_busy=true;return false;}
  if(was_busy){idle=now;was_busy=false;}
  if(leasing && uint32_t(now-lease)<120000)return false;
  leasing=false;
  return uint32_t(now-idle)>=10000;
 }
};
inline Session session;
}
