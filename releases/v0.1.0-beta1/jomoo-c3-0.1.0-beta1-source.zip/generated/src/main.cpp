// Auto generated code by esphome
// ========== AUTO GENERATED INCLUDE BLOCK BEGIN ===========
#include "esphome.h"
using namespace esphome;
alignas(logger::Logger) static unsigned char logger__logger_logger_id__pstorage[sizeof(logger::Logger)];
static logger::Logger *const logger_logger_id = reinterpret_cast<logger::Logger *>(logger__logger_logger_id__pstorage);
#ifndef __PICOLIBC__
using std::isnan;
#endif
using std::min;
using std::max;
#include <new>
static char esphome_app_name_buf[] = "jomoo-bridge-XXXXXX";
static char esphome_app_friendly_name_buf[] = "JOMOO SQ9650 XXXXXX";
using namespace text_sensor;
using namespace sensor;
using namespace binary_sensor;
using namespace switch_;
using namespace select;
using namespace button;
using namespace text;
alignas(web_server_base::WebServerBase) static unsigned char web_server_base__web_server_base_webserverbase_id__pstorage[sizeof(web_server_base::WebServerBase)];
static web_server_base::WebServerBase *const web_server_base_webserverbase_id = reinterpret_cast<web_server_base::WebServerBase *>(web_server_base__web_server_base_webserverbase_id__pstorage);
alignas(captive_portal::CaptivePortal) static unsigned char captive_portal__captive_portal_captiveportal_id__pstorage[sizeof(captive_portal::CaptivePortal)];
static captive_portal::CaptivePortal *const captive_portal_captiveportal_id = reinterpret_cast<captive_portal::CaptivePortal *>(captive_portal__captive_portal_captiveportal_id__pstorage);
alignas(wifi::WiFiComponent) static unsigned char wifi__wifi_wificomponent_id__pstorage[sizeof(wifi::WiFiComponent)];
static wifi::WiFiComponent *const wifi_wificomponent_id = reinterpret_cast<wifi::WiFiComponent *>(wifi__wifi_wificomponent_id__pstorage);
alignas(mdns::MDNSComponent) static unsigned char mdns__mdns_mdnscomponent_id__pstorage[sizeof(mdns::MDNSComponent)];
static mdns::MDNSComponent *const mdns_mdnscomponent_id = reinterpret_cast<mdns::MDNSComponent *>(mdns__mdns_mdnscomponent_id__pstorage);
alignas(network::NetworkComponent) static unsigned char network__network_networkcomponent_id__pstorage[sizeof(network::NetworkComponent)];
static network::NetworkComponent *const network_networkcomponent_id = reinterpret_cast<network::NetworkComponent *>(network__network_networkcomponent_id__pstorage);
alignas(web_server::WebServerOTAComponent) static unsigned char web_server__web_server_webserverotacomponent_id__pstorage[sizeof(web_server::WebServerOTAComponent)];
static web_server::WebServerOTAComponent *const web_server_webserverotacomponent_id = reinterpret_cast<web_server::WebServerOTAComponent *>(web_server__web_server_webserverotacomponent_id__pstorage);
alignas(preferences::IntervalSyncer) static unsigned char preferences__preferences_intervalsyncer_id__pstorage[sizeof(preferences::IntervalSyncer)];
static preferences::IntervalSyncer *const preferences_intervalsyncer_id = reinterpret_cast<preferences::IntervalSyncer *>(preferences__preferences_intervalsyncer_id__pstorage);
alignas(safe_mode::SafeModeComponent) static unsigned char safe_mode__safe_mode_safemodecomponent_id__pstorage[sizeof(safe_mode::SafeModeComponent)];
static safe_mode::SafeModeComponent *const safe_mode_safemodecomponent_id = reinterpret_cast<safe_mode::SafeModeComponent *>(safe_mode__safe_mode_safemodecomponent_id__pstorage);
alignas(web_server::WebServer) static unsigned char web_server__web_server_webserver_id__pstorage[sizeof(web_server::WebServer)];
static web_server::WebServer *const web_server_webserver_id = reinterpret_cast<web_server::WebServer *>(web_server__web_server_webserver_id__pstorage);
constexpr uint8_t ESPHOME_WEBSERVER_INDEX_HTML[174] PROGMEM = {60, 33, 68, 79, 67, 84, 89, 80, 69, 32, 104, 116, 109, 108, 62, 60, 104, 116, 109, 108, 62, 60, 104, 101, 97, 100, 62, 60, 109, 101, 116, 97, 32, 99, 104, 97, 114, 115, 101, 116, 61, 85, 84, 70, 45, 56, 62, 60, 108, 105, 110, 107, 32, 114, 101, 108, 61, 105, 99, 111, 110, 32, 104, 114, 101, 102, 61, 100, 97, 116, 97, 58, 62, 60, 47, 104, 101, 97, 100, 62, 60, 98, 111, 100, 121, 62, 60, 101, 115, 112, 45, 97, 112, 112, 62, 60, 47, 101, 115, 112, 45, 97, 112, 112, 62, 60, 115, 99, 114, 105, 112, 116, 32, 115, 114, 99, 61, 34, 104, 116, 116, 112, 115, 58, 47, 47, 111, 105, 46, 101, 115, 112, 104, 111, 109, 101, 46, 105, 111, 47, 118, 51, 47, 119, 119, 119, 46, 106, 115, 34, 62, 60, 47, 115, 99, 114, 105, 112, 116, 62, 60, 47, 98, 111, 100, 121, 62, 60, 47, 104, 116, 109, 108, 62};
constexpr size_t ESPHOME_WEBSERVER_INDEX_HTML_SIZE = 174;
alignas(api::APIServer) static unsigned char api__api_apiserver_id__pstorage[sizeof(api::APIServer)];
static api::APIServer *const api_apiserver_id = reinterpret_cast<api::APIServer *>(api__api_apiserver_id__pstorage);
using namespace api;
alignas(StartupTrigger) static unsigned char esphome__startuptrigger_id__pstorage[sizeof(StartupTrigger)];
static StartupTrigger *const startuptrigger_id = reinterpret_cast<StartupTrigger *>(esphome__startuptrigger_id__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id = reinterpret_cast<Automation<> *>(esphome__automation_id__pstorage);
using namespace json;
alignas(esp32_ble_tracker::ESP32BLETracker) static unsigned char esp32_ble_tracker__esp32_ble_tracker_esp32bletracker_id__pstorage[sizeof(esp32_ble_tracker::ESP32BLETracker)];
static esp32_ble_tracker::ESP32BLETracker *const esp32_ble_tracker_esp32bletracker_id = reinterpret_cast<esp32_ble_tracker::ESP32BLETracker *>(esp32_ble_tracker__esp32_ble_tracker_esp32bletracker_id__pstorage);
alignas(ble_client::BLEClient) static unsigned char ble_client__sq9650_client__pstorage[sizeof(ble_client::BLEClient)];
static ble_client::BLEClient *const sq9650_client = reinterpret_cast<ble_client::BLEClient *>(ble_client__sq9650_client__pstorage);
alignas(ble_client::BLEClientConnectTrigger) static unsigned char ble_client__ble_client_bleclientconnecttrigger_id__pstorage[sizeof(ble_client::BLEClientConnectTrigger)];
static ble_client::BLEClientConnectTrigger *const ble_client_bleclientconnecttrigger_id = reinterpret_cast<ble_client::BLEClientConnectTrigger *>(ble_client__ble_client_bleclientconnecttrigger_id__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_2__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_2 = reinterpret_cast<Automation<> *>(esphome__automation_id_2__pstorage);
alignas(script::SingleScript<>) static unsigned char script__query_state__pstorage[sizeof(script::SingleScript<>)];
static script::SingleScript<> *const query_state = reinterpret_cast<script::SingleScript<> *>(script__query_state__pstorage);
alignas(script::SingleScript<>) static unsigned char script__query_version__pstorage[sizeof(script::SingleScript<>)];
static script::SingleScript<> *const query_version = reinterpret_cast<script::SingleScript<> *>(script__query_version__pstorage);
alignas(script::RestartScript<>) static unsigned char script__bootstrap__pstorage[sizeof(script::RestartScript<>)];
static script::RestartScript<> *const bootstrap = reinterpret_cast<script::RestartScript<> *>(script__bootstrap__pstorage);
alignas(script::SingleScript<>) static unsigned char script__reconnect_ble__pstorage[sizeof(script::SingleScript<>)];
static script::SingleScript<> *const reconnect_ble = reinterpret_cast<script::SingleScript<> *>(script__reconnect_ble__pstorage);
alignas(script::SingleScript<>) static unsigned char script__acquire_session__pstorage[sizeof(script::SingleScript<>)];
static script::SingleScript<> *const acquire_session = reinterpret_cast<script::SingleScript<> *>(script__acquire_session__pstorage);
alignas(script::SingleScript<int, int, int>) static unsigned char script__send_command__pstorage[sizeof(script::SingleScript<int, int, int>)];
static script::SingleScript<int, int, int> *const send_command = reinterpret_cast<script::SingleScript<int, int, int> *>(script__send_command__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_4__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_4 = reinterpret_cast<Automation<> *>(esphome__automation_id_4__pstorage);
alignas(StatelessLambdaCondition<>) static unsigned char esphome__lambdacondition_id__pstorage[sizeof(StatelessLambdaCondition<>)];
static StatelessLambdaCondition<> *const lambdacondition_id = reinterpret_cast<StatelessLambdaCondition<> *>(esphome__lambdacondition_id__pstorage);
alignas(IfAction<false>) static unsigned char esphome__ifaction_id__pstorage[sizeof(IfAction<false>)];
static IfAction<false> *const ifaction_id = reinterpret_cast<IfAction<false> *>(esphome__ifaction_id__pstorage);
alignas(ble_client::BLEClientWriteAction<>) static unsigned char ble_client__ble_client_bleclientwriteaction_id__pstorage[sizeof(ble_client::BLEClientWriteAction<>)];
static ble_client::BLEClientWriteAction<> *const ble_client_bleclientwriteaction_id = reinterpret_cast<ble_client::BLEClientWriteAction<> *>(ble_client__ble_client_bleclientwriteaction_id__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_5__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_5 = reinterpret_cast<Automation<> *>(esphome__automation_id_5__pstorage);
alignas(StatelessLambdaCondition<>) static unsigned char esphome__lambdacondition_id_2__pstorage[sizeof(StatelessLambdaCondition<>)];
static StatelessLambdaCondition<> *const lambdacondition_id_2 = reinterpret_cast<StatelessLambdaCondition<> *>(esphome__lambdacondition_id_2__pstorage);
alignas(IfAction<false>) static unsigned char esphome__ifaction_id_2__pstorage[sizeof(IfAction<false>)];
static IfAction<false> *const ifaction_id_2 = reinterpret_cast<IfAction<false> *>(esphome__ifaction_id_2__pstorage);
alignas(ble_client::BLEClientWriteAction<>) static unsigned char ble_client__ble_client_bleclientwriteaction_id_2__pstorage[sizeof(ble_client::BLEClientWriteAction<>)];
static ble_client::BLEClientWriteAction<> *const ble_client_bleclientwriteaction_id_2 = reinterpret_cast<ble_client::BLEClientWriteAction<> *>(ble_client__ble_client_bleclientwriteaction_id_2__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_6__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_6 = reinterpret_cast<Automation<> *>(esphome__automation_id_6__pstorage);
alignas(DelayAction<>) static unsigned char esphome__delayaction_id__pstorage[sizeof(DelayAction<>)];
static DelayAction<> *const delayaction_id = reinterpret_cast<DelayAction<> *>(esphome__delayaction_id__pstorage);
alignas(script::ScriptExecuteAction<script::Script<>>) static unsigned char script__script_scriptexecuteaction_id_2__pstorage[sizeof(script::ScriptExecuteAction<script::Script<>>)];
static script::ScriptExecuteAction<script::Script<>> *const script_scriptexecuteaction_id_2 = reinterpret_cast<script::ScriptExecuteAction<script::Script<>> *>(script__script_scriptexecuteaction_id_2__pstorage);
alignas(script::ScriptWaitAction<script::SingleScript<>>) static unsigned char script__script_scriptwaitaction_id__pstorage[sizeof(script::ScriptWaitAction<script::SingleScript<>>)];
static script::ScriptWaitAction<script::SingleScript<>> *const script_scriptwaitaction_id = reinterpret_cast<script::ScriptWaitAction<script::SingleScript<>> *>(script__script_scriptwaitaction_id__pstorage);
alignas(DelayAction<>) static unsigned char esphome__delayaction_id_2__pstorage[sizeof(DelayAction<>)];
static DelayAction<> *const delayaction_id_2 = reinterpret_cast<DelayAction<> *>(esphome__delayaction_id_2__pstorage);
alignas(script::ScriptExecuteAction<script::Script<>>) static unsigned char script__script_scriptexecuteaction_id_3__pstorage[sizeof(script::ScriptExecuteAction<script::Script<>>)];
static script::ScriptExecuteAction<script::Script<>> *const script_scriptexecuteaction_id_3 = reinterpret_cast<script::ScriptExecuteAction<script::Script<>> *>(script__script_scriptexecuteaction_id_3__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_7__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_7 = reinterpret_cast<Automation<> *>(esphome__automation_id_7__pstorage);
alignas(template_::TemplateTextSensor) static unsigned char template__connection_mode__pstorage[sizeof(template_::TemplateTextSensor)];
static template_::TemplateTextSensor *const connection_mode = reinterpret_cast<template_::TemplateTextSensor *>(template__connection_mode__pstorage);
alignas(wifi_info::IPAddressWiFiInfo) static unsigned char wifi_info__wifi_info_ipaddresswifiinfo_id__pstorage[sizeof(wifi_info::IPAddressWiFiInfo)];
static wifi_info::IPAddressWiFiInfo *const wifi_info_ipaddresswifiinfo_id = reinterpret_cast<wifi_info::IPAddressWiFiInfo *>(wifi_info__wifi_info_ipaddresswifiinfo_id__pstorage);
alignas(version::VersionTextSensor) static unsigned char version__version_versiontextsensor_id__pstorage[sizeof(version::VersionTextSensor)];
static version::VersionTextSensor *const version_versiontextsensor_id = reinterpret_cast<version::VersionTextSensor *>(version__version_versiontextsensor_id__pstorage);
alignas(template_::TemplateTextSensor) static unsigned char template__state_description__pstorage[sizeof(template_::TemplateTextSensor)];
static template_::TemplateTextSensor *const state_description = reinterpret_cast<template_::TemplateTextSensor *>(template__state_description__pstorage);
alignas(template_::TemplateTextSensor) static unsigned char template__command_result__pstorage[sizeof(template_::TemplateTextSensor)];
static template_::TemplateTextSensor *const command_result = reinterpret_cast<template_::TemplateTextSensor *>(template__command_result__pstorage);
alignas(template_::TemplateTextSensor) static unsigned char template__hardware_version__pstorage[sizeof(template_::TemplateTextSensor)];
static template_::TemplateTextSensor *const hardware_version = reinterpret_cast<template_::TemplateTextSensor *>(template__hardware_version__pstorage);
alignas(template_::TemplateTextSensor) static unsigned char template__mcu_version__pstorage[sizeof(template_::TemplateTextSensor)];
static template_::TemplateTextSensor *const mcu_version = reinterpret_cast<template_::TemplateTextSensor *>(template__mcu_version__pstorage);
alignas(template_::TemplateTextSensor) static unsigned char template__raw_status__pstorage[sizeof(template_::TemplateTextSensor)];
static template_::TemplateTextSensor *const raw_status = reinterpret_cast<template_::TemplateTextSensor *>(template__raw_status__pstorage);
alignas(ble_client::BLETextSensor) static unsigned char ble_client__sq9650_raw__pstorage[sizeof(ble_client::BLETextSensor)];
static ble_client::BLETextSensor *const sq9650_raw = reinterpret_cast<ble_client::BLETextSensor *>(ble_client__sq9650_raw__pstorage);
alignas(ble_client::BLETextSensorNotifyTrigger) static unsigned char ble_client__ble_client_bletextsensornotifytrigger_id__pstorage[sizeof(ble_client::BLETextSensorNotifyTrigger)];
static ble_client::BLETextSensorNotifyTrigger *const ble_client_bletextsensornotifytrigger_id = reinterpret_cast<ble_client::BLETextSensorNotifyTrigger *>(ble_client__ble_client_bletextsensornotifytrigger_id__pstorage);
alignas(Automation<std::string>) static unsigned char esphome__automation_id_10__pstorage[sizeof(Automation<std::string>)];
static Automation<std::string> *const automation_id_10 = reinterpret_cast<Automation<std::string> *>(esphome__automation_id_10__pstorage);
alignas(wifi_signal::WiFiSignalSensor) static unsigned char wifi_signal__wifi_signal_wifisignalsensor_id__pstorage[sizeof(wifi_signal::WiFiSignalSensor)];
static wifi_signal::WiFiSignalSensor *const wifi_signal_wifisignalsensor_id = reinterpret_cast<wifi_signal::WiFiSignalSensor *>(wifi_signal__wifi_signal_wifisignalsensor_id__pstorage);
alignas(uptime::UptimeSecondsSensor) static unsigned char uptime__uptime_uptimesecondssensor_id__pstorage[sizeof(uptime::UptimeSecondsSensor)];
static uptime::UptimeSecondsSensor *const uptime_uptimesecondssensor_id = reinterpret_cast<uptime::UptimeSecondsSensor *>(uptime__uptime_uptimesecondssensor_id__pstorage);
alignas(template_::TemplateSensor) static unsigned char template__seat_level_raw__pstorage[sizeof(template_::TemplateSensor)];
static template_::TemplateSensor *const seat_level_raw = reinterpret_cast<template_::TemplateSensor *>(template__seat_level_raw__pstorage);
alignas(template_::TemplateSensor) static unsigned char template__work_state_raw__pstorage[sizeof(template_::TemplateSensor)];
static template_::TemplateSensor *const work_state_raw = reinterpret_cast<template_::TemplateSensor *>(template__work_state_raw__pstorage);
alignas(template_::TemplateSensor) static unsigned char template__flush_kind__pstorage[sizeof(template_::TemplateSensor)];
static template_::TemplateSensor *const flush_kind = reinterpret_cast<template_::TemplateSensor *>(template__flush_kind__pstorage);
alignas(template_::TemplateSensor) static unsigned char template__template__templatesensor_id__pstorage[sizeof(template_::TemplateSensor)];
static template_::TemplateSensor *const template__templatesensor_id = reinterpret_cast<template_::TemplateSensor *>(template__template__templatesensor_id__pstorage);
alignas(status::StatusBinarySensor) static unsigned char status__status_statusbinarysensor_id__pstorage[sizeof(status::StatusBinarySensor)];
static status::StatusBinarySensor *const status_statusbinarysensor_id = reinterpret_cast<status::StatusBinarySensor *>(status__status_statusbinarysensor_id__pstorage);
alignas(template_::TemplateBinarySensor) static unsigned char template__template__templatebinarysensor_id__pstorage[sizeof(template_::TemplateBinarySensor)];
static template_::TemplateBinarySensor *const template__templatebinarysensor_id = reinterpret_cast<template_::TemplateBinarySensor *>(template__template__templatebinarysensor_id__pstorage);
alignas(template_::TemplateBinarySensor) static unsigned char template__state_valid__pstorage[sizeof(template_::TemplateBinarySensor)];
static template_::TemplateBinarySensor *const state_valid = reinterpret_cast<template_::TemplateBinarySensor *>(template__state_valid__pstorage);
alignas(template_::TemplateBinarySensor) static unsigned char template__lid_open__pstorage[sizeof(template_::TemplateBinarySensor)];
static template_::TemplateBinarySensor *const lid_open = reinterpret_cast<template_::TemplateBinarySensor *>(template__lid_open__pstorage);
alignas(template_::TemplateBinarySensor) static unsigned char template__ring_open__pstorage[sizeof(template_::TemplateBinarySensor)];
static template_::TemplateBinarySensor *const ring_open = reinterpret_cast<template_::TemplateBinarySensor *>(template__ring_open__pstorage);
alignas(template_::TemplateBinarySensor) static unsigned char template__occupied__pstorage[sizeof(template_::TemplateBinarySensor)];
static template_::TemplateBinarySensor *const occupied = reinterpret_cast<template_::TemplateBinarySensor *>(template__occupied__pstorage);
alignas(template_::TemplateBinarySensor) static unsigned char template__moving__pstorage[sizeof(template_::TemplateBinarySensor)];
static template_::TemplateBinarySensor *const moving = reinterpret_cast<template_::TemplateBinarySensor *>(template__moving__pstorage);
alignas(template_::TemplateBinarySensor) static unsigned char template__water_ready__pstorage[sizeof(template_::TemplateBinarySensor)];
static template_::TemplateBinarySensor *const water_ready = reinterpret_cast<template_::TemplateBinarySensor *>(template__water_ready__pstorage);
alignas(template_::TemplateBinarySensor) static unsigned char template__foam_running__pstorage[sizeof(template_::TemplateBinarySensor)];
static template_::TemplateBinarySensor *const foam_running = reinterpret_cast<template_::TemplateBinarySensor *>(template__foam_running__pstorage);
alignas(template_::TemplateSwitch) static unsigned char template__keep_connected__pstorage[sizeof(template_::TemplateSwitch)];
static template_::TemplateSwitch *const keep_connected = reinterpret_cast<template_::TemplateSwitch *>(template__keep_connected__pstorage);
alignas(template_::TemplateSwitch) static unsigned char template__away_mode__pstorage[sizeof(template_::TemplateSwitch)];
static template_::TemplateSwitch *const away_mode = reinterpret_cast<template_::TemplateSwitch *>(template__away_mode__pstorage);
alignas(template_::TemplateSwitch) static unsigned char template__night_light__pstorage[sizeof(template_::TemplateSwitch)];
static template_::TemplateSwitch *const night_light = reinterpret_cast<template_::TemplateSwitch *>(template__night_light__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_12__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_12 = reinterpret_cast<Automation<> *>(esphome__automation_id_12__pstorage);
alignas(script::ScriptExecuteAction<script::Script<int, int, int>>) static unsigned char script__script_scriptexecuteaction_id_10__pstorage[sizeof(script::ScriptExecuteAction<script::Script<int, int, int>>)];
static script::ScriptExecuteAction<script::Script<int, int, int>> *const script_scriptexecuteaction_id_10 = reinterpret_cast<script::ScriptExecuteAction<script::Script<int, int, int>> *>(script__script_scriptexecuteaction_id_10__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_11__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_11 = reinterpret_cast<Automation<> *>(esphome__automation_id_11__pstorage);
alignas(script::ScriptExecuteAction<script::Script<int, int, int>>) static unsigned char script__script_scriptexecuteaction_id_9__pstorage[sizeof(script::ScriptExecuteAction<script::Script<int, int, int>>)];
static script::ScriptExecuteAction<script::Script<int, int, int>> *const script_scriptexecuteaction_id_9 = reinterpret_cast<script::ScriptExecuteAction<script::Script<int, int, int>> *>(script__script_scriptexecuteaction_id_9__pstorage);
alignas(template_::TemplateSwitch) static unsigned char template__foot_sensor__pstorage[sizeof(template_::TemplateSwitch)];
static template_::TemplateSwitch *const foot_sensor = reinterpret_cast<template_::TemplateSwitch *>(template__foot_sensor__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_14__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_14 = reinterpret_cast<Automation<> *>(esphome__automation_id_14__pstorage);
alignas(script::ScriptExecuteAction<script::Script<int, int, int>>) static unsigned char script__script_scriptexecuteaction_id_12__pstorage[sizeof(script::ScriptExecuteAction<script::Script<int, int, int>>)];
static script::ScriptExecuteAction<script::Script<int, int, int>> *const script_scriptexecuteaction_id_12 = reinterpret_cast<script::ScriptExecuteAction<script::Script<int, int, int>> *>(script__script_scriptexecuteaction_id_12__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_13__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_13 = reinterpret_cast<Automation<> *>(esphome__automation_id_13__pstorage);
alignas(script::ScriptExecuteAction<script::Script<int, int, int>>) static unsigned char script__script_scriptexecuteaction_id_11__pstorage[sizeof(script::ScriptExecuteAction<script::Script<int, int, int>>)];
static script::ScriptExecuteAction<script::Script<int, int, int>> *const script_scriptexecuteaction_id_11 = reinterpret_cast<script::ScriptExecuteAction<script::Script<int, int, int>> *>(script__script_scriptexecuteaction_id_11__pstorage);
alignas(template_::TemplateSwitch) static unsigned char template__auto_night__pstorage[sizeof(template_::TemplateSwitch)];
static template_::TemplateSwitch *const auto_night = reinterpret_cast<template_::TemplateSwitch *>(template__auto_night__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_16__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_16 = reinterpret_cast<Automation<> *>(esphome__automation_id_16__pstorage);
alignas(script::ScriptExecuteAction<script::Script<int, int, int>>) static unsigned char script__script_scriptexecuteaction_id_14__pstorage[sizeof(script::ScriptExecuteAction<script::Script<int, int, int>>)];
static script::ScriptExecuteAction<script::Script<int, int, int>> *const script_scriptexecuteaction_id_14 = reinterpret_cast<script::ScriptExecuteAction<script::Script<int, int, int>> *>(script__script_scriptexecuteaction_id_14__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_15__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_15 = reinterpret_cast<Automation<> *>(esphome__automation_id_15__pstorage);
alignas(script::ScriptExecuteAction<script::Script<int, int, int>>) static unsigned char script__script_scriptexecuteaction_id_13__pstorage[sizeof(script::ScriptExecuteAction<script::Script<int, int, int>>)];
static script::ScriptExecuteAction<script::Script<int, int, int>> *const script_scriptexecuteaction_id_13 = reinterpret_cast<script::ScriptExecuteAction<script::Script<int, int, int>> *>(script__script_scriptexecuteaction_id_13__pstorage);
alignas(template_::TemplateSelectWithSetAction<false, false, false, 3>) static unsigned char template__seat_temperature__pstorage[sizeof(template_::TemplateSelectWithSetAction<false, false, false, 3>)];
static template_::TemplateSelectWithSetAction<false, false, false, 3> *const seat_temperature = reinterpret_cast<template_::TemplateSelectWithSetAction<false, false, false, 3> *>(template__seat_temperature__pstorage);
static constexpr const char * select_options[] PROGMEM = {"\345\270\270\346\270\251", "\344\270\255\346\270\251", "\351\253\230\346\270\251", "\346\234\252\347\237\245"};
alignas(Automation<StringRef>) static unsigned char esphome__automation_id_17__pstorage[sizeof(Automation<StringRef>)];
static Automation<StringRef> *const automation_id_17 = reinterpret_cast<Automation<StringRef> *>(esphome__automation_id_17__pstorage);
alignas(StatelessLambdaCondition<StringRef>) static unsigned char esphome__lambdacondition_id_13__pstorage[sizeof(StatelessLambdaCondition<StringRef>)];
static StatelessLambdaCondition<StringRef> *const lambdacondition_id_13 = reinterpret_cast<StatelessLambdaCondition<StringRef> *>(esphome__lambdacondition_id_13__pstorage);
alignas(IfAction<false, StringRef>) static unsigned char esphome__ifaction_id_10__pstorage[sizeof(IfAction<false, StringRef>)];
static IfAction<false, StringRef> *const ifaction_id_10 = reinterpret_cast<IfAction<false, StringRef> *>(esphome__ifaction_id_10__pstorage);
alignas(script::ScriptExecuteAction<script::Script<int, int, int>, StringRef>) static unsigned char script__script_scriptexecuteaction_id_15__pstorage[sizeof(script::ScriptExecuteAction<script::Script<int, int, int>, StringRef>)];
static script::ScriptExecuteAction<script::Script<int, int, int>, StringRef> *const script_scriptexecuteaction_id_15 = reinterpret_cast<script::ScriptExecuteAction<script::Script<int, int, int>, StringRef> *>(script__script_scriptexecuteaction_id_15__pstorage);
alignas(template_::TemplateButton) static unsigned char template__template__templatebutton_id__pstorage[sizeof(template_::TemplateButton)];
static template_::TemplateButton *const template__templatebutton_id = reinterpret_cast<template_::TemplateButton *>(template__template__templatebutton_id__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_18__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_18 = reinterpret_cast<Automation<> *>(esphome__automation_id_18__pstorage);
alignas(script::ScriptExecuteAction<script::Script<>>) static unsigned char script__script_scriptexecuteaction_id_16__pstorage[sizeof(script::ScriptExecuteAction<script::Script<>>)];
static script::ScriptExecuteAction<script::Script<>> *const script_scriptexecuteaction_id_16 = reinterpret_cast<script::ScriptExecuteAction<script::Script<>> *>(script__script_scriptexecuteaction_id_16__pstorage);
alignas(template_::TemplateButton) static unsigned char template__template__templatebutton_id_2__pstorage[sizeof(template_::TemplateButton)];
static template_::TemplateButton *const template__templatebutton_id_2 = reinterpret_cast<template_::TemplateButton *>(template__template__templatebutton_id_2__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_19__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_19 = reinterpret_cast<Automation<> *>(esphome__automation_id_19__pstorage);
alignas(StatelessLambdaAction<>) static unsigned char esphome__lambdaaction_id_16__pstorage[sizeof(StatelessLambdaAction<>)];
static StatelessLambdaAction<> *const lambdaaction_id_16 = reinterpret_cast<StatelessLambdaAction<> *>(esphome__lambdaaction_id_16__pstorage);
alignas(template_::TemplateButton) static unsigned char template__template__templatebutton_id_3__pstorage[sizeof(template_::TemplateButton)];
static template_::TemplateButton *const template__templatebutton_id_3 = reinterpret_cast<template_::TemplateButton *>(template__template__templatebutton_id_3__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_20__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_20 = reinterpret_cast<Automation<> *>(esphome__automation_id_20__pstorage);
alignas(script::ScriptExecuteAction<script::Script<int, int, int>>) static unsigned char script__script_scriptexecuteaction_id_17__pstorage[sizeof(script::ScriptExecuteAction<script::Script<int, int, int>>)];
static script::ScriptExecuteAction<script::Script<int, int, int>> *const script_scriptexecuteaction_id_17 = reinterpret_cast<script::ScriptExecuteAction<script::Script<int, int, int>> *>(script__script_scriptexecuteaction_id_17__pstorage);
alignas(template_::TemplateButton) static unsigned char template__template__templatebutton_id_4__pstorage[sizeof(template_::TemplateButton)];
static template_::TemplateButton *const template__templatebutton_id_4 = reinterpret_cast<template_::TemplateButton *>(template__template__templatebutton_id_4__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_21__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_21 = reinterpret_cast<Automation<> *>(esphome__automation_id_21__pstorage);
alignas(script::ScriptExecuteAction<script::Script<int, int, int>>) static unsigned char script__script_scriptexecuteaction_id_18__pstorage[sizeof(script::ScriptExecuteAction<script::Script<int, int, int>>)];
static script::ScriptExecuteAction<script::Script<int, int, int>> *const script_scriptexecuteaction_id_18 = reinterpret_cast<script::ScriptExecuteAction<script::Script<int, int, int>> *>(script__script_scriptexecuteaction_id_18__pstorage);
alignas(template_::TemplateButton) static unsigned char template__template__templatebutton_id_5__pstorage[sizeof(template_::TemplateButton)];
static template_::TemplateButton *const template__templatebutton_id_5 = reinterpret_cast<template_::TemplateButton *>(template__template__templatebutton_id_5__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_22__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_22 = reinterpret_cast<Automation<> *>(esphome__automation_id_22__pstorage);
alignas(script::ScriptExecuteAction<script::Script<int, int, int>>) static unsigned char script__script_scriptexecuteaction_id_19__pstorage[sizeof(script::ScriptExecuteAction<script::Script<int, int, int>>)];
static script::ScriptExecuteAction<script::Script<int, int, int>> *const script_scriptexecuteaction_id_19 = reinterpret_cast<script::ScriptExecuteAction<script::Script<int, int, int>> *>(script__script_scriptexecuteaction_id_19__pstorage);
alignas(template_::TemplateButton) static unsigned char template__template__templatebutton_id_6__pstorage[sizeof(template_::TemplateButton)];
static template_::TemplateButton *const template__templatebutton_id_6 = reinterpret_cast<template_::TemplateButton *>(template__template__templatebutton_id_6__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_23__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_23 = reinterpret_cast<Automation<> *>(esphome__automation_id_23__pstorage);
alignas(script::ScriptExecuteAction<script::Script<int, int, int>>) static unsigned char script__script_scriptexecuteaction_id_20__pstorage[sizeof(script::ScriptExecuteAction<script::Script<int, int, int>>)];
static script::ScriptExecuteAction<script::Script<int, int, int>> *const script_scriptexecuteaction_id_20 = reinterpret_cast<script::ScriptExecuteAction<script::Script<int, int, int>> *>(script__script_scriptexecuteaction_id_20__pstorage);
alignas(template_::TemplateButton) static unsigned char template__template__templatebutton_id_7__pstorage[sizeof(template_::TemplateButton)];
static template_::TemplateButton *const template__templatebutton_id_7 = reinterpret_cast<template_::TemplateButton *>(template__template__templatebutton_id_7__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_24__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_24 = reinterpret_cast<Automation<> *>(esphome__automation_id_24__pstorage);
alignas(script::ScriptExecuteAction<script::Script<int, int, int>>) static unsigned char script__script_scriptexecuteaction_id_21__pstorage[sizeof(script::ScriptExecuteAction<script::Script<int, int, int>>)];
static script::ScriptExecuteAction<script::Script<int, int, int>> *const script_scriptexecuteaction_id_21 = reinterpret_cast<script::ScriptExecuteAction<script::Script<int, int, int>> *>(script__script_scriptexecuteaction_id_21__pstorage);
alignas(template_::TemplateButton) static unsigned char template__template__templatebutton_id_8__pstorage[sizeof(template_::TemplateButton)];
static template_::TemplateButton *const template__templatebutton_id_8 = reinterpret_cast<template_::TemplateButton *>(template__template__templatebutton_id_8__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_25__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_25 = reinterpret_cast<Automation<> *>(esphome__automation_id_25__pstorage);
alignas(script::ScriptExecuteAction<script::Script<int, int, int>>) static unsigned char script__script_scriptexecuteaction_id_22__pstorage[sizeof(script::ScriptExecuteAction<script::Script<int, int, int>>)];
static script::ScriptExecuteAction<script::Script<int, int, int>> *const script_scriptexecuteaction_id_22 = reinterpret_cast<script::ScriptExecuteAction<script::Script<int, int, int>> *>(script__script_scriptexecuteaction_id_22__pstorage);
alignas(template_::TemplateButton) static unsigned char template__template__templatebutton_id_9__pstorage[sizeof(template_::TemplateButton)];
static template_::TemplateButton *const template__templatebutton_id_9 = reinterpret_cast<template_::TemplateButton *>(template__template__templatebutton_id_9__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_26__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_26 = reinterpret_cast<Automation<> *>(esphome__automation_id_26__pstorage);
alignas(script::ScriptExecuteAction<script::Script<int, int, int>>) static unsigned char script__script_scriptexecuteaction_id_23__pstorage[sizeof(script::ScriptExecuteAction<script::Script<int, int, int>>)];
static script::ScriptExecuteAction<script::Script<int, int, int>> *const script_scriptexecuteaction_id_23 = reinterpret_cast<script::ScriptExecuteAction<script::Script<int, int, int>> *>(script__script_scriptexecuteaction_id_23__pstorage);
alignas(template_::TemplateButton) static unsigned char template__template__templatebutton_id_10__pstorage[sizeof(template_::TemplateButton)];
static template_::TemplateButton *const template__templatebutton_id_10 = reinterpret_cast<template_::TemplateButton *>(template__template__templatebutton_id_10__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_27__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_27 = reinterpret_cast<Automation<> *>(esphome__automation_id_27__pstorage);
alignas(script::ScriptExecuteAction<script::Script<int, int, int>>) static unsigned char script__script_scriptexecuteaction_id_24__pstorage[sizeof(script::ScriptExecuteAction<script::Script<int, int, int>>)];
static script::ScriptExecuteAction<script::Script<int, int, int>> *const script_scriptexecuteaction_id_24 = reinterpret_cast<script::ScriptExecuteAction<script::Script<int, int, int>> *>(script__script_scriptexecuteaction_id_24__pstorage);
alignas(template_::TemplateButton) static unsigned char template__template__templatebutton_id_11__pstorage[sizeof(template_::TemplateButton)];
static template_::TemplateButton *const template__templatebutton_id_11 = reinterpret_cast<template_::TemplateButton *>(template__template__templatebutton_id_11__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_28__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_28 = reinterpret_cast<Automation<> *>(esphome__automation_id_28__pstorage);
alignas(script::ScriptExecuteAction<script::Script<>>) static unsigned char script__script_scriptexecuteaction_id_25__pstorage[sizeof(script::ScriptExecuteAction<script::Script<>>)];
static script::ScriptExecuteAction<script::Script<>> *const script_scriptexecuteaction_id_25 = reinterpret_cast<script::ScriptExecuteAction<script::Script<>> *>(script__script_scriptexecuteaction_id_25__pstorage);
alignas(template_::TemplateButton) static unsigned char template__template__templatebutton_id_12__pstorage[sizeof(template_::TemplateButton)];
static template_::TemplateButton *const template__templatebutton_id_12 = reinterpret_cast<template_::TemplateButton *>(template__template__templatebutton_id_12__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_29__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_29 = reinterpret_cast<Automation<> *>(esphome__automation_id_29__pstorage);
alignas(script::ScriptExecuteAction<script::Script<>>) static unsigned char script__script_scriptexecuteaction_id_26__pstorage[sizeof(script::ScriptExecuteAction<script::Script<>>)];
static script::ScriptExecuteAction<script::Script<>> *const script_scriptexecuteaction_id_26 = reinterpret_cast<script::ScriptExecuteAction<script::Script<>> *>(script__script_scriptexecuteaction_id_26__pstorage);
alignas(script::ScriptWaitAction<script::SingleScript<>>) static unsigned char script__script_scriptwaitaction_id_2__pstorage[sizeof(script::ScriptWaitAction<script::SingleScript<>>)];
static script::ScriptWaitAction<script::SingleScript<>> *const script_scriptwaitaction_id_2 = reinterpret_cast<script::ScriptWaitAction<script::SingleScript<>> *>(script__script_scriptwaitaction_id_2__pstorage);
alignas(script::ScriptExecuteAction<script::Script<>>) static unsigned char script__script_scriptexecuteaction_id_27__pstorage[sizeof(script::ScriptExecuteAction<script::Script<>>)];
static script::ScriptExecuteAction<script::Script<>> *const script_scriptexecuteaction_id_27 = reinterpret_cast<script::ScriptExecuteAction<script::Script<>> *>(script__script_scriptexecuteaction_id_27__pstorage);
alignas(template_::TemplateButton) static unsigned char template__template__templatebutton_id_13__pstorage[sizeof(template_::TemplateButton)];
static template_::TemplateButton *const template__templatebutton_id_13 = reinterpret_cast<template_::TemplateButton *>(template__template__templatebutton_id_13__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_30__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_30 = reinterpret_cast<Automation<> *>(esphome__automation_id_30__pstorage);
alignas(script::ScriptExecuteAction<script::Script<>>) static unsigned char script__script_scriptexecuteaction_id_28__pstorage[sizeof(script::ScriptExecuteAction<script::Script<>>)];
static script::ScriptExecuteAction<script::Script<>> *const script_scriptexecuteaction_id_28 = reinterpret_cast<script::ScriptExecuteAction<script::Script<>> *>(script__script_scriptexecuteaction_id_28__pstorage);
alignas(interval::IntervalTrigger) static unsigned char interval__interval_intervaltrigger_id__pstorage[sizeof(interval::IntervalTrigger)];
static interval::IntervalTrigger *const interval_intervaltrigger_id = reinterpret_cast<interval::IntervalTrigger *>(interval__interval_intervaltrigger_id__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_31__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_31 = reinterpret_cast<Automation<> *>(esphome__automation_id_31__pstorage);
alignas(StatelessLambdaCondition<>) static unsigned char esphome__lambdacondition_id_14__pstorage[sizeof(StatelessLambdaCondition<>)];
static StatelessLambdaCondition<> *const lambdacondition_id_14 = reinterpret_cast<StatelessLambdaCondition<> *>(esphome__lambdacondition_id_14__pstorage);
alignas(IfAction<false>) static unsigned char esphome__ifaction_id_11__pstorage[sizeof(IfAction<false>)];
static IfAction<false> *const ifaction_id_11 = reinterpret_cast<IfAction<false> *>(esphome__ifaction_id_11__pstorage);
alignas(StatelessLambdaAction<>) static unsigned char esphome__lambdaaction_id_17__pstorage[sizeof(StatelessLambdaAction<>)];
static StatelessLambdaAction<> *const lambdaaction_id_17 = reinterpret_cast<StatelessLambdaAction<> *>(esphome__lambdaaction_id_17__pstorage);
alignas(script::ScriptExecuteAction<script::Script<>>) static unsigned char script__script_scriptexecuteaction_id_29__pstorage[sizeof(script::ScriptExecuteAction<script::Script<>>)];
static script::ScriptExecuteAction<script::Script<>> *const script_scriptexecuteaction_id_29 = reinterpret_cast<script::ScriptExecuteAction<script::Script<>> *>(script__script_scriptexecuteaction_id_29__pstorage);
alignas(interval::IntervalTrigger) static unsigned char interval__interval_intervaltrigger_id_2__pstorage[sizeof(interval::IntervalTrigger)];
static interval::IntervalTrigger *const interval_intervaltrigger_id_2 = reinterpret_cast<interval::IntervalTrigger *>(interval__interval_intervaltrigger_id_2__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_32__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_32 = reinterpret_cast<Automation<> *>(esphome__automation_id_32__pstorage);
alignas(template_::TemplateText) static unsigned char template__target_mac__pstorage[sizeof(template_::TemplateText)];
static template_::TemplateText *const target_mac = reinterpret_cast<template_::TemplateText *>(template__target_mac__pstorage);
alignas(Automation<std::string>) static unsigned char esphome__automation_id_35__pstorage[sizeof(Automation<std::string>)];
static Automation<std::string> *const automation_id_35 = reinterpret_cast<Automation<std::string> *>(esphome__automation_id_35__pstorage);
alignas(esp32_ble::ESP32BLE) static unsigned char esp32_ble__esp32_ble_esp32ble_id__pstorage[sizeof(esp32_ble::ESP32BLE)];
static esp32_ble::ESP32BLE *const esp32_ble_esp32ble_id = reinterpret_cast<esp32_ble::ESP32BLE *>(esp32_ble__esp32_ble_esp32ble_id__pstorage);
alignas(globals::RestoringGlobalStringComponent<std::string, 18>) static unsigned char globals__configured_mac__pstorage[sizeof(globals::RestoringGlobalStringComponent<std::string, 18>)];
static globals::RestoringGlobalStringComponent<std::string, 18> *const configured_mac = reinterpret_cast<globals::RestoringGlobalStringComponent<std::string, 18> *>(globals__configured_mac__pstorage);
alignas(globals::GlobalsComponent<uint32_t>) static unsigned char globals__command_started__pstorage[sizeof(globals::GlobalsComponent<uint32_t>)];
static globals::GlobalsComponent<uint32_t> *const command_started = reinterpret_cast<globals::GlobalsComponent<uint32_t> *>(globals__command_started__pstorage);
alignas(globals::GlobalsComponent<bool>) static unsigned char globals__command_pending__pstorage[sizeof(globals::GlobalsComponent<bool>)];
static globals::GlobalsComponent<bool> *const command_pending = reinterpret_cast<globals::GlobalsComponent<bool> *>(globals__command_pending__pstorage);
alignas(globals::GlobalsComponent<bool>) static unsigned char globals__accepted__pstorage[sizeof(globals::GlobalsComponent<bool>)];
static globals::GlobalsComponent<bool> *const accepted = reinterpret_cast<globals::GlobalsComponent<bool> *>(globals__accepted__pstorage);
alignas(globals::GlobalsComponent<int>) static unsigned char globals__pending_cmd__pstorage[sizeof(globals::GlobalsComponent<int>)];
static globals::GlobalsComponent<int> *const pending_cmd = reinterpret_cast<globals::GlobalsComponent<int> *>(globals__pending_cmd__pstorage);
alignas(globals::GlobalsComponent<int>) static unsigned char globals__pending_value__pstorage[sizeof(globals::GlobalsComponent<int>)];
static globals::GlobalsComponent<int> *const pending_value = reinterpret_cast<globals::GlobalsComponent<int> *>(globals__pending_value__pstorage);
alignas(globals::GlobalsComponent<int>) static unsigned char globals__pending_index__pstorage[sizeof(globals::GlobalsComponent<int>)];
static globals::GlobalsComponent<int> *const pending_index = reinterpret_cast<globals::GlobalsComponent<int> *>(globals__pending_index__pstorage);
alignas(globals::GlobalsComponent<uint32_t>) static unsigned char globals__sent_at__pstorage[sizeof(globals::GlobalsComponent<uint32_t>)];
static globals::GlobalsComponent<uint32_t> *const sent_at = reinterpret_cast<globals::GlobalsComponent<uint32_t> *>(globals__sent_at__pstorage);
alignas(globals::GlobalsComponent<uint32_t>) static unsigned char globals__sent_sequence__pstorage[sizeof(globals::GlobalsComponent<uint32_t>)];
static globals::GlobalsComponent<uint32_t> *const sent_sequence = reinterpret_cast<globals::GlobalsComponent<uint32_t> *>(globals__sent_sequence__pstorage);
alignas(StatelessLambdaAction<>) static unsigned char esphome__lambdaaction_id_2__pstorage[sizeof(StatelessLambdaAction<>)];
static StatelessLambdaAction<> *const lambdaaction_id_2 = reinterpret_cast<StatelessLambdaAction<> *>(esphome__lambdaaction_id_2__pstorage);
alignas(script::ScriptExecuteAction<script::Script<>>) static unsigned char script__script_scriptexecuteaction_id__pstorage[sizeof(script::ScriptExecuteAction<script::Script<>>)];
static script::ScriptExecuteAction<script::Script<>> *const script_scriptexecuteaction_id = reinterpret_cast<script::ScriptExecuteAction<script::Script<>> *>(script__script_scriptexecuteaction_id__pstorage);
alignas(ble_client::BLEClientDisconnectTrigger) static unsigned char ble_client__ble_client_bleclientdisconnecttrigger_id__pstorage[sizeof(ble_client::BLEClientDisconnectTrigger)];
static ble_client::BLEClientDisconnectTrigger *const ble_client_bleclientdisconnecttrigger_id = reinterpret_cast<ble_client::BLEClientDisconnectTrigger *>(ble_client__ble_client_bleclientdisconnecttrigger_id__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_3__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_3 = reinterpret_cast<Automation<> *>(esphome__automation_id_3__pstorage);
static void esphome__applyaction_id__fn() {
  ::esp32_ble_tracker_esp32bletracker_id->stop_scan();
}
alignas(ApplyAction<esphome__applyaction_id__fn>) static unsigned char esphome__applyaction_id__pstorage[sizeof(ApplyAction<esphome__applyaction_id__fn>)];
static ApplyAction<esphome__applyaction_id__fn> *const applyaction_id = reinterpret_cast<ApplyAction<esphome__applyaction_id__fn> *>(esphome__applyaction_id__pstorage);
static void esphome__applyaction_id_2__fn() {
  ::send_command->stop();
}
alignas(ApplyAction<esphome__applyaction_id_2__fn>) static unsigned char esphome__applyaction_id_2__pstorage[sizeof(ApplyAction<esphome__applyaction_id_2__fn>)];
static ApplyAction<esphome__applyaction_id_2__fn> *const applyaction_id_2 = reinterpret_cast<ApplyAction<esphome__applyaction_id_2__fn> *>(esphome__applyaction_id_2__pstorage);
static void esphome__applyaction_id_3__fn() {
  ::acquire_session->stop();
}
alignas(ApplyAction<esphome__applyaction_id_3__fn>) static unsigned char esphome__applyaction_id_3__pstorage[sizeof(ApplyAction<esphome__applyaction_id_3__fn>)];
static ApplyAction<esphome__applyaction_id_3__fn> *const applyaction_id_3 = reinterpret_cast<ApplyAction<esphome__applyaction_id_3__fn> *>(esphome__applyaction_id_3__pstorage);
static void esphome__applyaction_id_4__fn() {
  ::query_version->stop();
}
alignas(ApplyAction<esphome__applyaction_id_4__fn>) static unsigned char esphome__applyaction_id_4__pstorage[sizeof(ApplyAction<esphome__applyaction_id_4__fn>)];
static ApplyAction<esphome__applyaction_id_4__fn> *const applyaction_id_4 = reinterpret_cast<ApplyAction<esphome__applyaction_id_4__fn> *>(esphome__applyaction_id_4__pstorage);
static void esphome__applyaction_id_5__fn() {
  ::query_state->stop();
}
alignas(ApplyAction<esphome__applyaction_id_5__fn>) static unsigned char esphome__applyaction_id_5__pstorage[sizeof(ApplyAction<esphome__applyaction_id_5__fn>)];
static ApplyAction<esphome__applyaction_id_5__fn> *const applyaction_id_5 = reinterpret_cast<ApplyAction<esphome__applyaction_id_5__fn> *>(esphome__applyaction_id_5__pstorage);
static void esphome__applyaction_id_6__fn() {
  ::bootstrap->stop();
}
alignas(ApplyAction<esphome__applyaction_id_6__fn>) static unsigned char esphome__applyaction_id_6__pstorage[sizeof(ApplyAction<esphome__applyaction_id_6__fn>)];
static ApplyAction<esphome__applyaction_id_6__fn> *const applyaction_id_6 = reinterpret_cast<ApplyAction<esphome__applyaction_id_6__fn> *>(esphome__applyaction_id_6__pstorage);
alignas(StatelessLambdaAction<>) static unsigned char esphome__lambdaaction_id_3__pstorage[sizeof(StatelessLambdaAction<>)];
static StatelessLambdaAction<> *const lambdaaction_id_3 = reinterpret_cast<StatelessLambdaAction<> *>(esphome__lambdaaction_id_3__pstorage);
alignas(StatelessLambdaCondition<>) static unsigned char esphome__lambdacondition_id_3__pstorage[sizeof(StatelessLambdaCondition<>)];
static StatelessLambdaCondition<> *const lambdacondition_id_3 = reinterpret_cast<StatelessLambdaCondition<> *>(esphome__lambdacondition_id_3__pstorage);
alignas(IfAction<false>) static unsigned char esphome__ifaction_id_3__pstorage[sizeof(IfAction<false>)];
static IfAction<false> *const ifaction_id_3 = reinterpret_cast<IfAction<false> *>(esphome__ifaction_id_3__pstorage);
alignas(StatelessLambdaAction<>) static unsigned char esphome__lambdaaction_id_4__pstorage[sizeof(StatelessLambdaAction<>)];
static StatelessLambdaAction<> *const lambdaaction_id_4 = reinterpret_cast<StatelessLambdaAction<> *>(esphome__lambdaaction_id_4__pstorage);
static void esphome__applyaction_id_7__fn() {
  ::reconnect_ble->stop();
}
alignas(ApplyAction<esphome__applyaction_id_7__fn>) static unsigned char esphome__applyaction_id_7__pstorage[sizeof(ApplyAction<esphome__applyaction_id_7__fn>)];
static ApplyAction<esphome__applyaction_id_7__fn> *const applyaction_id_7 = reinterpret_cast<ApplyAction<esphome__applyaction_id_7__fn> *>(esphome__applyaction_id_7__pstorage);
static void esphome__applyaction_id_8__fn() {
  ::acquire_session->stop();
}
alignas(ApplyAction<esphome__applyaction_id_8__fn>) static unsigned char esphome__applyaction_id_8__pstorage[sizeof(ApplyAction<esphome__applyaction_id_8__fn>)];
static ApplyAction<esphome__applyaction_id_8__fn> *const applyaction_id_8 = reinterpret_cast<ApplyAction<esphome__applyaction_id_8__fn> *>(esphome__applyaction_id_8__pstorage);
static void esphome__applyaction_id_9__fn() {
  ::bootstrap->stop();
}
alignas(ApplyAction<esphome__applyaction_id_9__fn>) static unsigned char esphome__applyaction_id_9__pstorage[sizeof(ApplyAction<esphome__applyaction_id_9__fn>)];
static ApplyAction<esphome__applyaction_id_9__fn> *const applyaction_id_9 = reinterpret_cast<ApplyAction<esphome__applyaction_id_9__fn> *>(esphome__applyaction_id_9__pstorage);
static void esphome__applyaction_id_10__fn() {
  ::query_state->stop();
}
alignas(ApplyAction<esphome__applyaction_id_10__fn>) static unsigned char esphome__applyaction_id_10__pstorage[sizeof(ApplyAction<esphome__applyaction_id_10__fn>)];
static ApplyAction<esphome__applyaction_id_10__fn> *const applyaction_id_10 = reinterpret_cast<ApplyAction<esphome__applyaction_id_10__fn> *>(esphome__applyaction_id_10__pstorage);
static void esphome__applyaction_id_11__fn() {
  ::query_version->stop();
}
alignas(ApplyAction<esphome__applyaction_id_11__fn>) static unsigned char esphome__applyaction_id_11__pstorage[sizeof(ApplyAction<esphome__applyaction_id_11__fn>)];
static ApplyAction<esphome__applyaction_id_11__fn> *const applyaction_id_11 = reinterpret_cast<ApplyAction<esphome__applyaction_id_11__fn> *>(esphome__applyaction_id_11__pstorage);
alignas(StatelessLambdaAction<>) static unsigned char esphome__lambdaaction_id_5__pstorage[sizeof(StatelessLambdaAction<>)];
static StatelessLambdaAction<> *const lambdaaction_id_5 = reinterpret_cast<StatelessLambdaAction<> *>(esphome__lambdaaction_id_5__pstorage);
alignas(StatelessLambdaCondition<>) static unsigned char esphome__lambdacondition_id_4__pstorage[sizeof(StatelessLambdaCondition<>)];
static StatelessLambdaCondition<> *const lambdacondition_id_4 = reinterpret_cast<StatelessLambdaCondition<> *>(esphome__lambdacondition_id_4__pstorage);
alignas(WaitUntilAction<>) static unsigned char esphome__waituntilaction_id__pstorage[sizeof(WaitUntilAction<>)];
static WaitUntilAction<> *const waituntilaction_id = reinterpret_cast<WaitUntilAction<> *>(esphome__waituntilaction_id__pstorage);
alignas(StatelessLambdaCondition<>) static unsigned char esphome__lambdacondition_id_5__pstorage[sizeof(StatelessLambdaCondition<>)];
static StatelessLambdaCondition<> *const lambdacondition_id_5 = reinterpret_cast<StatelessLambdaCondition<> *>(esphome__lambdacondition_id_5__pstorage);
alignas(IfAction<true>) static unsigned char esphome__ifaction_id_4__pstorage[sizeof(IfAction<true>)];
static IfAction<true> *const ifaction_id_4 = reinterpret_cast<IfAction<true> *>(esphome__ifaction_id_4__pstorage);
alignas(script::ScriptExecuteAction<script::Script<>>) static unsigned char script__script_scriptexecuteaction_id_4__pstorage[sizeof(script::ScriptExecuteAction<script::Script<>>)];
static script::ScriptExecuteAction<script::Script<>> *const script_scriptexecuteaction_id_4 = reinterpret_cast<script::ScriptExecuteAction<script::Script<>> *>(script__script_scriptexecuteaction_id_4__pstorage);
alignas(StatelessLambdaAction<>) static unsigned char esphome__lambdaaction_id_6__pstorage[sizeof(StatelessLambdaAction<>)];
static StatelessLambdaAction<> *const lambdaaction_id_6 = reinterpret_cast<StatelessLambdaAction<> *>(esphome__lambdaaction_id_6__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_8__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_8 = reinterpret_cast<Automation<> *>(esphome__automation_id_8__pstorage);
alignas(StatelessLambdaCondition<>) static unsigned char esphome__lambdacondition_id_6__pstorage[sizeof(StatelessLambdaCondition<>)];
static StatelessLambdaCondition<> *const lambdacondition_id_6 = reinterpret_cast<StatelessLambdaCondition<> *>(esphome__lambdacondition_id_6__pstorage);
alignas(IfAction<false>) static unsigned char esphome__ifaction_id_5__pstorage[sizeof(IfAction<false>)];
static IfAction<false> *const ifaction_id_5 = reinterpret_cast<IfAction<false> *>(esphome__ifaction_id_5__pstorage);
alignas(StatelessLambdaAction<>) static unsigned char esphome__lambdaaction_id_7__pstorage[sizeof(StatelessLambdaAction<>)];
static StatelessLambdaAction<> *const lambdaaction_id_7 = reinterpret_cast<StatelessLambdaAction<> *>(esphome__lambdaaction_id_7__pstorage);
static void esphome__applyaction_id_12__fn() {
  ::acquire_session->stop();
}
alignas(ApplyAction<esphome__applyaction_id_12__fn>) static unsigned char esphome__applyaction_id_12__pstorage[sizeof(ApplyAction<esphome__applyaction_id_12__fn>)];
static ApplyAction<esphome__applyaction_id_12__fn> *const applyaction_id_12 = reinterpret_cast<ApplyAction<esphome__applyaction_id_12__fn> *>(esphome__applyaction_id_12__pstorage);
alignas(StatelessLambdaCondition<>) static unsigned char esphome__lambdacondition_id_7__pstorage[sizeof(StatelessLambdaCondition<>)];
static StatelessLambdaCondition<> *const lambdacondition_id_7 = reinterpret_cast<StatelessLambdaCondition<> *>(esphome__lambdacondition_id_7__pstorage);
alignas(IfAction<false>) static unsigned char esphome__ifaction_id_6__pstorage[sizeof(IfAction<false>)];
static IfAction<false> *const ifaction_id_6 = reinterpret_cast<IfAction<false> *>(esphome__ifaction_id_6__pstorage);
alignas(StatelessLambdaAction<>) static unsigned char esphome__lambdaaction_id_8__pstorage[sizeof(StatelessLambdaAction<>)];
static StatelessLambdaAction<> *const lambdaaction_id_8 = reinterpret_cast<StatelessLambdaAction<> *>(esphome__lambdaaction_id_8__pstorage);
static void esphome__applyaction_id_13__fn() {
  ::acquire_session->stop();
}
alignas(ApplyAction<esphome__applyaction_id_13__fn>) static unsigned char esphome__applyaction_id_13__pstorage[sizeof(ApplyAction<esphome__applyaction_id_13__fn>)];
static ApplyAction<esphome__applyaction_id_13__fn> *const applyaction_id_13 = reinterpret_cast<ApplyAction<esphome__applyaction_id_13__fn> *>(esphome__applyaction_id_13__pstorage);
alignas(StatelessLambdaAction<>) static unsigned char esphome__lambdaaction_id_9__pstorage[sizeof(StatelessLambdaAction<>)];
static StatelessLambdaAction<> *const lambdaaction_id_9 = reinterpret_cast<StatelessLambdaAction<> *>(esphome__lambdaaction_id_9__pstorage);
alignas(StatelessLambdaCondition<>) static unsigned char esphome__lambdacondition_id_8__pstorage[sizeof(StatelessLambdaCondition<>)];
static StatelessLambdaCondition<> *const lambdacondition_id_8 = reinterpret_cast<StatelessLambdaCondition<> *>(esphome__lambdacondition_id_8__pstorage);
alignas(IfAction<false>) static unsigned char esphome__ifaction_id_7__pstorage[sizeof(IfAction<false>)];
static IfAction<false> *const ifaction_id_7 = reinterpret_cast<IfAction<false> *>(esphome__ifaction_id_7__pstorage);
alignas(ble_client::BLEClientConnectAction<>) static unsigned char ble_client__ble_client_bleclientconnectaction_id__pstorage[sizeof(ble_client::BLEClientConnectAction<>)];
static ble_client::BLEClientConnectAction<> *const ble_client_bleclientconnectaction_id = reinterpret_cast<ble_client::BLEClientConnectAction<> *>(ble_client__ble_client_bleclientconnectaction_id__pstorage);
alignas(script::ScriptExecuteAction<script::Script<>>) static unsigned char script__script_scriptexecuteaction_id_5__pstorage[sizeof(script::ScriptExecuteAction<script::Script<>>)];
static script::ScriptExecuteAction<script::Script<>> *const script_scriptexecuteaction_id_5 = reinterpret_cast<script::ScriptExecuteAction<script::Script<>> *>(script__script_scriptexecuteaction_id_5__pstorage);
alignas(Automation<int, int, int>) static unsigned char esphome__automation_id_9__pstorage[sizeof(Automation<int, int, int>)];
static Automation<int, int, int> *const automation_id_9 = reinterpret_cast<Automation<int, int, int> *>(esphome__automation_id_9__pstorage);
alignas(StatelessLambdaCondition<int, int, int>) static unsigned char esphome__lambdacondition_id_9__pstorage[sizeof(StatelessLambdaCondition<int, int, int>)];
static StatelessLambdaCondition<int, int, int> *const lambdacondition_id_9 = reinterpret_cast<StatelessLambdaCondition<int, int, int> *>(esphome__lambdacondition_id_9__pstorage);
alignas(IfAction<false, int, int, int>) static unsigned char esphome__ifaction_id_8__pstorage[sizeof(IfAction<false, int, int, int>)];
static IfAction<false, int, int, int> *const ifaction_id_8 = reinterpret_cast<IfAction<false, int, int, int> *>(esphome__ifaction_id_8__pstorage);
alignas(StatelessLambdaAction<int, int, int>) static unsigned char esphome__lambdaaction_id_10__pstorage[sizeof(StatelessLambdaAction<int, int, int>)];
static StatelessLambdaAction<int, int, int> *const lambdaaction_id_10 = reinterpret_cast<StatelessLambdaAction<int, int, int> *>(esphome__lambdaaction_id_10__pstorage);
static void esphome__applyaction_id_14__fn(const std::remove_cvref_t<int> & cmd, const std::remove_cvref_t<int> & arg, const std::remove_cvref_t<int> & index) {
  ::send_command->stop();
}
alignas(ApplyAction<esphome__applyaction_id_14__fn, int, int, int>) static unsigned char esphome__applyaction_id_14__pstorage[sizeof(ApplyAction<esphome__applyaction_id_14__fn, int, int, int>)];
static ApplyAction<esphome__applyaction_id_14__fn, int, int, int> *const applyaction_id_14 = reinterpret_cast<ApplyAction<esphome__applyaction_id_14__fn, int, int, int> *>(esphome__applyaction_id_14__pstorage);
alignas(StatelessLambdaAction<int, int, int>) static unsigned char esphome__lambdaaction_id_11__pstorage[sizeof(StatelessLambdaAction<int, int, int>)];
static StatelessLambdaAction<int, int, int> *const lambdaaction_id_11 = reinterpret_cast<StatelessLambdaAction<int, int, int> *>(esphome__lambdaaction_id_11__pstorage);
alignas(script::ScriptExecuteAction<script::Script<>, int, int, int>) static unsigned char script__script_scriptexecuteaction_id_6__pstorage[sizeof(script::ScriptExecuteAction<script::Script<>, int, int, int>)];
static script::ScriptExecuteAction<script::Script<>, int, int, int> *const script_scriptexecuteaction_id_6 = reinterpret_cast<script::ScriptExecuteAction<script::Script<>, int, int, int> *>(script__script_scriptexecuteaction_id_6__pstorage);
alignas(StatelessLambdaCondition<int, int, int>) static unsigned char esphome__lambdacondition_id_10__pstorage[sizeof(StatelessLambdaCondition<int, int, int>)];
static StatelessLambdaCondition<int, int, int> *const lambdacondition_id_10 = reinterpret_cast<StatelessLambdaCondition<int, int, int> *>(esphome__lambdacondition_id_10__pstorage);
alignas(WaitUntilAction<int, int, int>) static unsigned char esphome__waituntilaction_id_2__pstorage[sizeof(WaitUntilAction<int, int, int>)];
static WaitUntilAction<int, int, int> *const waituntilaction_id_2 = reinterpret_cast<WaitUntilAction<int, int, int> *>(esphome__waituntilaction_id_2__pstorage);
alignas(StatelessLambdaAction<int, int, int>) static unsigned char esphome__lambdaaction_id_12__pstorage[sizeof(StatelessLambdaAction<int, int, int>)];
static StatelessLambdaAction<int, int, int> *const lambdaaction_id_12 = reinterpret_cast<StatelessLambdaAction<int, int, int> *>(esphome__lambdaaction_id_12__pstorage);
alignas(script::ScriptExecuteAction<script::Script<>, int, int, int>) static unsigned char script__script_scriptexecuteaction_id_7__pstorage[sizeof(script::ScriptExecuteAction<script::Script<>, int, int, int>)];
static script::ScriptExecuteAction<script::Script<>, int, int, int> *const script_scriptexecuteaction_id_7 = reinterpret_cast<script::ScriptExecuteAction<script::Script<>, int, int, int> *>(script__script_scriptexecuteaction_id_7__pstorage);
alignas(StatelessLambdaCondition<int, int, int>) static unsigned char esphome__lambdacondition_id_11__pstorage[sizeof(StatelessLambdaCondition<int, int, int>)];
static StatelessLambdaCondition<int, int, int> *const lambdacondition_id_11 = reinterpret_cast<StatelessLambdaCondition<int, int, int> *>(esphome__lambdacondition_id_11__pstorage);
alignas(WaitUntilAction<int, int, int>) static unsigned char esphome__waituntilaction_id_3__pstorage[sizeof(WaitUntilAction<int, int, int>)];
static WaitUntilAction<int, int, int> *const waituntilaction_id_3 = reinterpret_cast<WaitUntilAction<int, int, int> *>(esphome__waituntilaction_id_3__pstorage);
alignas(StatelessLambdaAction<int, int, int>) static unsigned char esphome__lambdaaction_id_13__pstorage[sizeof(StatelessLambdaAction<int, int, int>)];
static StatelessLambdaAction<int, int, int> *const lambdaaction_id_13 = reinterpret_cast<StatelessLambdaAction<int, int, int> *>(esphome__lambdaaction_id_13__pstorage);
alignas(StatelessLambdaCondition<int, int, int>) static unsigned char esphome__lambdacondition_id_12__pstorage[sizeof(StatelessLambdaCondition<int, int, int>)];
static StatelessLambdaCondition<int, int, int> *const lambdacondition_id_12 = reinterpret_cast<StatelessLambdaCondition<int, int, int> *>(esphome__lambdacondition_id_12__pstorage);
alignas(IfAction<false, int, int, int>) static unsigned char esphome__ifaction_id_9__pstorage[sizeof(IfAction<false, int, int, int>)];
static IfAction<false, int, int, int> *const ifaction_id_9 = reinterpret_cast<IfAction<false, int, int, int> *>(esphome__ifaction_id_9__pstorage);
alignas(ble_client::BLEClientWriteAction<int, int, int>) static unsigned char ble_client__ble_client_bleclientwriteaction_id_3__pstorage[sizeof(ble_client::BLEClientWriteAction<int, int, int>)];
static ble_client::BLEClientWriteAction<int, int, int> *const ble_client_bleclientwriteaction_id_3 = reinterpret_cast<ble_client::BLEClientWriteAction<int, int, int> *>(ble_client__ble_client_bleclientwriteaction_id_3__pstorage);
alignas(DelayAction<int, int, int>) static unsigned char esphome__delayaction_id_3__pstorage[sizeof(DelayAction<int, int, int>)];
static DelayAction<int, int, int> *const delayaction_id_3 = reinterpret_cast<DelayAction<int, int, int> *>(esphome__delayaction_id_3__pstorage);
alignas(script::ScriptExecuteAction<script::Script<>, int, int, int>) static unsigned char script__script_scriptexecuteaction_id_8__pstorage[sizeof(script::ScriptExecuteAction<script::Script<>, int, int, int>)];
static script::ScriptExecuteAction<script::Script<>, int, int, int> *const script_scriptexecuteaction_id_8 = reinterpret_cast<script::ScriptExecuteAction<script::Script<>, int, int, int> *>(script__script_scriptexecuteaction_id_8__pstorage);
alignas(StatelessLambdaAction<std::string>) static unsigned char esphome__lambdaaction_id_14__pstorage[sizeof(StatelessLambdaAction<std::string>)];
static StatelessLambdaAction<std::string> *const lambdaaction_id_14 = reinterpret_cast<StatelessLambdaAction<std::string> *>(esphome__lambdaaction_id_14__pstorage);
alignas(StatelessLambdaAction<>) static unsigned char esphome__lambdaaction_id_15__pstorage[sizeof(StatelessLambdaAction<>)];
static StatelessLambdaAction<> *const lambdaaction_id_15 = reinterpret_cast<StatelessLambdaAction<> *>(esphome__lambdaaction_id_15__pstorage);
alignas(StatelessLambdaCondition<>) static unsigned char esphome__lambdacondition_id_15__pstorage[sizeof(StatelessLambdaCondition<>)];
static StatelessLambdaCondition<> *const lambdacondition_id_15 = reinterpret_cast<StatelessLambdaCondition<> *>(esphome__lambdacondition_id_15__pstorage);
alignas(IfAction<false>) static unsigned char esphome__ifaction_id_12__pstorage[sizeof(IfAction<false>)];
static IfAction<false> *const ifaction_id_12 = reinterpret_cast<IfAction<false> *>(esphome__ifaction_id_12__pstorage);
static void esphome__applyaction_id_15__fn() {
  ::esp32_ble_tracker_esp32bletracker_id->stop_scan();
}
alignas(ApplyAction<esphome__applyaction_id_15__fn>) static unsigned char esphome__applyaction_id_15__pstorage[sizeof(ApplyAction<esphome__applyaction_id_15__fn>)];
static ApplyAction<esphome__applyaction_id_15__fn> *const applyaction_id_15 = reinterpret_cast<ApplyAction<esphome__applyaction_id_15__fn> *>(esphome__applyaction_id_15__pstorage);
static void esphome__applyaction_id_16__fn() {
  ::send_command->stop();
}
alignas(ApplyAction<esphome__applyaction_id_16__fn>) static unsigned char esphome__applyaction_id_16__pstorage[sizeof(ApplyAction<esphome__applyaction_id_16__fn>)];
static ApplyAction<esphome__applyaction_id_16__fn> *const applyaction_id_16 = reinterpret_cast<ApplyAction<esphome__applyaction_id_16__fn> *>(esphome__applyaction_id_16__pstorage);
static void esphome__applyaction_id_17__fn() {
  ::acquire_session->stop();
}
alignas(ApplyAction<esphome__applyaction_id_17__fn>) static unsigned char esphome__applyaction_id_17__pstorage[sizeof(ApplyAction<esphome__applyaction_id_17__fn>)];
static ApplyAction<esphome__applyaction_id_17__fn> *const applyaction_id_17 = reinterpret_cast<ApplyAction<esphome__applyaction_id_17__fn> *>(esphome__applyaction_id_17__pstorage);
static void esphome__applyaction_id_18__fn() {
  ::bootstrap->stop();
}
alignas(ApplyAction<esphome__applyaction_id_18__fn>) static unsigned char esphome__applyaction_id_18__pstorage[sizeof(ApplyAction<esphome__applyaction_id_18__fn>)];
static ApplyAction<esphome__applyaction_id_18__fn> *const applyaction_id_18 = reinterpret_cast<ApplyAction<esphome__applyaction_id_18__fn> *>(esphome__applyaction_id_18__pstorage);
static void esphome__applyaction_id_19__fn() {
  ::query_version->stop();
}
alignas(ApplyAction<esphome__applyaction_id_19__fn>) static unsigned char esphome__applyaction_id_19__pstorage[sizeof(ApplyAction<esphome__applyaction_id_19__fn>)];
static ApplyAction<esphome__applyaction_id_19__fn> *const applyaction_id_19 = reinterpret_cast<ApplyAction<esphome__applyaction_id_19__fn> *>(esphome__applyaction_id_19__pstorage);
static void esphome__applyaction_id_20__fn() {
  ::query_state->stop();
}
alignas(ApplyAction<esphome__applyaction_id_20__fn>) static unsigned char esphome__applyaction_id_20__pstorage[sizeof(ApplyAction<esphome__applyaction_id_20__fn>)];
static ApplyAction<esphome__applyaction_id_20__fn> *const applyaction_id_20 = reinterpret_cast<ApplyAction<esphome__applyaction_id_20__fn> *>(esphome__applyaction_id_20__pstorage);
alignas(StatelessLambdaAction<>) static unsigned char esphome__lambdaaction_id_18__pstorage[sizeof(StatelessLambdaAction<>)];
static StatelessLambdaAction<> *const lambdaaction_id_18 = reinterpret_cast<StatelessLambdaAction<> *>(esphome__lambdaaction_id_18__pstorage);
alignas(ble_client::BLEClientDisconnectAction<>) static unsigned char ble_client__ble_client_bleclientdisconnectaction_id__pstorage[sizeof(ble_client::BLEClientDisconnectAction<>)];
static ble_client::BLEClientDisconnectAction<> *const ble_client_bleclientdisconnectaction_id = reinterpret_cast<ble_client::BLEClientDisconnectAction<> *>(ble_client__ble_client_bleclientdisconnectaction_id__pstorage);
alignas(interval::IntervalTrigger) static unsigned char interval__interval_intervaltrigger_id_3__pstorage[sizeof(interval::IntervalTrigger)];
static interval::IntervalTrigger *const interval_intervaltrigger_id_3 = reinterpret_cast<interval::IntervalTrigger *>(interval__interval_intervaltrigger_id_3__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_33__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_33 = reinterpret_cast<Automation<> *>(esphome__automation_id_33__pstorage);
alignas(StatelessLambdaCondition<>) static unsigned char esphome__lambdacondition_id_16__pstorage[sizeof(StatelessLambdaCondition<>)];
static StatelessLambdaCondition<> *const lambdacondition_id_16 = reinterpret_cast<StatelessLambdaCondition<> *>(esphome__lambdacondition_id_16__pstorage);
static bool esphome__applycondition_id__fn() {
  return ::send_command->is_running();
}
alignas(ApplyCondition<esphome__applycondition_id__fn>) static unsigned char esphome__applycondition_id__pstorage[sizeof(ApplyCondition<esphome__applycondition_id__fn>)];
static ApplyCondition<esphome__applycondition_id__fn> *const applycondition_id = reinterpret_cast<ApplyCondition<esphome__applycondition_id__fn> *>(esphome__applycondition_id__pstorage);
alignas(NotCondition<>) static unsigned char esphome__notcondition_id__pstorage[sizeof(NotCondition<>)];
static NotCondition<> *const notcondition_id = reinterpret_cast<NotCondition<> *>(esphome__notcondition_id__pstorage);
static bool esphome__applycondition_id_2__fn() {
  return ::bootstrap->is_running();
}
alignas(ApplyCondition<esphome__applycondition_id_2__fn>) static unsigned char esphome__applycondition_id_2__pstorage[sizeof(ApplyCondition<esphome__applycondition_id_2__fn>)];
static ApplyCondition<esphome__applycondition_id_2__fn> *const applycondition_id_2 = reinterpret_cast<ApplyCondition<esphome__applycondition_id_2__fn> *>(esphome__applycondition_id_2__pstorage);
alignas(NotCondition<>) static unsigned char esphome__notcondition_id_2__pstorage[sizeof(NotCondition<>)];
static NotCondition<> *const notcondition_id_2 = reinterpret_cast<NotCondition<> *>(esphome__notcondition_id_2__pstorage);
alignas(AndCondition<3>) static unsigned char esphome__andcondition_id__pstorage[sizeof(AndCondition<3>)];
static AndCondition<3> *const andcondition_id = reinterpret_cast<AndCondition<3> *>(esphome__andcondition_id__pstorage);
alignas(IfAction<false>) static unsigned char esphome__ifaction_id_13__pstorage[sizeof(IfAction<false>)];
static IfAction<false> *const ifaction_id_13 = reinterpret_cast<IfAction<false> *>(esphome__ifaction_id_13__pstorage);
alignas(StatelessLambdaAction<>) static unsigned char esphome__lambdaaction_id_19__pstorage[sizeof(StatelessLambdaAction<>)];
static StatelessLambdaAction<> *const lambdaaction_id_19 = reinterpret_cast<StatelessLambdaAction<> *>(esphome__lambdaaction_id_19__pstorage);
alignas(script::ScriptExecuteAction<script::Script<>>) static unsigned char script__script_scriptexecuteaction_id_30__pstorage[sizeof(script::ScriptExecuteAction<script::Script<>>)];
static script::ScriptExecuteAction<script::Script<>> *const script_scriptexecuteaction_id_30 = reinterpret_cast<script::ScriptExecuteAction<script::Script<>> *>(script__script_scriptexecuteaction_id_30__pstorage);
alignas(interval::IntervalTrigger) static unsigned char interval__interval_intervaltrigger_id_4__pstorage[sizeof(interval::IntervalTrigger)];
static interval::IntervalTrigger *const interval_intervaltrigger_id_4 = reinterpret_cast<interval::IntervalTrigger *>(interval__interval_intervaltrigger_id_4__pstorage);
alignas(Automation<>) static unsigned char esphome__automation_id_34__pstorage[sizeof(Automation<>)];
static Automation<> *const automation_id_34 = reinterpret_cast<Automation<> *>(esphome__automation_id_34__pstorage);
alignas(StatelessLambdaAction<>) static unsigned char esphome__lambdaaction_id_20__pstorage[sizeof(StatelessLambdaAction<>)];
static StatelessLambdaAction<> *const lambdaaction_id_20 = reinterpret_cast<StatelessLambdaAction<> *>(esphome__lambdaaction_id_20__pstorage);
alignas(StatelessLambdaAction<std::string>) static unsigned char esphome__lambdaaction_id_21__pstorage[sizeof(StatelessLambdaAction<std::string>)];
static StatelessLambdaAction<std::string> *const lambdaaction_id_21 = reinterpret_cast<StatelessLambdaAction<std::string> *>(esphome__lambdaaction_id_21__pstorage);
alignas(StatelessLambdaAction<>) static unsigned char esphome__lambdaaction_id__pstorage[sizeof(StatelessLambdaAction<>)];
static StatelessLambdaAction<> *const lambdaaction_id = reinterpret_cast<StatelessLambdaAction<> *>(esphome__lambdaaction_id__pstorage);
#include <tuple>
static auto esphome_controllers() { return std::tuple{web_server_webserver_id, api_apiserver_id}; }
#include "esphome/core/controller_dispatch.h"
static constexpr size_t ESPHOME_LOOPING_COMPONENT_COUNT = \
  (1 * HasLoopOverride<logger::Logger>::value) + \
  (1 * HasLoopOverride<captive_portal::CaptivePortal>::value) + \
  (1 * HasLoopOverride<wifi::WiFiComponent>::value) + \
  (1 * HasLoopOverride<mdns::MDNSComponent>::value) + \
  (1 * HasLoopOverride<network::NetworkComponent>::value) + \
  (1 * HasLoopOverride<preferences::IntervalSyncer>::value) + \
  (1 * HasLoopOverride<safe_mode::SafeModeComponent>::value) + \
  (1 * HasLoopOverride<web_server::WebServerOTAComponent>::value) + \
  (1 * HasLoopOverride<web_server::WebServer>::value) + \
  (1 * HasLoopOverride<api::APIServer>::value) + \
  (1 * HasLoopOverride<StartupTrigger>::value) + \
  (1 * HasLoopOverride<esp32_ble_tracker::ESP32BLETracker>::value) + \
  (1 * HasLoopOverride<ble_client::BLEClient>::value) + \
  (2 * HasLoopOverride<script::ScriptWaitAction<script::SingleScript<>>>::value) + \
  (6 * HasLoopOverride<template_::TemplateTextSensor>::value) + \
  (1 * HasLoopOverride<wifi_info::IPAddressWiFiInfo>::value) + \
  (1 * HasLoopOverride<version::VersionTextSensor>::value) + \
  (1 * HasLoopOverride<ble_client::BLETextSensor>::value) + \
  (1 * HasLoopOverride<wifi_signal::WiFiSignalSensor>::value) + \
  (1 * HasLoopOverride<uptime::UptimeSecondsSensor>::value) + \
  (4 * HasLoopOverride<template_::TemplateSensor>::value) + \
  (1 * HasLoopOverride<status::StatusBinarySensor>::value) + \
  (8 * HasLoopOverride<template_::TemplateBinarySensor>::value) + \
  (5 * HasLoopOverride<template_::TemplateSwitch>::value) + \
  (1 * HasLoopOverride<template_::TemplateSelectWithSetAction<false, false, false, 3>>::value) + \
  (4 * HasLoopOverride<interval::IntervalTrigger>::value) + \
  (1 * HasLoopOverride<template_::TemplateText>::value) + \
  (1 * HasLoopOverride<esp32_ble::ESP32BLE>::value) + \
  (1 * HasLoopOverride<globals::RestoringGlobalStringComponent<std::string, 18>>::value) + \
  (3 * HasLoopOverride<globals::GlobalsComponent<uint32_t>>::value) + \
  (2 * HasLoopOverride<globals::GlobalsComponent<bool>>::value) + \
  (3 * HasLoopOverride<globals::GlobalsComponent<int>>::value) + \
  (1 * HasLoopOverride<WaitUntilAction<>>::value) + \
  (2 * HasLoopOverride<WaitUntilAction<int, int, int>>::value);
#include "sq9650_protocol.h"
#include "sq9650_session.h"
#include "public_config.h"
namespace esphome {
static const char COMP_SRC_TABLE_STR_0[] PROGMEM = "logger";
static const char COMP_SRC_TABLE_STR_1[] PROGMEM = "captive_portal";
static const char COMP_SRC_TABLE_STR_2[] PROGMEM = "wifi";
static const char COMP_SRC_TABLE_STR_3[] PROGMEM = "mdns";
static const char COMP_SRC_TABLE_STR_4[] PROGMEM = "network";
static const char COMP_SRC_TABLE_STR_5[] PROGMEM = "preferences";
static const char COMP_SRC_TABLE_STR_6[] PROGMEM = "safe_mode";
static const char COMP_SRC_TABLE_STR_7[] PROGMEM = "web_server.ota";
static const char COMP_SRC_TABLE_STR_8[] PROGMEM = "web_server";
static const char COMP_SRC_TABLE_STR_9[] PROGMEM = "api";
static const char COMP_SRC_TABLE_STR_10[] PROGMEM = "esphome.coroutine";
static const char COMP_SRC_TABLE_STR_11[] PROGMEM = "esp32_ble_tracker";
static const char COMP_SRC_TABLE_STR_12[] PROGMEM = "ble_client";
static const char COMP_SRC_TABLE_STR_13[] PROGMEM = "script";
static const char COMP_SRC_TABLE_STR_14[] PROGMEM = "template.text_sensor";
static const char COMP_SRC_TABLE_STR_15[] PROGMEM = "wifi_info.text_sensor";
static const char COMP_SRC_TABLE_STR_16[] PROGMEM = "version.text_sensor";
static const char COMP_SRC_TABLE_STR_17[] PROGMEM = "ble_client.text_sensor";
static const char COMP_SRC_TABLE_STR_18[] PROGMEM = "wifi_signal.sensor";
static const char COMP_SRC_TABLE_STR_19[] PROGMEM = "uptime.sensor";
static const char COMP_SRC_TABLE_STR_20[] PROGMEM = "template.sensor";
static const char COMP_SRC_TABLE_STR_21[] PROGMEM = "status.binary_sensor";
static const char COMP_SRC_TABLE_STR_22[] PROGMEM = "template.binary_sensor";
static const char COMP_SRC_TABLE_STR_23[] PROGMEM = "template.switch";
static const char COMP_SRC_TABLE_STR_24[] PROGMEM = "template.select";
static const char COMP_SRC_TABLE_STR_25[] PROGMEM = "interval";
static const char COMP_SRC_TABLE_STR_26[] PROGMEM = "template.text";
static const char COMP_SRC_TABLE_STR_27[] PROGMEM = "esp32_ble";
static const char COMP_SRC_TABLE_STR_28[] PROGMEM = "globals";
static const char *const COMP_SRC_TABLE[] PROGMEM = {COMP_SRC_TABLE_STR_0, COMP_SRC_TABLE_STR_1, COMP_SRC_TABLE_STR_2, COMP_SRC_TABLE_STR_3, COMP_SRC_TABLE_STR_4, COMP_SRC_TABLE_STR_5, COMP_SRC_TABLE_STR_6, COMP_SRC_TABLE_STR_7, COMP_SRC_TABLE_STR_8, COMP_SRC_TABLE_STR_9, COMP_SRC_TABLE_STR_10, COMP_SRC_TABLE_STR_11, COMP_SRC_TABLE_STR_12, COMP_SRC_TABLE_STR_13, COMP_SRC_TABLE_STR_14, COMP_SRC_TABLE_STR_15, COMP_SRC_TABLE_STR_16, COMP_SRC_TABLE_STR_17, COMP_SRC_TABLE_STR_18, COMP_SRC_TABLE_STR_19, COMP_SRC_TABLE_STR_20, COMP_SRC_TABLE_STR_21, COMP_SRC_TABLE_STR_22, COMP_SRC_TABLE_STR_23, COMP_SRC_TABLE_STR_24, COMP_SRC_TABLE_STR_25, COMP_SRC_TABLE_STR_26, COMP_SRC_TABLE_STR_27, COMP_SRC_TABLE_STR_28};
const LogString *component_source_lookup(uint8_t index) {
  if (index == 0 || index > 29) return LOG_STR("<unknown>");
  return reinterpret_cast<const LogString *>(
    progmem_read_ptr(&COMP_SRC_TABLE[index - 1]));
}
}  // namespace esphome
namespace esphome {
static const char ENTITY_DC_TABLE_STR_0[] PROGMEM = "signal_strength";
static const char ENTITY_DC_TABLE_STR_1[] PROGMEM = "duration";
static const char ENTITY_DC_TABLE_STR_2[] PROGMEM = "connectivity";
static const char ENTITY_DC_TABLE_EMPTY[] PROGMEM = "";
static const char *const ENTITY_DC_TABLE[] PROGMEM = {ENTITY_DC_TABLE_STR_0, ENTITY_DC_TABLE_STR_1, ENTITY_DC_TABLE_STR_2};
const char *entity_device_class_lookup(uint8_t index) {
  if (index == 0 || index > 3) return ENTITY_DC_TABLE_EMPTY;
  return progmem_read_ptr(&ENTITY_DC_TABLE[index - 1]);
}

static const char *const ENTITY_UOM_TABLE[] PROGMEM = {"dBm", "s"};
const char *entity_uom_lookup(uint8_t index) {
  if (index == 0 || index > 2) return "";
  return progmem_read_ptr(&ENTITY_UOM_TABLE[index - 1]);
}

static const char ENTITY_ICON_TABLE_STR_0[] PROGMEM = "mdi:new-box";
static const char ENTITY_ICON_TABLE_STR_1[] PROGMEM = "mdi:timer-outline";
static const char ENTITY_ICON_TABLE_EMPTY[] PROGMEM = "";
static const char *const ENTITY_ICON_TABLE[] PROGMEM = {ENTITY_ICON_TABLE_STR_0, ENTITY_ICON_TABLE_STR_1};
const char *entity_icon_lookup(uint8_t index) {
  if (index == 0 || index > 2) return ENTITY_ICON_TABLE_EMPTY;
  return progmem_read_ptr(&ENTITY_ICON_TABLE[index - 1]);
}

}  // namespace esphome
// ========== AUTO GENERATED INCLUDE BLOCK END ==========="

void setup() {
  // ========== AUTO GENERATED CODE BEGIN ===========
  // logger:
  //   baud_rate: 115200
  //   deassert_rts_dtr: true
  //   hardware_uart: USB_SERIAL_JTAG
  //   id: logger_logger_id
  //   level: INFO
  //   logs:
  //     esp32_ble_tracker: INFO
  //     text_sensor: WARN
  //   runtime_tag_levels: false
  //   task_log_buffer_size: 768
  //   tx_buffer_size: 512
  new(logger_logger_id) logger::Logger(115200);
  logger_logger_id->create_pthread_key();
  logger_logger_id->set_uart_selection(logger::UART_SELECTION_USB_SERIAL_JTAG);
  logger_logger_id->pre_setup();
  logger_logger_id->set_log_level(ESPHOME_LOG_LEVEL_INFO);
  // network:
  //   enable_ipv6: false
  //   id: network_networkcomponent_id
  //   min_ipv6_addr_count: 0
  // esphome:
  //   areas: []
  //   build_flags: []
  //   build_path: build\jomoo-bridge
  //   debug_scheduler: false
  //   devices: []
  //   environment_variables: {}
  //   friendly_name: JOMOO SQ9650
  //   includes:
  //     - F:\CodeX\jomoo-capture\esp32\public-build\sq9650_protocol.h
  //     - F:\CodeX\jomoo-capture\esp32\public-build\sq9650_session.h
  //     - F:\CodeX\jomoo-capture\esp32\public-build\public_config.h
  //   includes_c: []
  //   libraries: []
  //   merge_warnings: true
  //   min_version: 2026.10.0
  //   name: jomoo-bridge
  //   name_add_mac_suffix: true
  //   on_boot:
  //     - automation_id: automation_id
  //       priority: -100.0
  //       then:
  //         - lambda: !lambda |-
  //             id(target_mac).publish_state(id(configured_mac));
  //             uint64_t addr=0;
  //             if(sq9650::parse_mac(id(configured_mac),addr)) id(sq9650_client).set_address(addr);
  //           type_id: lambdaaction_id
  //       trigger_id: startuptrigger_id
  //   platformio_options: {}
  //   suspend_loop: false
  new (&App) Application;
  App.pre_setup(esphome_app_name_buf, 19, esphome_app_friendly_name_buf, 19);
  App.looping_components_.init(ESPHOME_LOOPING_COMPONENT_COUNT);
  // text_sensor:
  // sensor:
  // binary_sensor:
  // switch:
  // select:
  // button:
  // text:
  logger_logger_id->set_log_level("esp32_ble_tracker", ESPHOME_LOG_LEVEL_INFO);
  logger_logger_id->set_log_level("text_sensor", ESPHOME_LOG_LEVEL_WARN);
  App.register_component_(logger_logger_id, 1);
  // web_server_base:
  //   id: web_server_base_webserverbase_id
  new(web_server_base_webserverbase_id) web_server_base::WebServerBase();
  web_server_base::global_web_server_base = web_server_base_webserverbase_id;
  // captive_portal:
  //   compression: gzip
  //   id: captive_portal_captiveportal_id
  //   web_server_base_id: web_server_base_webserverbase_id
  new(captive_portal_captiveportal_id) captive_portal::CaptivePortal(web_server_base_webserverbase_id);
  App.register_component_(captive_portal_captiveportal_id, 2);
  // wifi:
  //   ap:
  //     ap_timeout: 90s
  //     id: wifi_wifiap_id
  //     ssid: \033[8mJomoo-Setup\033[28m
  //   domain: .local
  //   enable_btm: false
  //   enable_on_boot: true
  //   enable_rrm: false
  //   fast_connect:
  //     enabled: false
  //     storage: flash
  //   id: wifi_wificomponent_id
  //   min_auth_mode: WPA2
  //   passive_scan: false
  //   post_connect_roaming: true
  //   power_save_mode: LIGHT
  //   reboot_timeout: 0s
  //   use_address: jomoo-bridge.local
  new(wifi_wificomponent_id) wifi::WiFiComponent();
  {
  wifi::WiFiAP wifi_wifiap_id = wifi::WiFiAP();
  wifi_wifiap_id.set_ssid("Jomoo-Setup");
  wifi_wificomponent_id->set_ap(wifi_wifiap_id);
  }
  wifi_wificomponent_id->set_reboot_timeout(0);
  wifi_wificomponent_id->set_power_save_mode(wifi::WIFI_POWER_SAVE_LIGHT);
  App.register_component_(wifi_wificomponent_id, 3);
  // mdns:
  //   disabled: false
  //   id: mdns_mdnscomponent_id
  //   services: []
  new(mdns_mdnscomponent_id) mdns::MDNSComponent();
  App.register_component_(mdns_mdnscomponent_id, 4);
  new(network_networkcomponent_id) network::NetworkComponent();
  App.register_component_(network_networkcomponent_id, 5);
  // ota:
  // ota.web_server:
  //   id: web_server_webserverotacomponent_id
  //   platform: web_server
  new(web_server_webserverotacomponent_id) web_server::WebServerOTAComponent();
  // preferences:
  //   flash_write_interval: 60s
  //   id: preferences_intervalsyncer_id
  new(preferences_intervalsyncer_id) preferences::IntervalSyncer();
  preferences_intervalsyncer_id->set_update_interval(60000);
  App.register_component_(preferences_intervalsyncer_id, 6);
  // safe_mode:
  //   boot_is_good_after: 1min
  //   boot_is_good_on_shutdown: true
  //   disabled: false
  //   id: safe_mode_safemodecomponent_id
  //   num_attempts: 10
  //   reboot_timeout: 5min
  //   storage: flash
  new(safe_mode_safemodecomponent_id) safe_mode::SafeModeComponent();
  App.register_component_(safe_mode_safemodecomponent_id, 7);
  if (safe_mode_safemodecomponent_id->should_enter_safe_mode(10, 300000, 60000, true)) return;
  App.register_component_(web_server_webserverotacomponent_id, 8);
  // web_server:
  //   compression: gzip
  //   css_url: ''
  //   enable_private_network_access: false
  //   id: web_server_webserver_id
  //   include_internal: false
  //   js_url: https:oi.esphome.io/v3/www.js
  //   local: true
  //   log: true
  //   ota: false
  //   port: 80
  //   version: 3
  //   web_server_base_id: web_server_base_webserverbase_id
  new(web_server_webserver_id) web_server::WebServer(web_server_base_webserverbase_id);
  App.register_component_(web_server_webserver_id, 9);
  // api:
  //   batch_delay: 100ms
  //   custom_services: false
  //   homeassistant_services: false
  //   homeassistant_states: false
  //   id: api_apiserver_id
  //   listen_backlog: 4
  //   max_connections: 5
  //   max_send_queue: 8
  //   port: 6053
  //   reboot_timeout: 0s
  new(api_apiserver_id) api::APIServer();
  App.register_component_(api_apiserver_id, 10);
  api_apiserver_id->set_reboot_timeout(0);
  new(startuptrigger_id) StartupTrigger(-100.0f);
  App.register_component_(startuptrigger_id, 11);
  new(automation_id) Automation<>(startuptrigger_id);
  // json:
  //   {}
  // esp32:
  //   board: esp32-c3
  //   cpu_frequency: 160MHZ
  //   flash_size: 4MB
  //   framework:
  //     advanced:
  //       adc_oneshot_in_iram: false
  //       compiler_optimization: SIZE
  //       disable_debug_stubs: true
  //       disable_dev_null_vfs: true
  //       disable_fatfs: true
  //       disable_libc_locks_in_iram: true
  //       disable_mbedtls_peer_cert: true
  //       disable_mbedtls_pkcs7: true
  //       disable_mbedtls_tls: true
  //       disable_mbedtls_tls_extras: true
  //       disable_mbedtls_tls_server: true
  //       disable_ocd_aware: true
  //       disable_regi2c_in_iram: true
  //       disable_usb_serial_jtag_secondary: true
  //       disable_vfs_support_dir: true
  //       disable_vfs_support_select: true
  //       disable_vfs_support_termios: true
  //       enable_full_printf: false
  //       enable_idf_experimental_features: false
  //       enable_lwip_assert: true
  //       enable_lwip_bridge_interface: false
  //       enable_lwip_check_thread_safety: true
  //       enable_lwip_mdns_queries: true
  //       enable_lwip_tcpip_core_locking: true
  //       enable_ota_downgrade_protection: false
  //       enable_ota_rollback: true
  //       execute_from_psram: false
  //       freertos_in_iram: false
  //       heap_in_iram: false
  //       ignore_efuse_custom_mac: false
  //       ignore_efuse_mac_crc: false
  //       include_builtin_idf_components: []
  //       loop_task_stack_size: 8192
  //       ringbuf_in_iram: false
  //       sram1_as_iram: false
  //       use_full_certificate_bundle: false
  //     components: []
  //     log_level: ERROR
  //     sdkconfig_options: {}
  //     type: esp-idf
  //     version: 5.5.6
  //   variant: ESP32C3
  //   watchdog_timeout: 5s
  // esp32_ble_tracker:
  //   ble_id: esp32_ble_esp32ble_id
  //   id: esp32_ble_tracker_esp32bletracker_id
  //   scan_parameters:
  //     active: true
  //     continuous: false
  //     duration: 30s
  //     interval: 320ms
  //     window: 60ms
  //   software_coexistence: true
  new(esp32_ble_tracker_esp32bletracker_id) esp32_ble_tracker::ESP32BLETracker();
  App.register_component_(esp32_ble_tracker_esp32bletracker_id, 12);
  // ble_client:
  //   auto_connect: false
  //   esp32_ble_id: esp32_ble_tracker_esp32bletracker_id
  //   id: sq9650_client
  //   mac_address: 00:00:00:00:00:00
  //   on_connect:
  //     - automation_id: automation_id_2
  //       then:
  //         - lambda: !lambda |-
  //             if(!sq9650::session.active){id(sq9650_client).disconnect();return;}
  //             sq9650::bridge.connect();
  //             id(command_pending)=false;
  //             id(state_description).publish_state("蓝牙已连接，等待读回状态");
  //             id(command_result).publish_state("重连仅查询，不重放控制");
  //           type_id: lambdaaction_id_2
  //         - script.execute:
  //             id: bootstrap
  //           type_id: script_scriptexecuteaction_id
  //       trigger_id: ble_client_bleclientconnecttrigger_id
  //   on_disconnect:
  //     - automation_id: automation_id_3
  //       then:
  //         - esp32_ble_tracker.stop_scan:
  //             id: esp32_ble_tracker_esp32bletracker_id
  //           type_id: applyaction_id
  //         - script.stop:
  //             id: send_command
  //           type_id: applyaction_id_2
  //         - script.stop:
  //             id: acquire_session
  //           type_id: applyaction_id_3
  //         - script.stop:
  //             id: query_version
  //           type_id: applyaction_id_4
  //         - script.stop:
  //             id: query_state
  //           type_id: applyaction_id_5
  //         - script.stop:
  //             id: bootstrap
  //           type_id: applyaction_id_6
  //         - lambda: !lambda |-
  //             sq9650::session.cancel();
  //             sq9650::bridge.disconnect();
  //             if(id(command_pending)) id(command_result).publish_state("连接断开，命令未确认且不重放");
  //             id(command_pending)=false;
  //             id(state_description).publish_state("蓝牙离线，显示值为历史值");
  //           type_id: lambdaaction_id_3
  //       trigger_id: ble_client_bleclientdisconnecttrigger_id
  new(sq9650_client) ble_client::BLEClient();
  App.register_component_(sq9650_client, 13);
  esp32_ble_tracker_esp32bletracker_id->register_client(sq9650_client);
  sq9650_client->set_address(0x000000000000ULL);
  sq9650_client->set_auto_connect(false);
  new(ble_client_bleclientconnecttrigger_id) ble_client::BLEClientConnectTrigger(sq9650_client);
  new(automation_id_2) Automation<>(ble_client_bleclientconnecttrigger_id);
  // script:
  //   - automation_id: automation_id_4
  //     id: query_state
  //     mode: single
  //     parameters: {}
  //     then:
  //       - if:
  //           condition:
  //             lambda: !lambda |-
  //               return sq9650::bridge.connected;
  //             type_id: lambdacondition_id
  //           then:
  //             - ble_client.ble_write:
  //                 characteristic_uuid: FFE1
  //                 id: sq9650_client
  //                 service_uuid: FFE0
  //                 value:
  //                   - 0xFC
  //                   - 0x12
  //                   - 0x01
  //                   - 0x00
  //                   - 0x00
  //                   - 0x00
  //                   - 0x11
  //                   - 0x00
  //                   - 0xFC
  //               type_id: ble_client_bleclientwriteaction_id
  //         type_id: ifaction_id
  //     trigger_id: trigger_id
  //   - automation_id: automation_id_5
  //     id: query_version
  //     mode: single
  //     parameters: {}
  //     then:
  //       - if:
  //           condition:
  //             lambda: !lambda |-
  //               return sq9650::bridge.connected;
  //             type_id: lambdacondition_id_2
  //           then:
  //             - ble_client.ble_write:
  //                 characteristic_uuid: FFE1
  //                 id: sq9650_client
  //                 service_uuid: FFE0
  //                 value:
  //                   - 0xFC
  //                   - 0x02
  //                   - 0x01
  //                   - 0x00
  //                   - 0x00
  //                   - 0x00
  //                   - 0x01
  //                   - 0x00
  //                   - 0xFC
  //               type_id: ble_client_bleclientwriteaction_id_2
  //         type_id: ifaction_id_2
  //     trigger_id: trigger_id_2
  //   - automation_id: automation_id_6
  //     id: bootstrap
  //     mode: restart
  //     parameters: {}
  //     then:
  //       - delay: 2s
  //         type_id: delayaction_id
  //       - script.execute:
  //           id: query_state
  //         type_id: script_scriptexecuteaction_id_2
  //       - script.wait:
  //           id: query_state
  //         type_id: script_scriptwaitaction_id
  //       - delay: 1s
  //         type_id: delayaction_id_2
  //       - script.execute:
  //           id: query_version
  //         type_id: script_scriptexecuteaction_id_3
  //     trigger_id: trigger_id_3
  //   - automation_id: automation_id_7
  //     id: reconnect_ble
  //     mode: single
  //     parameters: {}
  //     then:
  //       - if:
  //           condition:
  //             lambda: !lambda |-
  //               return id(command_pending) || id(send_command).is_running() || (sq9650::bridge.fresh(millis()) && (sq9650::bridge.state.motion || sq9650::bridge.state.flush || sq9650::bridge.state.bubble));
  //             type_id: lambdacondition_id_3
  //           then:
  //             - lambda: !lambda |-
  //                 id(command_result).publish_state("拒绝：动作或请求处理中，暂不重连");
  //               type_id: lambdaaction_id_4
  //             - script.stop:
  //                 id: reconnect_ble
  //               type_id: applyaction_id_7
  //         type_id: ifaction_id_3
  //       - script.stop:
  //           id: acquire_session
  //         type_id: applyaction_id_8
  //       - script.stop:
  //           id: bootstrap
  //         type_id: applyaction_id_9
  //       - script.stop:
  //           id: query_state
  //         type_id: applyaction_id_10
  //       - script.stop:
  //           id: query_version
  //         type_id: applyaction_id_11
  //       - lambda: !lambda |-
  //           sq9650::session.cancel();
  //           sq9650::bridge.disconnect();
  //           id(state_valid).publish_state(false);
  //           id(sq9650_client).disconnect();
  //         type_id: lambdaaction_id_5
  //       - type_id: waituntilaction_id
  //         wait_until:
  //           condition:
  //             lambda: !lambda |-
  //               return id(sq9650_client).state()==esphome::esp32_ble_tracker::ClientState::IDLE;
  //             type_id: lambdacondition_id_4
  //           timeout: 5s
  //       - if:
  //           condition:
  //             lambda: !lambda |-
  //               return id(sq9650_client).state()==esphome::esp32_ble_tracker::ClientState::IDLE;
  //             type_id: lambdacondition_id_5
  //           else:
  //             - lambda: !lambda |-
  //                 id(command_result).publish_state("断开连接超时，未重连、不重放");
  //               type_id: lambdaaction_id_6
  //           then:
  //             - script.execute:
  //                 id: acquire_session
  //               type_id: script_scriptexecuteaction_id_4
  //         type_id: ifaction_id_4
  //     trigger_id: trigger_id_4
  //   - automation_id: automation_id_8
  //     id: acquire_session
  //     mode: single
  //     parameters: {}
  //     then:
  //       - if:
  //           condition:
  //             lambda: !lambda |-
  //               uint64_t addr=0;
  //               return !sq9650::parse_mac(id(configured_mac),addr);
  //             type_id: lambdacondition_id_6
  //           then:
  //             - lambda: !lambda |-
  //                 id(command_result).publish_state("请先配置马桶蓝牙地址");
  //               type_id: lambdaaction_id_7
  //             - script.stop:
  //                 id: acquire_session
  //               type_id: applyaction_id_12
  //         type_id: ifaction_id_5
  //       - if:
  //           condition:
  //             lambda: !lambda |-
  //               return id(command_pending);
  //             type_id: lambdacondition_id_7
  //           then:
  //             - lambda: !lambda |-
  //                 id(command_result).publish_state("拒绝：命令处理中，会话不变");
  //               type_id: lambdaaction_id_8
  //             - script.stop:
  //                 id: acquire_session
  //               type_id: applyaction_id_13
  //         type_id: ifaction_id_6
  //       - lambda: !lambda |-
  //           sq9650::session.request(millis()); sq9650::session.retry=millis(); sq9650::bridge.have_state=false; id(state_valid).publish_state(false);
  //         type_id: lambdaaction_id_9
  //       - if:
  //           condition:
  //             lambda: !lambda |-
  //               return !sq9650::bridge.connected;
  //             type_id: lambdacondition_id_8
  //           then:
  //             - ble_client.connect:
  //                 id: sq9650_client
  //               type_id: ble_client_bleclientconnectaction_id
  //         type_id: ifaction_id_7
  //       - script.execute:
  //           id: query_state
  //         type_id: script_scriptexecuteaction_id_5
  //     trigger_id: trigger_id_5
  //   - automation_id: automation_id_9
  //     id: send_command
  //     mode: single
  //     parameters:
  //       arg: int
  //       cmd: int
  //       index: int
  //     then:
  //       - if:
  //           condition:
  //             lambda: !lambda |-
  //               return id(command_pending);
  //             type_id: lambdacondition_id_9
  //           then:
  //             - lambda: !lambda |-
  //                 id(command_result).publish_state("拒绝：上个命令仍等待读回");
  //               type_id: lambdaaction_id_10
  //             - script.stop:
  //                 id: send_command
  //               type_id: applyaction_id_14
  //         type_id: ifaction_id_8
  //       - lambda: !lambda |-
  //           id(accepted)=false; id(command_started)=millis();
  //         type_id: lambdaaction_id_11
  //       - script.execute:
  //           id: acquire_session
  //         type_id: script_scriptexecuteaction_id_6
  //       - type_id: waituntilaction_id_2
  //         wait_until:
  //           condition:
  //             lambda: !lambda |-
  //               return sq9650::bridge.connected;
  //             type_id: lambdacondition_id_10
  //           timeout: 30s
  //       - lambda: !lambda |-
  //           sq9650::session.sequence=sq9650::bridge.state_sequence; sq9650::bridge.have_state=false; id(state_valid).publish_state(false);
  //         type_id: lambdaaction_id_12
  //       - script.execute:
  //           id: query_state
  //         type_id: script_scriptexecuteaction_id_7
  //       - type_id: waituntilaction_id_3
  //         wait_until:
  //           condition:
  //             lambda: !lambda |-
  //               return sq9650::bridge.state_sequence!=sq9650::session.sequence;
  //             type_id: lambdacondition_id_11
  //           timeout: 5s
  //       - lambda: !lambda |-
  //           id(accepted)=false;
  //           if(!sq9650::session.active || uint32_t(millis()-id(command_started))>=30000 || sq9650::bridge.state_sequence==sq9650::session.sequence) {id(command_result).publish_state("获取新鲜状态超时或会话取消，未发送，不重试");return;}
  //           if(cmd!=0x35 && cmd!=0x46 && sq9650::bridge.matches(cmd,arg,index)) {id(command_result).publish_state("已达到目标，未重复下发");return;}
  //           if(id(command_pending)) {
  //             id(command_result).publish_state("拒绝：上个命令仍等待读回");
  //             return;
  //           }
  //           const char *reason=sq9650::bridge.reject(cmd,arg,index,millis());
  //           if(reason) {
  //             id(command_result).publish_state(std::string("拒绝：")+reason);
  //             ESP_LOGW("sq9650", "REJECT cmd=%02X reason=%s",cmd,reason);
  //             return;
  //           }
  //           id(accepted)=true;
  //           id(pending_cmd)=cmd;id(pending_value)=arg;id(pending_index)=index;
  //           id(sent_at)=millis();id(sent_sequence)=sq9650::bridge.state_sequence;
  //           id(command_pending)=true;
  //           sq9650::bridge.sent(cmd,millis());
  //           sq9650::session.sent(millis());
  //           id(command_result).publish_state("请求发送，等待设备状态回读");
  //           ESP_LOGI("sq9650", "REQUEST cmd=%02X arg=%d index=%d",cmd,arg,index);
  //         type_id: lambdaaction_id_13
  //       - if:
  //           condition:
  //             lambda: !lambda |-
  //               return id(accepted);
  //             type_id: lambdacondition_id_12
  //           then:
  //             - ble_client.ble_write:
  //                 characteristic_uuid: FFE1
  //                 id: sq9650_client
  //                 service_uuid: FFE0
  //                 value: !lambda |-
  //                   auto f=sq9650::command(cmd,arg,index);
  //                   return std::vector<uint8_t>(f.data,f.data+f.size);
  //               type_id: ble_client_bleclientwriteaction_id_3
  //             - delay: 800ms
  //               type_id: delayaction_id_3
  //             - script.execute:
  //                 id: query_state
  //               type_id: script_scriptexecuteaction_id_8
  //         type_id: ifaction_id_9
  //     trigger_id: trigger_id_6
  new(query_state) script::SingleScript<>();
  query_state->set_name(LOG_STR("query_state"));
  new(query_version) script::SingleScript<>();
  query_version->set_name(LOG_STR("query_version"));
  new(bootstrap) script::RestartScript<>();
  bootstrap->set_name(LOG_STR("bootstrap"));
  new(reconnect_ble) script::SingleScript<>();
  reconnect_ble->set_name(LOG_STR("reconnect_ble"));
  new(acquire_session) script::SingleScript<>();
  acquire_session->set_name(LOG_STR("acquire_session"));
  new(send_command) script::SingleScript<int, int, int>();
  send_command->set_name(LOG_STR("send_command"));
  new(automation_id_4) Automation<>(query_state);
  new(lambdacondition_id) StatelessLambdaCondition<>([]() -> bool {
      #line 125 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      return sq9650::bridge.connected;
  });
  new(ifaction_id) IfAction<false>(lambdacondition_id);
  new(ble_client_bleclientwriteaction_id) ble_client::BLEClientWriteAction<>(sq9650_client);
  static const uint8_t ble_client_bleclientwriteaction_id_data[] = {0xFC, 0x12, 0x01, 0x00, 0x00, 0x00, 0x11, 0x00, 0xFC};
  ble_client_bleclientwriteaction_id->set_value_simple(ble_client_bleclientwriteaction_id_data, 9);
  ble_client_bleclientwriteaction_id->set_service_uuid16(0xFFE0ULL);
  ble_client_bleclientwriteaction_id->set_char_uuid16(0xFFE1ULL);
  ifaction_id->add_then({ble_client_bleclientwriteaction_id});
  automation_id_4->add_actions({ifaction_id});
  new(automation_id_5) Automation<>(query_version);
  new(lambdacondition_id_2) StatelessLambdaCondition<>([]() -> bool {
      #line 137 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      return sq9650::bridge.connected;
  });
  new(ifaction_id_2) IfAction<false>(lambdacondition_id_2);
  new(ble_client_bleclientwriteaction_id_2) ble_client::BLEClientWriteAction<>(sq9650_client);
  static const uint8_t ble_client_bleclientwriteaction_id_2_data[] = {0xFC, 0x02, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0xFC};
  ble_client_bleclientwriteaction_id_2->set_value_simple(ble_client_bleclientwriteaction_id_2_data, 9);
  ble_client_bleclientwriteaction_id_2->set_service_uuid16(0xFFE0ULL);
  ble_client_bleclientwriteaction_id_2->set_char_uuid16(0xFFE1ULL);
  ifaction_id_2->add_then({ble_client_bleclientwriteaction_id_2});
  automation_id_5->add_actions({ifaction_id_2});
  new(automation_id_6) Automation<>(bootstrap);
  new(delayaction_id) DelayAction<>();
  delayaction_id->set_delay([]() -> uint32_t {
      return 2000;
  });
  new(script_scriptexecuteaction_id_2) script::ScriptExecuteAction<script::Script<>>(query_state);
  script_scriptexecuteaction_id_2->set_args();
  new(script_scriptwaitaction_id) script::ScriptWaitAction<script::SingleScript<>>(query_state);
  App.register_component_(script_scriptwaitaction_id, 14);
  new(delayaction_id_2) DelayAction<>();
  delayaction_id_2->set_delay([]() -> uint32_t {
      return 1000;
  });
  new(script_scriptexecuteaction_id_3) script::ScriptExecuteAction<script::Script<>>(query_version);
  script_scriptexecuteaction_id_3->set_args();
  automation_id_6->add_actions({delayaction_id, script_scriptexecuteaction_id_2, script_scriptwaitaction_id, delayaction_id_2, script_scriptexecuteaction_id_3});
  new(automation_id_7) Automation<>(reconnect_ble);
  // text_sensor.template:
  //   disabled_by_default: false
  //   id: connection_mode
  //   lambda: !lambda |-
  //     return sq9650::bridge.connected ? std::string("已连接") : std::string("蓝牙待命；显示历史值");
  //   name: 蓝牙会话模式 Connection Mode
  //   platform: template
  //   update_interval: 5s
  new(connection_mode) template_::TemplateTextSensor();
  App.register_text_sensor(connection_mode, "\350\223\235\347\211\231\344\274\232\350\257\235\346\250\241\345\274\217 Connection Mode", 1157347676, 0);
  connection_mode->set_update_interval(5000);
  App.register_component_(connection_mode, 15);
  connection_mode->set_template([]() -> std::optional<std::string> {
      #line 270 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      return sq9650::bridge.connected ? std::string("已连接") : std::string("蓝牙待命；显示历史值");
  });
  // text_sensor.wifi_info:
  //   ip_address:
  //     disabled_by_default: false
  //     entity_category: diagnostic
  //     id: wifi_info_ipaddresswifiinfo_id
  //     name: IP Address
  //   platform: wifi_info
  new(wifi_info_ipaddresswifiinfo_id) wifi_info::IPAddressWiFiInfo();
  App.register_text_sensor(wifi_info_ipaddresswifiinfo_id, "IP Address", 3849966195UL, 134217728);  // category:diagnostic
  App.register_component_(wifi_info_ipaddresswifiinfo_id, 16);
  // text_sensor.version:
  //   disabled_by_default: false
  //   entity_category: diagnostic
  //   hide_hash: false
  //   hide_timestamp: false
  //   icon: mdi:new-box
  //   id: version_versiontextsensor_id
  //   name: ESPHome Version
  //   platform: version
  new(version_versiontextsensor_id) version::VersionTextSensor();
  App.register_text_sensor(version_versiontextsensor_id, "ESPHome Version", 2314437119UL, 134283264);  // category:diagnostic, icon:mdi:new-box
  App.register_component_(version_versiontextsensor_id, 17);
  // text_sensor.template:
  //   disabled_by_default: false
  //   id: state_description
  //   name: 马桶状态时效 State Freshness
  //   platform: template
  //   update_interval: 4294967295ms
  new(state_description) template_::TemplateTextSensor();
  App.register_text_sensor(state_description, "\351\251\254\346\241\266\347\212\266\346\200\201\346\227\266\346\225\210 State Freshness", 1450095485, 0);
  state_description->set_update_interval(4294967295UL);
  App.register_component_(state_description, 15);
  // text_sensor.template:
  //   disabled_by_default: false
  //   id: command_result
  //   name: 最近命令结果 Command Result
  //   platform: template
  //   update_interval: 4294967295ms
  new(command_result) template_::TemplateTextSensor();
  App.register_text_sensor(command_result, "\346\234\200\350\277\221\345\221\275\344\273\244\347\273\223\346\236\234 Command Result", 1829949871, 0);
  command_result->set_update_interval(4294967295UL);
  App.register_component_(command_result, 15);
  // text_sensor.template:
  //   disabled_by_default: false
  //   entity_category: diagnostic
  //   id: hardware_version
  //   name: 马桶硬件版本 Hardware Version
  //   platform: template
  //   update_interval: 4294967295ms
  new(hardware_version) template_::TemplateTextSensor();
  App.register_text_sensor(hardware_version, "\351\251\254\346\241\266\347\241\254\344\273\266\347\211\210\346\234\254 Hardware Version", 1786551175, 134217728);  // category:diagnostic
  hardware_version->set_update_interval(4294967295UL);
  App.register_component_(hardware_version, 15);
  // text_sensor.template:
  //   disabled_by_default: false
  //   entity_category: diagnostic
  //   id: mcu_version
  //   name: 马桶主板版本 MCU Version
  //   platform: template
  //   update_interval: 4294967295ms
  new(mcu_version) template_::TemplateTextSensor();
  App.register_text_sensor(mcu_version, "\351\251\254\346\241\266\344\270\273\346\235\277\347\211\210\346\234\254 MCU Version", 366709662, 134217728);  // category:diagnostic
  mcu_version->set_update_interval(4294967295UL);
  App.register_component_(mcu_version, 15);
  // text_sensor.template:
  //   disabled_by_default: false
  //   entity_category: diagnostic
  //   id: raw_status
  //   name: 原始状态帧 Raw State
  //   platform: template
  //   update_interval: 4294967295ms
  new(raw_status) template_::TemplateTextSensor();
  App.register_text_sensor(raw_status, "\345\216\237\345\247\213\347\212\266\346\200\201\345\270\247 Raw State", 3716131201UL, 134217728);  // category:diagnostic
  raw_status->set_update_interval(4294967295UL);
  App.register_component_(raw_status, 15);
  // text_sensor.ble_client:
  //   ble_client_id: sq9650_client
  //   characteristic_uuid: FFE1
  //   disabled_by_default: false
  //   id: sq9650_raw
  //   internal: true
  //   name: sq9650_raw
  //   notify: true
  //   on_notify:
  //     - automation_id: automation_id_10
  //       then:
  //         - lambda: !lambda |-
  //             for (uint8_t byte:x) {
  //               auto before=sq9650::bridge.state_sequence;
  //               if(!sq9650::bridge.ingest(byte,millis())) continue;
  //               auto &frame=sq9650::bridge.parser.frame;
  //               if(sq9650::bridge.state_sequence!=before) {
  //                 sq9650::session.acquired(millis());
  //                 const auto &s=sq9650::bridge.state;
  //                 id(lid_open).publish_state(s.lid);
  //                 id(ring_open).publish_state(s.ring);
  //                 id(occupied).publish_state(s.occupied);
  //                 id(moving).publish_state(s.motion!=0);
  //                 id(water_ready).publish_state(s.ready);
  //                 id(foam_running).publish_state(s.bubble);
  //                 id(night_light).publish_state(s.night);
  //                 id(foot_sensor).publish_state(s.foot);
  //                 id(auto_night).publish_state(s.light_sensor);
  //                 id(seat_level_raw).publish_state(s.seat);
  //                 id(work_state_raw).publish_state(s.work);
  //                 id(flush_kind).publish_state(s.flush);
  //                 id(seat_temperature).publish_state(s.seat==0?"常温":s.seat==3?"中温":s.seat==5?"高温":"未知");
  //                 if(uint32_t(millis()-sq9650::session.raw)>=60000){sq9650::session.raw=millis();id(raw_status).publish_state(format_hex_pretty(frame.data,frame.size));}
  //                 if(s.work==1) id(state_description).publish_state("休眠，状态有效");
  //                 else if(s.motion || s.flush || s.bubble || s.work!=2) id(state_description).publish_state("状态有效，设备忙碌");
  //                 else id(state_description).publish_state("状态有效，正常待机");
  //                 if(id(command_pending) && sq9650::bridge.state_sequence!=id(sent_sequence) &&
  //                    sq9650::bridge.matches(id(pending_cmd),id(pending_value),id(pending_index))) {
  //                   id(command_pending)=false;
  //                   sq9650::session.completed(millis(),sq9650::bridge.state.motion || sq9650::bridge.state.flush || sq9650::bridge.state.bubble);
  //                   id(command_result).publish_state("设备回读已匹配目标；动作效果请按现场确认");
  //                 }
  //               } else {
  //                 sq9650::Version v;
  //                 if(sq9650::decode_version(frame,v)) {
  //                   id(hardware_version).publish_state(v.hardware);
  //                   id(mcu_version).publish_state(v.firmware);
  //                 }
  //               }
  //             }
  //           type_id: lambdaaction_id_14
  //       trigger_id: ble_client_bletextsensornotifytrigger_id
  //   platform: ble_client
  //   service_uuid: FFE0
  //   update_interval: 4294967295ms
  new(sq9650_raw) ble_client::BLETextSensor();
  App.register_text_sensor(sq9650_raw, "sq9650_raw", 3617572812UL, 16777216);  // internal
  sq9650_raw->set_service_uuid16(0xFFE0ULL);
  sq9650_raw->set_char_uuid16(0xFFE1ULL);
  sq9650_raw->set_update_interval(4294967295UL);
  App.register_component_(sq9650_raw, 18);
  sq9650_client->register_ble_node(sq9650_raw);
  sq9650_raw->set_enable_notify(true);
  new(ble_client_bletextsensornotifytrigger_id) ble_client::BLETextSensorNotifyTrigger(sq9650_raw);
  sq9650_client->register_ble_node(ble_client_bletextsensornotifytrigger_id);
  new(automation_id_10) Automation<std::string>(ble_client_bletextsensornotifytrigger_id);
  // sensor.wifi_signal:
  //   accuracy_decimals: 0
  //   device_class: signal_strength
  //   disabled_by_default: false
  //   entity_category: diagnostic
  //   force_update: false
  //   id: wifi_signal_wifisignalsensor_id
  //   name: WiFi Signal
  //   platform: wifi_signal
  //   state_class: measurement
  //   unit_of_measurement: dBm
  //   update_interval: 30s
  new(wifi_signal_wifisignalsensor_id) wifi_signal::WiFiSignalSensor();
  wifi_signal_wifisignalsensor_id->set_state_class(sensor::STATE_CLASS_MEASUREMENT);
  wifi_signal_wifisignalsensor_id->set_accuracy_decimals(0);
  App.register_sensor(wifi_signal_wifisignalsensor_id, "WiFi Signal", 799351157, 134217985);  // category:diagnostic, dc:signal_strength, uom:dBm
  wifi_signal_wifisignalsensor_id->set_update_interval(30000);
  App.register_component_(wifi_signal_wifisignalsensor_id, 19);
  // sensor.uptime:
  //   accuracy_decimals: 0
  //   device_class: duration
  //   disabled_by_default: false
  //   entity_category: diagnostic
  //   force_update: false
  //   icon: mdi:timer-outline
  //   id: uptime_uptimesecondssensor_id
  //   name: Uptime
  //   platform: uptime
  //   state_class: total_increasing
  //   type: seconds
  //   unit_of_measurement: s
  //   update_interval: 30s
  new(uptime_uptimesecondssensor_id) uptime::UptimeSecondsSensor();
  uptime_uptimesecondssensor_id->set_state_class(sensor::STATE_CLASS_TOTAL_INCREASING);
  uptime_uptimesecondssensor_id->set_accuracy_decimals(0);
  App.register_sensor(uptime_uptimesecondssensor_id, "Uptime", 1324261225, 134349314);  // category:diagnostic, dc:duration, uom:s, icon:mdi:timer-outline
  uptime_uptimesecondssensor_id->set_update_interval(30000);
  App.register_component_(uptime_uptimesecondssensor_id, 20);
  // sensor.template:
  //   accuracy_decimals: 0
  //   disabled_by_default: false
  //   entity_category: diagnostic
  //   force_update: false
  //   id: seat_level_raw
  //   name: 座温档位原始值 Seat Level Raw
  //   platform: template
  //   update_interval: 4294967295ms
  new(seat_level_raw) template_::TemplateSensor();
  seat_level_raw->set_accuracy_decimals(0);
  App.register_sensor(seat_level_raw, "\345\272\247\346\270\251\346\241\243\344\275\215\345\216\237\345\247\213\345\200\274 Seat Level Raw", 3551596190UL, 134217728);  // category:diagnostic
  seat_level_raw->set_update_interval(4294967295UL);
  App.register_component_(seat_level_raw, 21);
  // sensor.template:
  //   accuracy_decimals: 0
  //   disabled_by_default: false
  //   entity_category: diagnostic
  //   force_update: false
  //   id: work_state_raw
  //   name: 工作状态原始值 Work State Raw
  //   platform: template
  //   update_interval: 4294967295ms
  new(work_state_raw) template_::TemplateSensor();
  work_state_raw->set_accuracy_decimals(0);
  App.register_sensor(work_state_raw, "\345\267\245\344\275\234\347\212\266\346\200\201\345\216\237\345\247\213\345\200\274 Work State Raw", 3624443131UL, 134217728);  // category:diagnostic
  work_state_raw->set_update_interval(4294967295UL);
  App.register_component_(work_state_raw, 21);
  // sensor.template:
  //   accuracy_decimals: 0
  //   disabled_by_default: false
  //   entity_category: diagnostic
  //   force_update: false
  //   id: flush_kind
  //   name: 冲水状态原始值 Flush Kind
  //   platform: template
  //   update_interval: 4294967295ms
  new(flush_kind) template_::TemplateSensor();
  flush_kind->set_accuracy_decimals(0);
  App.register_sensor(flush_kind, "\345\206\262\346\260\264\347\212\266\346\200\201\345\216\237\345\247\213\345\200\274 Flush Kind", 2902531290UL, 134217728);  // category:diagnostic
  flush_kind->set_update_interval(4294967295UL);
  App.register_component_(flush_kind, 21);
  // sensor.template:
  //   accuracy_decimals: 0
  //   disabled_by_default: false
  //   entity_category: diagnostic
  //   force_update: false
  //   id: template__templatesensor_id
  //   lambda: !lambda |-
  //     if(!sq9650::bridge.have_state) return NAN;
  //     return static_cast<float>(static_cast<uint32_t>(millis()-sq9650::bridge.state_at))/1000;
  //   name: 状态距今秒数 State Age
  //   platform: template
  //   unit_of_measurement: s
  //   update_interval: 5s
  new(template__templatesensor_id) template_::TemplateSensor();
  template__templatesensor_id->set_accuracy_decimals(0);
  App.register_sensor(template__templatesensor_id, "\347\212\266\346\200\201\350\267\235\344\273\212\347\247\222\346\225\260 State Age", 4291464305UL, 134218240);  // category:diagnostic, uom:s
  template__templatesensor_id->set_update_interval(5000);
  App.register_component_(template__templatesensor_id, 21);
  template__templatesensor_id->set_template([]() -> std::optional<float> {
      #line 386 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      if(!sq9650::bridge.have_state) return NAN;
      return static_cast<float>(static_cast<uint32_t>(millis()-sq9650::bridge.state_at))/1000;
  });
  // binary_sensor.status:
  //   device_class: connectivity
  //   disabled_by_default: false
  //   entity_category: diagnostic
  //   id: status_statusbinarysensor_id
  //   name: ESP32在线 ESP32 Online
  //   platform: status
  //   update_interval: 1s
  new(status_statusbinarysensor_id) status::StatusBinarySensor();
  status_statusbinarysensor_id->set_trigger_on_initial_state(false);
  App.register_binary_sensor(status_statusbinarysensor_id, "ESP32\345\234\250\347\272\277 ESP32 Online", 246954802, 134217731);  // category:diagnostic, dc:connectivity
  status_statusbinarysensor_id->set_update_interval(1000);
  App.register_component_(status_statusbinarysensor_id, 22);
  // binary_sensor.template:
  //   disabled_by_default: false
  //   id: template__templatebinarysensor_id
  //   lambda: !lambda |-
  //     return sq9650::bridge.connected;
  //   name: 马桶蓝牙已连接 BLE Connected
  //   platform: template
  new(template__templatebinarysensor_id) template_::TemplateBinarySensor();
  template__templatebinarysensor_id->set_trigger_on_initial_state(false);
  App.register_binary_sensor(template__templatebinarysensor_id, "\351\251\254\346\241\266\350\223\235\347\211\231\345\267\262\350\277\236\346\216\245 BLE Connected", 2793262500UL, 0);
  App.register_component_(template__templatebinarysensor_id, 23);
  template__templatebinarysensor_id->set_template([]() -> std::optional<bool> {
      #line 395 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      return sq9650::bridge.connected;
  });
  // binary_sensor.template:
  //   disabled_by_default: false
  //   id: state_valid
  //   lambda: !lambda |-
  //     return sq9650::bridge.fresh(millis());
  //   name: 马桶状态有效 State Valid
  //   platform: template
  new(state_valid) template_::TemplateBinarySensor();
  state_valid->set_trigger_on_initial_state(false);
  App.register_binary_sensor(state_valid, "\351\251\254\346\241\266\347\212\266\346\200\201\346\234\211\346\225\210 State Valid", 1920690318, 0);
  App.register_component_(state_valid, 23);
  state_valid->set_template([]() -> std::optional<bool> {
      #line 399 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      return sq9650::bridge.fresh(millis());
  });
  // binary_sensor.template:
  //   disabled_by_default: false
  //   id: lid_open
  //   name: 盖板已打开 Lid Open State
  //   platform: template
  new(lid_open) template_::TemplateBinarySensor();
  lid_open->set_trigger_on_initial_state(false);
  App.register_binary_sensor(lid_open, "\347\233\226\346\235\277\345\267\262\346\211\223\345\274\200 Lid Open State", 1150910043, 0);
  App.register_component_(lid_open, 23);
  // binary_sensor.template:
  //   disabled_by_default: false
  //   id: ring_open
  //   name: 座圈已抬起 Ring Raised State
  //   platform: template
  new(ring_open) template_::TemplateBinarySensor();
  ring_open->set_trigger_on_initial_state(false);
  App.register_binary_sensor(ring_open, "\345\272\247\345\234\210\345\267\262\346\212\254\350\265\267 Ring Raised State", 220922974, 0);
  App.register_component_(ring_open, 23);
  // binary_sensor.template:
  //   disabled_by_default: false
  //   id: occupied
  //   name: 有人着座 Occupied
  //   platform: template
  new(occupied) template_::TemplateBinarySensor();
  occupied->set_trigger_on_initial_state(false);
  App.register_binary_sensor(occupied, "\346\234\211\344\272\272\347\235\200\345\272\247 Occupied", 1488067464, 0);
  App.register_component_(occupied, 23);
  // binary_sensor.template:
  //   disabled_by_default: false
  //   id: moving
  //   name: 盖圈运动中 Moving
  //   platform: template
  new(moving) template_::TemplateBinarySensor();
  moving->set_trigger_on_initial_state(false);
  App.register_binary_sensor(moving, "\347\233\226\345\234\210\350\277\220\345\212\250\344\270\255 Moving", 3753096577UL, 0);
  App.register_component_(moving, 23);
  // binary_sensor.template:
  //   disabled_by_default: false
  //   id: water_ready
  //   name: 蓄水就绪 Water Ready
  //   platform: template
  new(water_ready) template_::TemplateBinarySensor();
  water_ready->set_trigger_on_initial_state(false);
  App.register_binary_sensor(water_ready, "\350\223\204\346\260\264\345\260\261\347\273\252 Water Ready", 1505418713, 0);
  App.register_component_(water_ready, 23);
  // binary_sensor.template:
  //   disabled_by_default: false
  //   id: foam_running
  //   name: 发泡中 Foam Running
  //   platform: template
  new(foam_running) template_::TemplateBinarySensor();
  foam_running->set_trigger_on_initial_state(false);
  App.register_binary_sensor(foam_running, "\345\217\221\346\263\241\344\270\255 Foam Running", 3241129538UL, 0);
  App.register_component_(foam_running, 23);
  // switch.template:
  //   assumed_state: false
  //   disabled_by_default: false
  //   id: keep_connected
  //   name: 常连接维护 Keep Connected
  //   optimistic: true
  //   platform: template
  //   restore_mode: ALWAYS_OFF
  new(keep_connected) template_::TemplateSwitch();
  keep_connected->set_restore_mode(switch_::SWITCH_ALWAYS_OFF);
  App.register_switch(keep_connected, "\345\270\270\350\277\236\346\216\245\347\273\264\346\212\244 Keep Connected", 2692503644UL, 0);
  App.register_component_(keep_connected, 24);
  keep_connected->set_optimistic(true);
  // switch.template:
  //   assumed_state: false
  //   disabled_by_default: false
  //   id: away_mode
  //   name: 离家节能 Away Mode
  //   optimistic: true
  //   platform: template
  //   restore_mode: ALWAYS_OFF
  new(away_mode) template_::TemplateSwitch();
  away_mode->set_restore_mode(switch_::SWITCH_ALWAYS_OFF);
  App.register_switch(away_mode, "\347\246\273\345\256\266\350\212\202\350\203\275 Away Mode", 4108078628UL, 0);
  App.register_component_(away_mode, 24);
  away_mode->set_optimistic(true);
  // switch.template:
  //   assumed_state: false
  //   disabled_by_default: false
  //   id: night_light
  //   name: 夜灯 Night Light
  //   optimistic: false
  //   platform: template
  //   restore_mode: DISABLED
  //   turn_off_action:
  //     automation_id: automation_id_12
  //     then:
  //       - script.execute:
  //           arg: 0
  //           cmd: 65
  //           id: send_command
  //           index: 0
  //         type_id: script_scriptexecuteaction_id_10
  //     trigger_id: trigger_id_8
  //   turn_on_action:
  //     automation_id: automation_id_11
  //     then:
  //       - script.execute:
  //           arg: 1
  //           cmd: 65
  //           id: send_command
  //           index: 0
  //         type_id: script_scriptexecuteaction_id_9
  //     trigger_id: trigger_id_7
  new(night_light) template_::TemplateSwitch();
  night_light->set_restore_mode(switch_::SWITCH_RESTORE_DISABLED);
  App.register_switch(night_light, "\345\244\234\347\201\257 Night Light", 3867542869UL, 0);
  App.register_component_(night_light, 24);
  new(automation_id_12) Automation<>(night_light->get_turn_off_trigger());
  new(script_scriptexecuteaction_id_10) script::ScriptExecuteAction<script::Script<int, int, int>>(send_command);
  script_scriptexecuteaction_id_10->set_args([]() -> int {
      return 65;
    }, []() -> int {
      return 0;
    }, []() -> int {
      return 0;
  });
  automation_id_12->add_actions({script_scriptexecuteaction_id_10});
  new(automation_id_11) Automation<>(night_light->get_turn_on_trigger());
  new(script_scriptexecuteaction_id_9) script::ScriptExecuteAction<script::Script<int, int, int>>(send_command);
  script_scriptexecuteaction_id_9->set_args([]() -> int {
      return 65;
    }, []() -> int {
      return 1;
    }, []() -> int {
      return 0;
  });
  automation_id_11->add_actions({script_scriptexecuteaction_id_9});
  // switch.template:
  //   assumed_state: false
  //   disabled_by_default: false
  //   id: foot_sensor
  //   name: 脚感 Foot Sensor
  //   optimistic: false
  //   platform: template
  //   restore_mode: DISABLED
  //   turn_off_action:
  //     automation_id: automation_id_14
  //     then:
  //       - script.execute:
  //           arg: 0
  //           cmd: 64
  //           id: send_command
  //           index: 14
  //         type_id: script_scriptexecuteaction_id_12
  //     trigger_id: trigger_id_10
  //   turn_on_action:
  //     automation_id: automation_id_13
  //     then:
  //       - script.execute:
  //           arg: 1
  //           cmd: 64
  //           id: send_command
  //           index: 14
  //         type_id: script_scriptexecuteaction_id_11
  //     trigger_id: trigger_id_9
  new(foot_sensor) template_::TemplateSwitch();
  foot_sensor->set_restore_mode(switch_::SWITCH_RESTORE_DISABLED);
  App.register_switch(foot_sensor, "\350\204\232\346\204\237 Foot Sensor", 1991109863, 0);
  App.register_component_(foot_sensor, 24);
  new(automation_id_14) Automation<>(foot_sensor->get_turn_off_trigger());
  new(script_scriptexecuteaction_id_12) script::ScriptExecuteAction<script::Script<int, int, int>>(send_command);
  script_scriptexecuteaction_id_12->set_args([]() -> int {
      return 64;
    }, []() -> int {
      return 0;
    }, []() -> int {
      return 14;
  });
  automation_id_14->add_actions({script_scriptexecuteaction_id_12});
  new(automation_id_13) Automation<>(foot_sensor->get_turn_on_trigger());
  new(script_scriptexecuteaction_id_11) script::ScriptExecuteAction<script::Script<int, int, int>>(send_command);
  script_scriptexecuteaction_id_11->set_args([]() -> int {
      return 64;
    }, []() -> int {
      return 1;
    }, []() -> int {
      return 14;
  });
  automation_id_13->add_actions({script_scriptexecuteaction_id_11});
  // switch.template:
  //   assumed_state: false
  //   disabled_by_default: false
  //   id: auto_night
  //   name: 光感夜灯（待实测） Auto Night Light
  //   optimistic: false
  //   platform: template
  //   restore_mode: DISABLED
  //   turn_off_action:
  //     automation_id: automation_id_16
  //     then:
  //       - script.execute:
  //           arg: 0
  //           cmd: 64
  //           id: send_command
  //           index: 2
  //         type_id: script_scriptexecuteaction_id_14
  //     trigger_id: trigger_id_12
  //   turn_on_action:
  //     automation_id: automation_id_15
  //     then:
  //       - script.execute:
  //           arg: 1
  //           cmd: 64
  //           id: send_command
  //           index: 2
  //         type_id: script_scriptexecuteaction_id_13
  //     trigger_id: trigger_id_11
  new(auto_night) template_::TemplateSwitch();
  auto_night->set_restore_mode(switch_::SWITCH_RESTORE_DISABLED);
  App.register_switch(auto_night, "\345\205\211\346\204\237\345\244\234\347\201\257\357\274\210\345\276\205\345\256\236\346\265\213\357\274\211 Auto Night Light", 1932562744, 0);
  App.register_component_(auto_night, 24);
  new(automation_id_16) Automation<>(auto_night->get_turn_off_trigger());
  new(script_scriptexecuteaction_id_14) script::ScriptExecuteAction<script::Script<int, int, int>>(send_command);
  script_scriptexecuteaction_id_14->set_args([]() -> int {
      return 64;
    }, []() -> int {
      return 0;
    }, []() -> int {
      return 2;
  });
  automation_id_16->add_actions({script_scriptexecuteaction_id_14});
  new(automation_id_15) Automation<>(auto_night->get_turn_on_trigger());
  new(script_scriptexecuteaction_id_13) script::ScriptExecuteAction<script::Script<int, int, int>>(send_command);
  script_scriptexecuteaction_id_13->set_args([]() -> int {
      return 64;
    }, []() -> int {
      return 1;
    }, []() -> int {
      return 2;
  });
  automation_id_15->add_actions({script_scriptexecuteaction_id_13});
  // select.template:
  //   disabled_by_default: false
  //   id: seat_temperature
  //   initial_option: 未知
  //   name: 座圈加热档位（待实测） Seat Heating
  //   optimistic: false
  //   options:
  //     - 常温
  //     - 中温
  //     - 高温
  //     - 未知
  //   platform: template
  //   restore_value: false
  //   set_action:
  //     automation_id: automation_id_17
  //     then:
  //       - if:
  //           condition:
  //             lambda: !lambda |-
  //               return x=="常温" || x=="中温" || x=="高温";
  //             type_id: lambdacondition_id_13
  //           then:
  //             - script.execute:
  //                 arg: !lambda |-
  //                   return x=="常温"?0:x=="中温"?3:5;
  //                 cmd: 60
  //                 id: send_command
  //                 index: -1
  //               type_id: script_scriptexecuteaction_id_15
  //         type_id: ifaction_id_10
  //     trigger_id: trigger_id_13
  //   update_interval: 60s
  new(seat_temperature) template_::TemplateSelectWithSetAction<false, false, false, 3>();
  seat_temperature->set_update_interval(4294967295UL);
  App.register_component_(seat_temperature, 25);
  seat_temperature->traits.set_options_static(select_options, 4);
  App.register_select(seat_temperature, "\345\272\247\345\234\210\345\212\240\347\203\255\346\241\243\344\275\215\357\274\210\345\276\205\345\256\236\346\265\213\357\274\211 Seat Heating", 3369823401UL, 0);
  new(automation_id_17) Automation<StringRef>(seat_temperature->get_set_trigger());
  new(lambdacondition_id_13) StatelessLambdaCondition<StringRef>([](StringRef x) -> bool {
      #line 494 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      return x=="常温" || x=="中温" || x=="高温";
  });
  new(ifaction_id_10) IfAction<false, StringRef>(lambdacondition_id_13);
  new(script_scriptexecuteaction_id_15) script::ScriptExecuteAction<script::Script<int, int, int>, StringRef>(send_command);
  script_scriptexecuteaction_id_15->set_args([](StringRef x) -> int {
      return 60;
    }, [](StringRef x) -> int {
      #line 499 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      return x=="常温"?0:x=="中温"?3:5;
    }, [](StringRef x) -> int {
      return -1;
  });
  ifaction_id_10->add_then({script_scriptexecuteaction_id_15});
  automation_id_17->add_actions({ifaction_id_10});
  // button.template:
  //   disabled_by_default: false
  //   id: template__templatebutton_id
  //   name: 保持蓝牙会话 Hold BLE Session
  //   on_press:
  //     - automation_id: automation_id_18
  //       then:
  //         - script.execute:
  //             id: acquire_session
  //           type_id: script_scriptexecuteaction_id_16
  //         - lambda: !lambda |-
  //             if(!id(command_pending)){sq9650::session.leasing=true; sq9650::session.lease=millis();}
  //           type_id: lambdaaction_id_15
  //       trigger_id: trigger_id_14
  //   platform: template
  new(template__templatebutton_id) template_::TemplateButton();
  new(automation_id_18) Automation<>();
  new(script_scriptexecuteaction_id_16) script::ScriptExecuteAction<script::Script<>>(acquire_session);
  script_scriptexecuteaction_id_16->set_args();
  // button.template:
  //   disabled_by_default: false
  //   id: template__templatebutton_id_2
  //   name: 结束蓝牙会话 Release BLE Session
  //   on_press:
  //     - automation_id: automation_id_19
  //       then:
  //         - lambda: !lambda |-
  //             sq9650::session.leasing=false;
  //           type_id: lambdaaction_id_16
  //       trigger_id: trigger_id_15
  //   platform: template
  new(template__templatebutton_id_2) template_::TemplateButton();
  new(automation_id_19) Automation<>();
  new(lambdaaction_id_16) StatelessLambdaAction<>([]() -> void {
      #line 511 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      sq9650::session.leasing=false;
  });
  automation_id_19->add_actions({lambdaaction_id_16});
  template__templatebutton_id_2->add_on_press_callback(TriggerForwarder<>{automation_id_19});
  App.register_button(template__templatebutton_id_2, "\347\273\223\346\235\237\350\223\235\347\211\231\344\274\232\350\257\235 Release BLE Session", 2640346894UL, 0);
  // button.template:
  //   disabled_by_default: false
  //   id: template__templatebutton_id_3
  //   name: 开盖 Open Lid
  //   on_press:
  //     - automation_id: automation_id_20
  //       then:
  //         - script.execute:
  //             arg: 1
  //             cmd: 51
  //             id: send_command
  //             index: -1
  //           type_id: script_scriptexecuteaction_id_17
  //       trigger_id: trigger_id_16
  //   platform: template
  new(template__templatebutton_id_3) template_::TemplateButton();
  new(automation_id_20) Automation<>();
  new(script_scriptexecuteaction_id_17) script::ScriptExecuteAction<script::Script<int, int, int>>(send_command);
  script_scriptexecuteaction_id_17->set_args([]() -> int {
      return 51;
    }, []() -> int {
      return 1;
    }, []() -> int {
      return -1;
  });
  automation_id_20->add_actions({script_scriptexecuteaction_id_17});
  template__templatebutton_id_3->add_on_press_callback(TriggerForwarder<>{automation_id_20});
  App.register_button(template__templatebutton_id_3, "\345\274\200\347\233\226 Open Lid", 998494272, 0);
  // button.template:
  //   disabled_by_default: false
  //   id: template__templatebutton_id_4
  //   name: 关盖 Close Lid
  //   on_press:
  //     - automation_id: automation_id_21
  //       then:
  //         - script.execute:
  //             arg: 0
  //             cmd: 51
  //             id: send_command
  //             index: -1
  //           type_id: script_scriptexecuteaction_id_18
  //       trigger_id: trigger_id_17
  //   platform: template
  new(template__templatebutton_id_4) template_::TemplateButton();
  new(automation_id_21) Automation<>();
  new(script_scriptexecuteaction_id_18) script::ScriptExecuteAction<script::Script<int, int, int>>(send_command);
  script_scriptexecuteaction_id_18->set_args([]() -> int {
      return 51;
    }, []() -> int {
      return 0;
    }, []() -> int {
      return -1;
  });
  automation_id_21->add_actions({script_scriptexecuteaction_id_18});
  template__templatebutton_id_4->add_on_press_callback(TriggerForwarder<>{automation_id_21});
  App.register_button(template__templatebutton_id_4, "\345\205\263\347\233\226 Close Lid", 1542558684, 0);
  // button.template:
  //   disabled_by_default: false
  //   id: template__templatebutton_id_5
  //   name: 抬起座圈 Raise Ring
  //   on_press:
  //     - automation_id: automation_id_22
  //       then:
  //         - script.execute:
  //             arg: 1
  //             cmd: 52
  //             id: send_command
  //             index: -1
  //           type_id: script_scriptexecuteaction_id_19
  //       trigger_id: trigger_id_18
  //   platform: template
  new(template__templatebutton_id_5) template_::TemplateButton();
  new(automation_id_22) Automation<>();
  new(script_scriptexecuteaction_id_19) script::ScriptExecuteAction<script::Script<int, int, int>>(send_command);
  script_scriptexecuteaction_id_19->set_args([]() -> int {
      return 52;
    }, []() -> int {
      return 1;
    }, []() -> int {
      return -1;
  });
  automation_id_22->add_actions({script_scriptexecuteaction_id_19});
  template__templatebutton_id_5->add_on_press_callback(TriggerForwarder<>{automation_id_22});
  App.register_button(template__templatebutton_id_5, "\346\212\254\350\265\267\345\272\247\345\234\210 Raise Ring", 4150129701UL, 0);
  // button.template:
  //   disabled_by_default: false
  //   id: template__templatebutton_id_6
  //   name: 放下座圈 Lower Ring
  //   on_press:
  //     - automation_id: automation_id_23
  //       then:
  //         - script.execute:
  //             arg: 0
  //             cmd: 52
  //             id: send_command
  //             index: -1
  //           type_id: script_scriptexecuteaction_id_20
  //       trigger_id: trigger_id_19
  //   platform: template
  new(template__templatebutton_id_6) template_::TemplateButton();
  new(automation_id_23) Automation<>();
  new(script_scriptexecuteaction_id_20) script::ScriptExecuteAction<script::Script<int, int, int>>(send_command);
  script_scriptexecuteaction_id_20->set_args([]() -> int {
      return 52;
    }, []() -> int {
      return 0;
    }, []() -> int {
      return -1;
  });
  automation_id_23->add_actions({script_scriptexecuteaction_id_20});
  template__templatebutton_id_6->add_on_press_callback(TriggerForwarder<>{automation_id_23});
  App.register_button(template__templatebutton_id_6, "\346\224\276\344\270\213\345\272\247\345\234\210 Lower Ring", 2136227032, 0);
  // button.template:
  //   disabled_by_default: false
  //   id: template__templatebutton_id_7
  //   name: 小冲 Small Flush
  //   on_press:
  //     - automation_id: automation_id_24
  //       then:
  //         - script.execute:
  //             arg: 1
  //             cmd: 53
  //             id: send_command
  //             index: -1
  //           type_id: script_scriptexecuteaction_id_21
  //       trigger_id: trigger_id_20
  //   platform: template
  new(template__templatebutton_id_7) template_::TemplateButton();
  new(automation_id_24) Automation<>();
  new(script_scriptexecuteaction_id_21) script::ScriptExecuteAction<script::Script<int, int, int>>(send_command);
  script_scriptexecuteaction_id_21->set_args([]() -> int {
      return 53;
    }, []() -> int {
      return 1;
    }, []() -> int {
      return -1;
  });
  automation_id_24->add_actions({script_scriptexecuteaction_id_21});
  template__templatebutton_id_7->add_on_press_callback(TriggerForwarder<>{automation_id_24});
  App.register_button(template__templatebutton_id_7, "\345\260\217\345\206\262 Small Flush", 3432958768UL, 0);
  // button.template:
  //   disabled_by_default: false
  //   id: template__templatebutton_id_8
  //   name: 大冲 Large Flush
  //   on_press:
  //     - automation_id: automation_id_25
  //       then:
  //         - script.execute:
  //             arg: 2
  //             cmd: 53
  //             id: send_command
  //             index: -1
  //           type_id: script_scriptexecuteaction_id_22
  //       trigger_id: trigger_id_21
  //   platform: template
  new(template__templatebutton_id_8) template_::TemplateButton();
  new(automation_id_25) Automation<>();
  new(script_scriptexecuteaction_id_22) script::ScriptExecuteAction<script::Script<int, int, int>>(send_command);
  script_scriptexecuteaction_id_22->set_args([]() -> int {
      return 53;
    }, []() -> int {
      return 2;
    }, []() -> int {
      return -1;
  });
  automation_id_25->add_actions({script_scriptexecuteaction_id_22});
  template__templatebutton_id_8->add_on_press_callback(TriggerForwarder<>{automation_id_25});
  App.register_button(template__templatebutton_id_8, "\345\244\247\345\206\262 Large Flush", 430005636, 0);
  // button.template:
  //   disabled_by_default: false
  //   id: template__templatebutton_id_9
  //   name: 启动魔力泡（待实测） Start Foam
  //   on_press:
  //     - automation_id: automation_id_26
  //       then:
  //         - script.execute:
  //             arg: 1
  //             cmd: 70
  //             id: send_command
  //             index: -1
  //           type_id: script_scriptexecuteaction_id_23
  //       trigger_id: trigger_id_22
  //   platform: template
  new(template__templatebutton_id_9) template_::TemplateButton();
  new(automation_id_26) Automation<>();
  new(script_scriptexecuteaction_id_23) script::ScriptExecuteAction<script::Script<int, int, int>>(send_command);
  script_scriptexecuteaction_id_23->set_args([]() -> int {
      return 70;
    }, []() -> int {
      return 1;
    }, []() -> int {
      return -1;
  });
  automation_id_26->add_actions({script_scriptexecuteaction_id_23});
  template__templatebutton_id_9->add_on_press_callback(TriggerForwarder<>{automation_id_26});
  App.register_button(template__templatebutton_id_9, "\345\220\257\345\212\250\351\255\224\345\212\233\346\263\241\357\274\210\345\276\205\345\256\236\346\265\213\357\274\211 Start Foam", 2319493758UL, 0);
  // button.template:
  //   disabled_by_default: false
  //   id: template__templatebutton_id_10
  //   name: 进入休眠（待实测） Hibernate
  //   on_press:
  //     - automation_id: automation_id_27
  //       then:
  //         - script.execute:
  //             arg: 1
  //             cmd: 23
  //             id: send_command
  //             index: -1
  //           type_id: script_scriptexecuteaction_id_24
  //       trigger_id: trigger_id_23
  //   platform: template
  new(template__templatebutton_id_10) template_::TemplateButton();
  new(automation_id_27) Automation<>();
  new(script_scriptexecuteaction_id_24) script::ScriptExecuteAction<script::Script<int, int, int>>(send_command);
  script_scriptexecuteaction_id_24->set_args([]() -> int {
      return 23;
    }, []() -> int {
      return 1;
    }, []() -> int {
      return -1;
  });
  automation_id_27->add_actions({script_scriptexecuteaction_id_24});
  template__templatebutton_id_10->add_on_press_callback(TriggerForwarder<>{automation_id_27});
  App.register_button(template__templatebutton_id_10, "\350\277\233\345\205\245\344\274\221\347\234\240\357\274\210\345\276\205\345\256\236\346\265\213\357\274\211 Hibernate", 2000960531, 0);
  // button.template:
  //   disabled_by_default: false
  //   entity_category: diagnostic
  //   id: template__templatebutton_id_11
  //   name: 刷新马桶状态 Refresh State
  //   on_press:
  //     - automation_id: automation_id_28
  //       then:
  //         - script.execute:
  //             id: acquire_session
  //           type_id: script_scriptexecuteaction_id_25
  //       trigger_id: trigger_id_24
  //   platform: template
  new(template__templatebutton_id_11) template_::TemplateButton();
  new(automation_id_28) Automation<>();
  new(script_scriptexecuteaction_id_25) script::ScriptExecuteAction<script::Script<>>(acquire_session);
  script_scriptexecuteaction_id_25->set_args();
  automation_id_28->add_actions({script_scriptexecuteaction_id_25});
  template__templatebutton_id_11->add_on_press_callback(TriggerForwarder<>{automation_id_28});
  App.register_button(template__templatebutton_id_11, "\345\210\267\346\226\260\351\251\254\346\241\266\347\212\266\346\200\201 Refresh State", 3965966269UL, 134217728);  // category:diagnostic
  // button.template:
  //   disabled_by_default: false
  //   entity_category: diagnostic
  //   id: template__templatebutton_id_12
  //   name: 读取马桶版本 Read Version
  //   on_press:
  //     - automation_id: automation_id_29
  //       then:
  //         - script.execute:
  //             id: acquire_session
  //           type_id: script_scriptexecuteaction_id_26
  //         - script.wait:
  //             id: acquire_session
  //           type_id: script_scriptwaitaction_id_2
  //         - script.execute:
  //             id: query_version
  //           type_id: script_scriptexecuteaction_id_27
  //       trigger_id: trigger_id_25
  //   platform: template
  new(template__templatebutton_id_12) template_::TemplateButton();
  new(automation_id_29) Automation<>();
  new(script_scriptexecuteaction_id_26) script::ScriptExecuteAction<script::Script<>>(acquire_session);
  script_scriptexecuteaction_id_26->set_args();
  new(script_scriptwaitaction_id_2) script::ScriptWaitAction<script::SingleScript<>>(acquire_session);
  App.register_component_(script_scriptwaitaction_id_2, 14);
  new(script_scriptexecuteaction_id_27) script::ScriptExecuteAction<script::Script<>>(query_version);
  script_scriptexecuteaction_id_27->set_args();
  automation_id_29->add_actions({script_scriptexecuteaction_id_26, script_scriptwaitaction_id_2, script_scriptexecuteaction_id_27});
  template__templatebutton_id_12->add_on_press_callback(TriggerForwarder<>{automation_id_29});
  App.register_button(template__templatebutton_id_12, "\350\257\273\345\217\226\351\251\254\346\241\266\347\211\210\346\234\254 Read Version", 535695611, 134217728);  // category:diagnostic
  // button.template:
  //   disabled_by_default: false
  //   entity_category: diagnostic
  //   id: template__templatebutton_id_13
  //   name: 重新连接马桶蓝牙 Reconnect BLE
  //   on_press:
  //     - automation_id: automation_id_30
  //       then:
  //         - script.execute:
  //             id: reconnect_ble
  //           type_id: script_scriptexecuteaction_id_28
  //       trigger_id: trigger_id_26
  //   platform: template
  new(template__templatebutton_id_13) template_::TemplateButton();
  new(automation_id_30) Automation<>();
  new(script_scriptexecuteaction_id_28) script::ScriptExecuteAction<script::Script<>>(reconnect_ble);
  script_scriptexecuteaction_id_28->set_args();
  automation_id_30->add_actions({script_scriptexecuteaction_id_28});
  template__templatebutton_id_13->add_on_press_callback(TriggerForwarder<>{automation_id_30});
  App.register_button(template__templatebutton_id_13, "\351\207\215\346\226\260\350\277\236\346\216\245\351\251\254\346\241\266\350\223\235\347\211\231 Reconnect BLE", 1747909677, 134217728);  // category:diagnostic
  // interval:
  //   - automation_id: automation_id_31
  //     id: interval_intervaltrigger_id
  //     interval: 5s
  //     startup_delay: 0s
  //     then:
  //       - if:
  //           condition:
  //             lambda: !lambda |-
  //               return id(keep_connected).state && !id(away_mode).state && !sq9650::session.active && uint32_t(millis()-sq9650::session.retry)>=60000;
  //             type_id: lambdacondition_id_14
  //           then:
  //             - lambda: !lambda |-
  //                 sq9650::session.retry=millis();
  //               type_id: lambdaaction_id_17
  //             - script.execute:
  //                 id: acquire_session
  //               type_id: script_scriptexecuteaction_id_29
  //         type_id: ifaction_id_11
  //     trigger_id: trigger_id_27
  //   - automation_id: automation_id_32
  //     id: interval_intervaltrigger_id_2
  //     interval: 1s
  //     startup_delay: 0s
  //     then:
  //       - if:
  //           condition:
  //             lambda: !lambda |-
  //               auto &b=sq9650::bridge;
  //               bool busy=b.state.motion || b.state.flush || b.state.bubble;
  //               if(id(keep_connected).state && !id(away_mode).state && sq9650::session.ready && !busy && !id(command_pending)) sq9650::session.idle=millis();
  //               return (id(send_command).is_running() && !id(command_pending) && !id(accepted) && uint32_t(millis()-id(command_started))>=30000) || sq9650::session.expired(millis(),b.connected,id(command_pending),busy);
  //             type_id: lambdacondition_id_15
  //           then:
  //             - esp32_ble_tracker.stop_scan:
  //                 id: esp32_ble_tracker_esp32bletracker_id
  //               type_id: applyaction_id_15
  //             - script.stop:
  //                 id: send_command
  //               type_id: applyaction_id_16
  //             - script.stop:
  //                 id: acquire_session
  //               type_id: applyaction_id_17
  //             - script.stop:
  //                 id: bootstrap
  //               type_id: applyaction_id_18
  //             - script.stop:
  //                 id: query_version
  //               type_id: applyaction_id_19
  //             - script.stop:
  //                 id: query_state
  //               type_id: applyaction_id_20
  //             - lambda: !lambda |-
  //                 sq9650::session.cancel();
  //                 sq9650::bridge.disconnect();
  //                 id(command_pending)=false;
  //                 id(state_description).publish_state("会话结束；历史状态，不重试");
  //               type_id: lambdaaction_id_18
  //             - ble_client.disconnect:
  //                 id: sq9650_client
  //               type_id: ble_client_bleclientdisconnectaction_id
  //         type_id: ifaction_id_12
  //     trigger_id: trigger_id_28
  //   - automation_id: automation_id_33
  //     id: interval_intervaltrigger_id_3
  //     interval: 2s
  //     startup_delay: 0s
  //     then:
  //       - if:
  //           condition:
  //             and:
  //               - lambda: !lambda |-
  //                   return sq9650::bridge.connected && (sq9650::session.leasing || id(command_pending) || sq9650::bridge.state.motion || sq9650::bridge.state.flush || sq9650::bridge.state.bubble || uint32_t(millis()-sq9650::session.poll)>=30000);
  //                 type_id: lambdacondition_id_16
  //               - not:
  //                   script.is_running:
  //                     id: send_command
  //                   type_id: applycondition_id
  //                 type_id: notcondition_id
  //               - not:
  //                   script.is_running:
  //                     id: bootstrap
  //                   type_id: applycondition_id_2
  //                 type_id: notcondition_id_2
  //             type_id: andcondition_id
  //           then:
  //             - lambda: !lambda |-
  //                 sq9650::session.poll=millis();
  //               type_id: lambdaaction_id_19
  //             - script.execute:
  //                 id: query_state
  //               type_id: script_scriptexecuteaction_id_30
  //         type_id: ifaction_id_13
  //     trigger_id: trigger_id_29
  //   - automation_id: automation_id_34
  //     id: interval_intervaltrigger_id_4
  //     interval: 1s
  //     startup_delay: 0s
  //     then:
  //       - lambda: !lambda |-
  //           if(sq9650::bridge.connected && !sq9650::bridge.fresh(millis()))
  //             id(state_description).publish_state("未收到有效状态或已过期，禁止控制；显示值为历史值");
  //           if(id(command_pending) && static_cast<uint32_t>(millis()-id(sent_at))>12000) {
  //             id(command_pending)=false;
  //             sq9650::session.completed(millis(),sq9650::bridge.state.motion || sq9650::bridge.state.flush || sq9650::bridge.state.bubble);
  //             id(command_result).publish_state("12秒内未读到目标状态，不自动重试");
  //           }
  //         type_id: lambdaaction_id_20
  //     trigger_id: trigger_id_30
  new(interval_intervaltrigger_id) interval::IntervalTrigger();
  App.register_component_(interval_intervaltrigger_id, 26);
  new(automation_id_31) Automation<>(interval_intervaltrigger_id);
  new(lambdacondition_id_14) StatelessLambdaCondition<>([]() -> bool {
      #line 599 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      return keep_connected->state && !away_mode->state && !sq9650::session.active && uint32_t(millis()-sq9650::session.retry)>=60000;
  });
  new(ifaction_id_11) IfAction<false>(lambdacondition_id_14);
  new(lambdaaction_id_17) StatelessLambdaAction<>([]() -> void {
      #line 601 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      sq9650::session.retry=millis();
  });
  new(script_scriptexecuteaction_id_29) script::ScriptExecuteAction<script::Script<>>(acquire_session);
  script_scriptexecuteaction_id_29->set_args();
  ifaction_id_11->add_then({lambdaaction_id_17, script_scriptexecuteaction_id_29});
  automation_id_31->add_actions({ifaction_id_11});
  interval_intervaltrigger_id->set_update_interval(5000);
  interval_intervaltrigger_id->set_startup_delay(0);
  new(interval_intervaltrigger_id_2) interval::IntervalTrigger();
  App.register_component_(interval_intervaltrigger_id_2, 26);
  new(automation_id_32) Automation<>(interval_intervaltrigger_id_2);
  // text.template:
  //   disabled_by_default: false
  //   id: target_mac
  //   initial_value: ''
  //   max_length: 17
  //   min_length: 0
  //   mode: TEXT
  //   name: 马桶蓝牙地址 Target MAC
  //   optimistic: false
  //   platform: template
  //   restore_value: false
  //   set_action:
  //     automation_id: automation_id_35
  //     then:
  //       - lambda: !lambda |-
  //           uint64_t addr=0;
  //           if(!sq9650::parse_mac(x,addr)) {
  //             id(command_result).publish_state("地址无效，请填写 AA:BB:CC:DD:EE:FF");
  //             return;
  //           }
  //           if(sq9650::session.active || id(send_command).is_running() ||
  //              id(sq9650_client).state()!=esphome::esp32_ble_tracker::ClientState::IDLE) {
  //             id(command_result).publish_state("请结束会话并等待蓝牙断开后修改地址");
  //             return;
  //           }
  //           id(configured_mac)=x;
  //           id(sq9650_client).set_address(addr);
  //           id(target_mac).publish_state(x);
  //           id(command_result).publish_state("地址已设置，点击刷新状态测试");
  //         type_id: lambdaaction_id_21
  //     trigger_id: trigger_id_31
  //   update_interval: 60s
  new(target_mac) template_::TemplateText();
  target_mac->traits.set_min_length(0);
  target_mac->traits.set_max_length(17);
  target_mac->traits.set_mode(text::TEXT_MODE_TEXT);
  App.register_text(target_mac, "\351\251\254\346\241\266\350\223\235\347\211\231\345\234\260\345\235\200 Target MAC", 2473226653UL, 0);
  target_mac->set_update_interval(60000);
  App.register_component_(target_mac, 27);
  target_mac->set_optimistic(false);
  new(automation_id_35) Automation<std::string>(target_mac->get_set_trigger());
  // socket:
  //   implementation: bsd_sockets
  // esp32_ble:
  //   advertising: false
  //   advertising_cycle_time: 10s
  //   connection_timeout: 20s
  //   disable_bt_logs: true
  //   enable_on_boot: true
  //   id: esp32_ble_esp32ble_id
  //   io_capability: none
  //   max_connections: 3
  //   max_notifications: 12
  new(esp32_ble_esp32ble_id) esp32_ble::ESP32BLE();
  esp32_ble_esp32ble_id->set_enable_on_boot(true);
  esp32_ble_esp32ble_id->set_io_capability(esp32_ble::IO_CAP_NONE);
  esp32_ble_esp32ble_id->set_advertising_cycle_time(10000);
  App.register_component_(esp32_ble_esp32ble_id, 28);
  // web_server_idf:
  //   {}
  // md5:
  { auto *h = esp32_ble_tracker_esp32bletracker_id; esp32_ble_esp32ble_id->add_gap_event_callback([h](esp_gap_ble_cb_event_t event, esp_ble_gap_cb_param_t *param) { h->gap_event_handler(event, param); }); }
  { auto *h = esp32_ble_tracker_esp32bletracker_id; esp32_ble_esp32ble_id->add_gap_scan_event_callback([h](const esphome::esp32_ble::BLEScanResult &scan_result) { h->gap_scan_event_handler(scan_result); }); }
  { auto *h = esp32_ble_tracker_esp32bletracker_id; esp32_ble_esp32ble_id->add_gattc_event_callback([h](esp_gattc_cb_event_t event, esp_gatt_if_t gattc_if, esp_ble_gattc_cb_param_t *param) { h->gattc_event_handler(event, gattc_if, param); }); }
  { auto *h = esp32_ble_tracker_esp32bletracker_id; esp32_ble_esp32ble_id->add_ble_status_event_callback([h]() { h->ble_before_disabled_event_handler(); }); }
  esp32_ble_tracker_esp32bletracker_id->set_parent(esp32_ble_esp32ble_id);
  esp32_ble_tracker_esp32bletracker_id->set_scan_duration(30);
  esp32_ble_tracker_esp32bletracker_id->set_scan_interval(512);
  esp32_ble_tracker_esp32bletracker_id->set_scan_window(96);
  esp32_ble_tracker_esp32bletracker_id->set_scan_active(true);
  esp32_ble_tracker_esp32bletracker_id->set_scan_continuous(false);
  // globals:
  //   id: configured_mac
  //   initial_value: '""'
  //   max_restore_data_length: 17
  //   restore_value: true
  //   type: std::string
  //   update_interval: 1s
  new(configured_mac) globals::RestoringGlobalStringComponent<std::string, 18>("");
  configured_mac->set_update_interval(1000);
  App.register_component_(configured_mac, 29);
  configured_mac->set_name_hash(3634419636UL);
  // globals:
  //   id: command_started
  //   initial_value: '0'
  //   restore_value: false
  //   type: uint32_t
  new(command_started) globals::GlobalsComponent<uint32_t>(0);
  App.register_component_(command_started, 29);
  // globals:
  //   id: command_pending
  //   initial_value: 'false'
  //   restore_value: false
  //   type: bool
  new(command_pending) globals::GlobalsComponent<bool>(false);
  App.register_component_(command_pending, 29);
  // globals:
  //   id: accepted
  //   initial_value: 'false'
  //   restore_value: false
  //   type: bool
  new(accepted) globals::GlobalsComponent<bool>(false);
  App.register_component_(accepted, 29);
  // globals:
  //   id: pending_cmd
  //   initial_value: '0'
  //   restore_value: false
  //   type: int
  new(pending_cmd) globals::GlobalsComponent<int>(0);
  App.register_component_(pending_cmd, 29);
  // globals:
  //   id: pending_value
  //   initial_value: '0'
  //   restore_value: false
  //   type: int
  new(pending_value) globals::GlobalsComponent<int>(0);
  App.register_component_(pending_value, 29);
  // globals:
  //   id: pending_index
  //   initial_value: '-1'
  //   restore_value: false
  //   type: int
  new(pending_index) globals::GlobalsComponent<int>(-1);
  App.register_component_(pending_index, 29);
  // globals:
  //   id: sent_at
  //   initial_value: '0'
  //   restore_value: false
  //   type: uint32_t
  new(sent_at) globals::GlobalsComponent<uint32_t>(0);
  App.register_component_(sent_at, 29);
  // globals:
  //   id: sent_sequence
  //   initial_value: '0'
  //   restore_value: false
  //   type: uint32_t
  new(sent_sequence) globals::GlobalsComponent<uint32_t>(0);
  App.register_component_(sent_sequence, 29);
  new(lambdaaction_id_2) StatelessLambdaAction<>([]() -> void {
      #line 97 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      if(!sq9650::session.active){sq9650_client->disconnect();return;}
      sq9650::bridge.connect();
      command_pending->value()=false;
      state_description->publish_state("蓝牙已连接，等待读回状态");
      command_result->publish_state("重连仅查询，不重放控制");
  });
  new(script_scriptexecuteaction_id) script::ScriptExecuteAction<script::Script<>>(bootstrap);
  script_scriptexecuteaction_id->set_args();
  automation_id_2->add_actions({lambdaaction_id_2, script_scriptexecuteaction_id});
  new(ble_client_bleclientdisconnecttrigger_id) ble_client::BLEClientDisconnectTrigger(sq9650_client);
  new(automation_id_3) Automation<>(ble_client_bleclientdisconnecttrigger_id);
  new(applyaction_id) ApplyAction<esphome__applyaction_id__fn>();
  new(applyaction_id_2) ApplyAction<esphome__applyaction_id_2__fn>();
  new(applyaction_id_3) ApplyAction<esphome__applyaction_id_3__fn>();
  new(applyaction_id_4) ApplyAction<esphome__applyaction_id_4__fn>();
  new(applyaction_id_5) ApplyAction<esphome__applyaction_id_5__fn>();
  new(applyaction_id_6) ApplyAction<esphome__applyaction_id_6__fn>();
  new(lambdaaction_id_3) StatelessLambdaAction<>([]() -> void {
      #line 112 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      sq9650::session.cancel();
      sq9650::bridge.disconnect();
      if(command_pending->value()) command_result->publish_state("连接断开，命令未确认且不重放");
      command_pending->value()=false;
      state_description->publish_state("蓝牙离线，显示值为历史值");
  });
  automation_id_3->add_actions({applyaction_id, applyaction_id_2, applyaction_id_3, applyaction_id_4, applyaction_id_5, applyaction_id_6, lambdaaction_id_3});
  new(lambdacondition_id_3) StatelessLambdaCondition<>([]() -> bool {
      #line 157 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      return command_pending->value() || send_command->is_running() || (sq9650::bridge.fresh(millis()) && (sq9650::bridge.state.motion || sq9650::bridge.state.flush || sq9650::bridge.state.bubble));
  });
  new(ifaction_id_3) IfAction<false>(lambdacondition_id_3);
  new(lambdaaction_id_4) StatelessLambdaAction<>([]() -> void {
      #line 159 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      command_result->publish_state("拒绝：动作或请求处理中，暂不重连");
  });
  new(applyaction_id_7) ApplyAction<esphome__applyaction_id_7__fn>();
  ifaction_id_3->add_then({lambdaaction_id_4, applyaction_id_7});
  new(applyaction_id_8) ApplyAction<esphome__applyaction_id_8__fn>();
  new(applyaction_id_9) ApplyAction<esphome__applyaction_id_9__fn>();
  new(applyaction_id_10) ApplyAction<esphome__applyaction_id_10__fn>();
  new(applyaction_id_11) ApplyAction<esphome__applyaction_id_11__fn>();
  new(lambdaaction_id_5) StatelessLambdaAction<>([]() -> void {
      #line 165 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      sq9650::session.cancel();
      sq9650::bridge.disconnect();
      state_valid->publish_state(false);
      sq9650_client->disconnect();
  });
  new(lambdacondition_id_4) StatelessLambdaCondition<>([]() -> bool {
      #line 172 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      return sq9650_client->state()==esphome::esp32_ble_tracker::ClientState::IDLE;
  });
  new(waituntilaction_id) WaitUntilAction<>(lambdacondition_id_4);
  waituntilaction_id->set_timeout_value([]() -> uint32_t {
      return 5000;
  });
  App.register_component_(waituntilaction_id, 14);
  new(lambdacondition_id_5) StatelessLambdaCondition<>([]() -> bool {
      #line 176 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      return sq9650_client->state()==esphome::esp32_ble_tracker::ClientState::IDLE;
  });
  new(ifaction_id_4) IfAction<true>(lambdacondition_id_5);
  new(script_scriptexecuteaction_id_4) script::ScriptExecuteAction<script::Script<>>(acquire_session);
  script_scriptexecuteaction_id_4->set_args();
  ifaction_id_4->add_then({script_scriptexecuteaction_id_4});
  new(lambdaaction_id_6) StatelessLambdaAction<>([]() -> void {
      #line 180 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      command_result->publish_state("断开连接超时，未重连、不重放");
  });
  ifaction_id_4->add_else({lambdaaction_id_6});
  automation_id_7->add_actions({ifaction_id_3, applyaction_id_8, applyaction_id_9, applyaction_id_10, applyaction_id_11, lambdaaction_id_5, waituntilaction_id, ifaction_id_4});
  new(automation_id_8) Automation<>(acquire_session);
  new(lambdacondition_id_6) StatelessLambdaCondition<>([]() -> bool {
      #line 186 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      uint64_t addr=0;
      return !sq9650::parse_mac(configured_mac->value(),addr);
  });
  new(ifaction_id_5) IfAction<false>(lambdacondition_id_6);
  new(lambdaaction_id_7) StatelessLambdaAction<>([]() -> void {
      #line 190 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      command_result->publish_state("请先配置马桶蓝牙地址");
  });
  new(applyaction_id_12) ApplyAction<esphome__applyaction_id_12__fn>();
  ifaction_id_5->add_then({lambdaaction_id_7, applyaction_id_12});
  new(lambdacondition_id_7) StatelessLambdaCondition<>([]() -> bool {
      #line 194 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      return command_pending->value();
  });
  new(ifaction_id_6) IfAction<false>(lambdacondition_id_7);
  new(lambdaaction_id_8) StatelessLambdaAction<>([]() -> void {
      #line 196 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      command_result->publish_state("拒绝：命令处理中，会话不变");
  });
  new(applyaction_id_13) ApplyAction<esphome__applyaction_id_13__fn>();
  ifaction_id_6->add_then({lambdaaction_id_8, applyaction_id_13});
  new(lambdaaction_id_9) StatelessLambdaAction<>([]() -> void {
      #line 198 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      sq9650::session.request(millis()); sq9650::session.retry=millis(); sq9650::bridge.have_state=false; state_valid->publish_state(false);
  });
  new(lambdacondition_id_8) StatelessLambdaCondition<>([]() -> bool {
      #line 201 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      return !sq9650::bridge.connected;
  });
  new(ifaction_id_7) IfAction<false>(lambdacondition_id_8);
  new(ble_client_bleclientconnectaction_id) ble_client::BLEClientConnectAction<>(sq9650_client);
  ifaction_id_7->add_then({ble_client_bleclientconnectaction_id});
  new(script_scriptexecuteaction_id_5) script::ScriptExecuteAction<script::Script<>>(query_state);
  script_scriptexecuteaction_id_5->set_args();
  automation_id_8->add_actions({ifaction_id_5, ifaction_id_6, lambdaaction_id_9, ifaction_id_7, script_scriptexecuteaction_id_5});
  new(automation_id_9) Automation<int, int, int>(send_command);
  new(lambdacondition_id_9) StatelessLambdaCondition<int, int, int>([](int cmd, int arg, int index) -> bool {
      #line 214 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      return command_pending->value();
  });
  new(ifaction_id_8) IfAction<false, int, int, int>(lambdacondition_id_9);
  new(lambdaaction_id_10) StatelessLambdaAction<int, int, int>([](int cmd, int arg, int index) -> void {
      #line 216 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      command_result->publish_state("拒绝：上个命令仍等待读回");
  });
  new(applyaction_id_14) ApplyAction<esphome__applyaction_id_14__fn, int, int, int>();
  ifaction_id_8->add_then({lambdaaction_id_10, applyaction_id_14});
  new(lambdaaction_id_11) StatelessLambdaAction<int, int, int>([](int cmd, int arg, int index) -> void {
      #line 218 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      accepted->value()=false; command_started->value()=millis();
  });
  new(script_scriptexecuteaction_id_6) script::ScriptExecuteAction<script::Script<>, int, int, int>(acquire_session);
  script_scriptexecuteaction_id_6->set_args();
  new(lambdacondition_id_10) StatelessLambdaCondition<int, int, int>([](int cmd, int arg, int index) -> bool {
      #line 222 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      return sq9650::bridge.connected;
  });
  new(waituntilaction_id_2) WaitUntilAction<int, int, int>(lambdacondition_id_10);
  waituntilaction_id_2->set_timeout_value([](int cmd, int arg, int index) -> uint32_t {
      return 30000;
  });
  App.register_component_(waituntilaction_id_2, 14);
  new(lambdaaction_id_12) StatelessLambdaAction<int, int, int>([](int cmd, int arg, int index) -> void {
      #line 224 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      sq9650::session.sequence=sq9650::bridge.state_sequence; sq9650::bridge.have_state=false; state_valid->publish_state(false);
  });
  new(script_scriptexecuteaction_id_7) script::ScriptExecuteAction<script::Script<>, int, int, int>(query_state);
  script_scriptexecuteaction_id_7->set_args();
  new(lambdacondition_id_11) StatelessLambdaCondition<int, int, int>([](int cmd, int arg, int index) -> bool {
      #line 228 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      return sq9650::bridge.state_sequence!=sq9650::session.sequence;
  });
  new(waituntilaction_id_3) WaitUntilAction<int, int, int>(lambdacondition_id_11);
  waituntilaction_id_3->set_timeout_value([](int cmd, int arg, int index) -> uint32_t {
      return 5000;
  });
  App.register_component_(waituntilaction_id_3, 14);
  new(lambdaaction_id_13) StatelessLambdaAction<int, int, int>([](int cmd, int arg, int index) -> void {
      #line 230 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      accepted->value()=false;
      if(!sq9650::session.active || uint32_t(millis()-command_started->value())>=30000 || sq9650::bridge.state_sequence==sq9650::session.sequence) {command_result->publish_state("获取新鲜状态超时或会话取消，未发送，不重试");return;}
      if(cmd!=0x35 && cmd!=0x46 && sq9650::bridge.matches(cmd,arg,index)) {command_result->publish_state("已达到目标，未重复下发");return;}
      if(command_pending->value()) {
        command_result->publish_state("拒绝：上个命令仍等待读回");
        return;
      }
      const char *reason=sq9650::bridge.reject(cmd,arg,index,millis());
      if(reason) {
        command_result->publish_state(std::string("拒绝：")+reason);
        ESP_LOGW("sq9650", "REJECT cmd=%02X reason=%s",cmd,reason);
        return;
      }
      accepted->value()=true;
      pending_cmd->value()=cmd;pending_value->value()=arg;pending_index->value()=index;
      sent_at->value()=millis();sent_sequence->value()=sq9650::bridge.state_sequence;
      command_pending->value()=true;
      sq9650::bridge.sent(cmd,millis());
      sq9650::session.sent(millis());
      command_result->publish_state("请求发送，等待设备状态回读");
      ESP_LOGI("sq9650", "REQUEST cmd=%02X arg=%d index=%d",cmd,arg,index);
  });
  new(lambdacondition_id_12) StatelessLambdaCondition<int, int, int>([](int cmd, int arg, int index) -> bool {
      #line 254 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      return accepted->value();
  });
  new(ifaction_id_9) IfAction<false, int, int, int>(lambdacondition_id_12);
  new(ble_client_bleclientwriteaction_id_3) ble_client::BLEClientWriteAction<int, int, int>(sq9650_client);
  ble_client_bleclientwriteaction_id_3->set_value_template([](int cmd, int arg, int index) -> std::vector<uint8_t> {
      #line 260 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      auto f=sq9650::command(cmd,arg,index);
      return std::vector<uint8_t>(f.data,f.data+f.size);
  });
  ble_client_bleclientwriteaction_id_3->set_service_uuid16(0xFFE0ULL);
  ble_client_bleclientwriteaction_id_3->set_char_uuid16(0xFFE1ULL);
  new(delayaction_id_3) DelayAction<int, int, int>();
  delayaction_id_3->set_delay([](int cmd, int arg, int index) -> uint32_t {
      return 800;
  });
  new(script_scriptexecuteaction_id_8) script::ScriptExecuteAction<script::Script<>, int, int, int>(query_state);
  script_scriptexecuteaction_id_8->set_args();
  ifaction_id_9->add_then({ble_client_bleclientwriteaction_id_3, delayaction_id_3, script_scriptexecuteaction_id_8});
  automation_id_9->add_actions({ifaction_id_8, lambdaaction_id_11, script_scriptexecuteaction_id_6, waituntilaction_id_2, lambdaaction_id_12, script_scriptexecuteaction_id_7, waituntilaction_id_3, lambdaaction_id_13, ifaction_id_9});
  new(lambdaaction_id_14) StatelessLambdaAction<std::string>([](std::string x) -> void {
      #line 313 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      for (uint8_t byte:x) {
        auto before=sq9650::bridge.state_sequence;
        if(!sq9650::bridge.ingest(byte,millis())) continue;
        auto &frame=sq9650::bridge.parser.frame;
        if(sq9650::bridge.state_sequence!=before) {
          sq9650::session.acquired(millis());
          const auto &s=sq9650::bridge.state;
          lid_open->publish_state(s.lid);
          ring_open->publish_state(s.ring);
          occupied->publish_state(s.occupied);
          moving->publish_state(s.motion!=0);
          water_ready->publish_state(s.ready);
          foam_running->publish_state(s.bubble);
          night_light->publish_state(s.night);
          foot_sensor->publish_state(s.foot);
          auto_night->publish_state(s.light_sensor);
          seat_level_raw->publish_state(s.seat);
          work_state_raw->publish_state(s.work);
          flush_kind->publish_state(s.flush);
          seat_temperature->publish_state(s.seat==0?"常温":s.seat==3?"中温":s.seat==5?"高温":"未知");
          if(uint32_t(millis()-sq9650::session.raw)>=60000){sq9650::session.raw=millis();raw_status->publish_state(format_hex_pretty(frame.data,frame.size));}
          if(s.work==1) state_description->publish_state("休眠，状态有效");
          else if(s.motion || s.flush || s.bubble || s.work!=2) state_description->publish_state("状态有效，设备忙碌");
          else state_description->publish_state("状态有效，正常待机");
          if(command_pending->value() && sq9650::bridge.state_sequence!=sent_sequence->value() &&
             sq9650::bridge.matches(pending_cmd->value(),pending_value->value(),pending_index->value())) {
            command_pending->value()=false;
            sq9650::session.completed(millis(),sq9650::bridge.state.motion || sq9650::bridge.state.flush || sq9650::bridge.state.bubble);
            command_result->publish_state("设备回读已匹配目标；动作效果请按现场确认");
          }
        } else {
          sq9650::Version v;
          if(sq9650::decode_version(frame,v)) {
            hardware_version->publish_state(v.hardware);
            mcu_version->publish_state(v.firmware);
          }
        }
      }
  });
  automation_id_10->add_actions({lambdaaction_id_14});
  new(lambdaaction_id_15) StatelessLambdaAction<>([]() -> void {
      #line 507 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      if(!command_pending->value()){sq9650::session.leasing=true; sq9650::session.lease=millis();}
  });
  automation_id_18->add_actions({script_scriptexecuteaction_id_16, lambdaaction_id_15});
  template__templatebutton_id->add_on_press_callback(TriggerForwarder<>{automation_id_18});
  App.register_button(template__templatebutton_id, "\344\277\235\346\214\201\350\223\235\347\211\231\344\274\232\350\257\235 Hold BLE Session", 926291062, 0);
  new(lambdacondition_id_15) StatelessLambdaCondition<>([]() -> bool {
      #line 607 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      auto &b=sq9650::bridge;
      bool busy=b.state.motion || b.state.flush || b.state.bubble;
      if(keep_connected->state && !away_mode->state && sq9650::session.ready && !busy && !command_pending->value()) sq9650::session.idle=millis();
      return (send_command->is_running() && !command_pending->value() && !accepted->value() && uint32_t(millis()-command_started->value())>=30000) || sq9650::session.expired(millis(),b.connected,command_pending->value(),busy);
  });
  new(ifaction_id_12) IfAction<false>(lambdacondition_id_15);
  new(applyaction_id_15) ApplyAction<esphome__applyaction_id_15__fn>();
  new(applyaction_id_16) ApplyAction<esphome__applyaction_id_16__fn>();
  new(applyaction_id_17) ApplyAction<esphome__applyaction_id_17__fn>();
  new(applyaction_id_18) ApplyAction<esphome__applyaction_id_18__fn>();
  new(applyaction_id_19) ApplyAction<esphome__applyaction_id_19__fn>();
  new(applyaction_id_20) ApplyAction<esphome__applyaction_id_20__fn>();
  new(lambdaaction_id_18) StatelessLambdaAction<>([]() -> void {
      #line 619 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      sq9650::session.cancel();
      sq9650::bridge.disconnect();
      command_pending->value()=false;
      state_description->publish_state("会话结束；历史状态，不重试");
  });
  new(ble_client_bleclientdisconnectaction_id) ble_client::BLEClientDisconnectAction<>(sq9650_client);
  ifaction_id_12->add_then({applyaction_id_15, applyaction_id_16, applyaction_id_17, applyaction_id_18, applyaction_id_19, applyaction_id_20, lambdaaction_id_18, ble_client_bleclientdisconnectaction_id});
  automation_id_32->add_actions({ifaction_id_12});
  interval_intervaltrigger_id_2->set_update_interval(1000);
  interval_intervaltrigger_id_2->set_startup_delay(0);
  new(interval_intervaltrigger_id_3) interval::IntervalTrigger();
  App.register_component_(interval_intervaltrigger_id_3, 26);
  new(automation_id_33) Automation<>(interval_intervaltrigger_id_3);
  new(lambdacondition_id_16) StatelessLambdaCondition<>([]() -> bool {
      #line 630 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      return sq9650::bridge.connected && (sq9650::session.leasing || command_pending->value() || sq9650::bridge.state.motion || sq9650::bridge.state.flush || sq9650::bridge.state.bubble || uint32_t(millis()-sq9650::session.poll)>=30000);
  });
  new(applycondition_id) ApplyCondition<esphome__applycondition_id__fn>();
  new(notcondition_id) NotCondition<>(applycondition_id);
  new(applycondition_id_2) ApplyCondition<esphome__applycondition_id_2__fn>();
  new(notcondition_id_2) NotCondition<>(applycondition_id_2);
  new(andcondition_id) AndCondition<3>({lambdacondition_id_16, notcondition_id, notcondition_id_2});
  new(ifaction_id_13) IfAction<false>(andcondition_id);
  new(lambdaaction_id_19) StatelessLambdaAction<>([]() -> void {
      #line 636 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      sq9650::session.poll=millis();
  });
  new(script_scriptexecuteaction_id_30) script::ScriptExecuteAction<script::Script<>>(query_state);
  script_scriptexecuteaction_id_30->set_args();
  ifaction_id_13->add_then({lambdaaction_id_19, script_scriptexecuteaction_id_30});
  automation_id_33->add_actions({ifaction_id_13});
  interval_intervaltrigger_id_3->set_update_interval(2000);
  interval_intervaltrigger_id_3->set_startup_delay(0);
  new(interval_intervaltrigger_id_4) interval::IntervalTrigger();
  App.register_component_(interval_intervaltrigger_id_4, 26);
  new(automation_id_34) Automation<>(interval_intervaltrigger_id_4);
  new(lambdaaction_id_20) StatelessLambdaAction<>([]() -> void {
      #line 640 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      if(sq9650::bridge.connected && !sq9650::bridge.fresh(millis()))
        state_description->publish_state("未收到有效状态或已过期，禁止控制；显示值为历史值");
      if(command_pending->value() && static_cast<uint32_t>(millis()-sent_at->value())>12000) {
        command_pending->value()=false;
        sq9650::session.completed(millis(),sq9650::bridge.state.motion || sq9650::bridge.state.flush || sq9650::bridge.state.bubble);
        command_result->publish_state("12秒内未读到目标状态，不自动重试");
      }
  });
  automation_id_34->add_actions({lambdaaction_id_20});
  interval_intervaltrigger_id_4->set_update_interval(1000);
  interval_intervaltrigger_id_4->set_startup_delay(0);
  new(lambdaaction_id_21) StatelessLambdaAction<std::string>([](std::string x) -> void {
      #line 658 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      uint64_t addr=0;
      if(!sq9650::parse_mac(x,addr)) {
        command_result->publish_state("地址无效，请填写 AA:BB:CC:DD:EE:FF");
        return;
      }
      if(sq9650::session.active || send_command->is_running() ||
         sq9650_client->state()!=esphome::esp32_ble_tracker::ClientState::IDLE) {
        command_result->publish_state("请结束会话并等待蓝牙断开后修改地址");
        return;
      }
      configured_mac->value()=x;
      sq9650_client->set_address(addr);
      target_mac->publish_state(x);
      command_result->publish_state("地址已设置，点击刷新状态测试");
  });
  automation_id_35->add_actions({lambdaaction_id_21});
  new(lambdaaction_id) StatelessLambdaAction<>([]() -> void {
      #line 11 "jomoo-capture\\esp32\\public-build\\jomoo-public.yaml"
      target_mac->publish_state(configured_mac->value());
      uint64_t addr=0;
      if(sq9650::parse_mac(configured_mac->value(),addr)) sq9650_client->set_address(addr);
  });
  automation_id->add_actions({lambdaaction_id});
  // =========== AUTO GENERATED CODE END ============
  App.setup();
}

void loop() {
  App.loop();
}
