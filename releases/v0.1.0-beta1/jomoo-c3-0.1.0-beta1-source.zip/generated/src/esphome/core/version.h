#pragma once
#include "esphome/core/macros.h"
#define ESPHOME_VERSION "2026.10.0"
#define ESPHOME_VERSION_CODE VERSION_CODE(2026, 10, 0)
