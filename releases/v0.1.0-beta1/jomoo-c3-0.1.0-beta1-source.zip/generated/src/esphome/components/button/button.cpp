#include "button.h"
#include "esphome/core/log.h"

namespace esphome::button {

static const char *const TAG = "button";

// Function implementation of LOG_BUTTON macro to reduce code size
void log_button(const char *tag, const char *prefix, const char *type, Button *obj) {
  if (obj == nullptr) {
    return;
  }

  ESP_LOGCONFIG(tag, "%s%s '%s'", prefix, type, obj->get_name().c_str());
  LOG_ENTITY_ICON(tag, prefix, *obj);
}

void Button::press() {
  ESP_LOGV(TAG, "'%s' Pressed.", this->get_name().c_str());
  this->press_action();
  this->press_callback_.call();
}

}  // namespace esphome::button
