#pragma once

#include "esphome/core/component.h"
#include "esphome/core/entity_base.h"
#include "esphome/core/helpers.h"
#include "esphome/core/string_ref.h"
#include "select_call.h"
#include "select_traits.h"

namespace esphome::select {

#define LOG_SELECT(prefix, type, obj) \
  if ((obj) != nullptr) { \
    ESP_LOGCONFIG(TAG, "%s%s '%s'", prefix, LOG_STR_LITERAL(type), (obj)->get_name().c_str()); \
    LOG_ENTITY_ICON(TAG, prefix, *(obj)); \
  }

#define SUB_SELECT(name) \
 protected: \
  select::Select *name##_select_{nullptr}; \
\
 public: \
  void set_##name##_select(select::Select *select) { this->name##_select_ = select; }

/** Base-class for all selects.
 *
 * A select can use publish_state to send out a new value.
 */
class Select : public EntityBase {
 public:
  SelectTraits traits;

  Select() = default;
  ~Select() = default;

  void publish_state(const std::string &state) { this->publish_state(state.c_str()); }
  void publish_state(const char *state);
  void publish_state(size_t index);

  /// Return the currently selected option, or empty StringRef if no state.
  /// The returned StringRef points to string literals from codegen (static storage).
  /// Traits are set once at startup and valid for the lifetime of the program.
  StringRef current_option() const {
    return this->has_state() ? StringRef(this->option_at(this->active_index_)) : StringRef();
  }

  /// Instantiate a SelectCall object to modify this select component's state.
  SelectCall make_call() { return SelectCall(this); }

  /// Return whether this select component contains the provided option.
  bool has_option(const std::string &option) const { return this->index_of(option).has_value(); }
  bool has_option(const char *option) const { return this->index_of(option).has_value(); }

  /// Return whether this select component contains the provided index offset.
  bool has_index(size_t index) const { return index < this->size(); }

  /// Return the number of options in this select component.
  size_t size() const { return this->traits.get_options().size(); }

  /// Find the (optional) index offset of the provided option value.
  optional<size_t> index_of(const char *option, size_t len) const;
  optional<size_t> index_of(const std::string &option) const { return this->index_of(option.data(), option.size()); }
  optional<size_t> index_of(const char *option) const { return this->index_of(option, strlen(option)); }

  /// Return the (optional) index offset of the currently active option.
  optional<size_t> active_index() const;

  /// Return the (optional) option value at the provided index offset.
  optional<std::string> at(size_t index) const;

  /// Return the option value at the provided index offset (as const char* from flash).
  const char *option_at(size_t index) const;

  template<typename F> void add_on_state_callback(F &&callback) {
    this->state_callback_.add(std::forward<F>(callback));
  }

 protected:
  friend class SelectCall;

  size_t active_index_{0};

  /** Set the value of the select by index, this is an optional virtual method.
   *
   * IMPORTANT: At least ONE of the two control() methods must be overridden by derived classes.
   * Overriding this index-based version is PREFERRED as it avoids string conversions.
   *
   * This method is called by the SelectCall when the index is already known.
   * Default implementation converts to string and calls control(const std::string&).
   *
   * @param index The index as validated by the SelectCall.
   */
  virtual void control(size_t index) { this->control(this->option_at(index)); }

  /** Set the value of the select, this is a virtual method that each select integration can implement.
   *
   * IMPORTANT: At least ONE of the two control() methods must be overridden by derived classes.
   * Overriding control(size_t) is PREFERRED as it avoids string conversions.
   *
   * This method is called by control(size_t) when not overridden, or directly by external code.
   * Default implementation converts to index and calls control(size_t).
   *
   * @param value The value as validated by the caller.
   */
  virtual void control(const std::string &value) {
    auto index = this->index_of(value);
    if (index.has_value()) {
      this->control(index.value());
    }
  }

  LazyCallbackManager<void(size_t)> state_callback_;
};

}  // namespace esphome::select
