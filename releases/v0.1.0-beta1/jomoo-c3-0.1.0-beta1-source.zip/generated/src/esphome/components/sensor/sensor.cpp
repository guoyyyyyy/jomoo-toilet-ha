#include "sensor.h"
#include "esphome/core/defines.h"
#include "esphome/core/controller_registry.h"
#include "esphome/core/log.h"
#include "esphome/core/progmem.h"

namespace esphome::sensor {

static const char *const TAG = "sensor";

// Function implementation of LOG_SENSOR macro to reduce code size
void log_sensor(const char *tag, const char *prefix, const char *type, Sensor *obj) {
  if (obj == nullptr) {
    return;
  }

  ESP_LOGCONFIG(tag,
                "%s%s '%s'\n"
                "%s  State Class: '%s'\n"
                "%s  Unit of Measurement: '%s'\n"
                "%s  Accuracy Decimals: %d",
                prefix, type, obj->get_name().c_str(), prefix,
                LOG_STR_ARG(state_class_to_string(obj->get_state_class())), prefix,
                obj->get_unit_of_measurement_ref().c_str(), prefix, obj->get_accuracy_decimals());

  LOG_ENTITY_DEVICE_CLASS(tag, prefix, *obj);
  LOG_ENTITY_ICON(tag, prefix, *obj);

  if (obj->get_force_update()) {
    ESP_LOGV(tag, "%s  Force Update: YES", prefix);
  }
}

// State class strings indexed by StateClass enum (0-4): NONE, MEASUREMENT, TOTAL_INCREASING, TOTAL, MEASUREMENT_ANGLE
PROGMEM_STRING_TABLE(StateClassStrings, "", "measurement", "total_increasing", "total", "measurement_angle");
static_assert(StateClassStrings::COUNT == STATE_CLASS_LAST + 1, "StateClassStrings must match StateClass enum");

const LogString *state_class_to_string(StateClass state_class) {
  // Fallback to index 0 (empty string for STATE_CLASS_NONE) if out of range
  return StateClassStrings::get_log_str(static_cast<uint8_t>(state_class), 0);
}

Sensor::Sensor() : state(NAN) {}

int8_t Sensor::get_accuracy_decimals() {
  if (this->sensor_flags_.has_accuracy_override)
    return this->accuracy_decimals_;
  return 0;
}
void Sensor::set_accuracy_decimals(int8_t accuracy_decimals) {
  this->accuracy_decimals_ = accuracy_decimals;
  this->sensor_flags_.has_accuracy_override = true;
}

void Sensor::set_state_class(StateClass state_class) {
  this->state_class_ = state_class;
  this->sensor_flags_.has_state_class_override = true;
}
StateClass Sensor::get_state_class() {
  if (this->sensor_flags_.has_state_class_override)
    return this->state_class_;
  return StateClass::STATE_CLASS_NONE;
}

void Sensor::publish_state(float state) {
#ifdef USE_SENSOR_FILTER
  this->raw_state_ = state;
  this->raw_callback_.call(state);
#endif

  ESP_LOGV(TAG, "'%s': Received new state %f", this->name_.c_str(), state);

#ifdef USE_SENSOR_FILTER
  if (this->filter_list_ == nullptr) {
#endif
    this->internal_send_state_to_frontend(state);
#ifdef USE_SENSOR_FILTER
  } else {
    this->filter_list_->input(state);
  }
#endif
}

#ifdef USE_SENSOR_FILTER
void Sensor::add_filter(Filter *filter) {
  // inefficient, but only happens once on every sensor setup and nobody's going to have massive amounts of
  // filters
  ESP_LOGVV(TAG, "Sensor(%p)::add_filter(%p)", this, filter);
  if (this->filter_list_ == nullptr) {
    this->filter_list_ = filter;
  } else {
    Filter *last_filter = this->filter_list_;
    while (last_filter->next_ != nullptr)
      last_filter = last_filter->next_;
    last_filter->initialize(this, filter);
  }
  filter->initialize(this, nullptr);
}
void Sensor::add_filters(std::initializer_list<Filter *> filters) {
  for (Filter *filter : filters) {
    this->add_filter(filter);
  }
}
void Sensor::set_filters(std::initializer_list<Filter *> filters) {
  this->clear_filters();
  this->add_filters(filters);
}
void Sensor::clear_filters() {
  if (this->filter_list_ != nullptr) {
    ESP_LOGVV(TAG, "Sensor(%p)::clear_filters()", this);
  }
  this->filter_list_ = nullptr;
}
#endif  // USE_SENSOR_FILTER

void Sensor::internal_send_state_to_frontend(float state) {
  this->set_has_state(true);
  this->state = state;
  ESP_LOGV(TAG, "'%s' >> %.*f %s", this->get_name().c_str(), std::max(0, (int) this->get_accuracy_decimals()), state,
           this->get_unit_of_measurement_ref().c_str());
  this->callback_.call(state);
#if defined(USE_SENSOR) && defined(USE_CONTROLLER_REGISTRY)
  ControllerRegistry::notify_sensor_update(this);
#endif
}

}  // namespace esphome::sensor
