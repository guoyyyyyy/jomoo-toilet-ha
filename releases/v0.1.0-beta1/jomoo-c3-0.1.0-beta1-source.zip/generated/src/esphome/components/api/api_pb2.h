// This file was automatically generated with a tool.
// See script/api_protobuf/api_protobuf.py
#pragma once

#include "esphome/core/string_ref.h"

#include "proto.h"
#include "api_pb2_includes.h"

namespace esphome::api {

// Upper bound on message IDs, enforced by the code generator: the plaintext
// frame header budgets 2 varint bytes for the type (HEADER_PADDING).
static constexpr uint16_t MAX_MESSAGE_TYPE = 16383;

namespace enums {

enum DisconnectReason : uint32_t {
  DISCONNECT_REASON_UNSPECIFIED = 0,
  DISCONNECT_REASON_PROVISIONING_CLOSED = 1,
};
enum SerialProxyPortType : uint32_t {
  SERIAL_PROXY_PORT_TYPE_TTL = 0,
  SERIAL_PROXY_PORT_TYPE_RS232 = 1,
  SERIAL_PROXY_PORT_TYPE_RS485 = 2,
  SERIAL_PROXY_PORT_TYPE_USB_SERIAL = 3,
};
enum EntityCategory : uint32_t {
  ENTITY_CATEGORY_NONE = 0,
  ENTITY_CATEGORY_CONFIG = 1,
  ENTITY_CATEGORY_DIAGNOSTIC = 2,
};
#ifdef USE_COVER
enum CoverOperation : uint32_t {
  COVER_OPERATION_IDLE = 0,
  COVER_OPERATION_IS_OPENING = 1,
  COVER_OPERATION_IS_CLOSING = 2,
};
#endif
#ifdef USE_FAN
enum FanDirection : uint32_t {
  FAN_DIRECTION_FORWARD = 0,
  FAN_DIRECTION_REVERSE = 1,
};
#endif
#ifdef USE_LIGHT
enum ColorMode : uint32_t {
  COLOR_MODE_UNKNOWN = 0,
  COLOR_MODE_ON_OFF = 1,
  COLOR_MODE_LEGACY_BRIGHTNESS = 2,
  COLOR_MODE_BRIGHTNESS = 3,
  COLOR_MODE_WHITE = 7,
  COLOR_MODE_COLOR_TEMPERATURE = 11,
  COLOR_MODE_COLD_WARM_WHITE = 19,
  COLOR_MODE_RGB = 35,
  COLOR_MODE_RGB_WHITE = 39,
  COLOR_MODE_RGB_COLOR_TEMPERATURE = 47,
  COLOR_MODE_RGB_COLD_WARM_WHITE = 51,
};
#endif
#ifdef USE_SENSOR
enum SensorStateClass : uint32_t {
  STATE_CLASS_NONE = 0,
  STATE_CLASS_MEASUREMENT = 1,
  STATE_CLASS_TOTAL_INCREASING = 2,
  STATE_CLASS_TOTAL = 3,
  STATE_CLASS_MEASUREMENT_ANGLE = 4,
};
#endif
enum LogLevel : uint32_t {
  LOG_LEVEL_NONE = 0,
  LOG_LEVEL_ERROR = 1,
  LOG_LEVEL_WARN = 2,
  LOG_LEVEL_INFO = 3,
  LOG_LEVEL_CONFIG = 4,
  LOG_LEVEL_DEBUG = 5,
  LOG_LEVEL_VERBOSE = 6,
  LOG_LEVEL_VERY_VERBOSE = 7,
};
enum DSTRuleType : uint32_t {
  DST_RULE_TYPE_NONE = 0,
  DST_RULE_TYPE_MONTH_WEEK_DAY = 1,
  DST_RULE_TYPE_JULIAN_NO_LEAP = 2,
  DST_RULE_TYPE_DAY_OF_YEAR = 3,
};
#ifdef USE_API_USER_DEFINED_ACTIONS
enum ServiceArgType : uint32_t {
  SERVICE_ARG_TYPE_BOOL = 0,
  SERVICE_ARG_TYPE_INT = 1,
  SERVICE_ARG_TYPE_FLOAT = 2,
  SERVICE_ARG_TYPE_STRING = 3,
  SERVICE_ARG_TYPE_BOOL_ARRAY = 4,
  SERVICE_ARG_TYPE_INT_ARRAY = 5,
  SERVICE_ARG_TYPE_FLOAT_ARRAY = 6,
  SERVICE_ARG_TYPE_STRING_ARRAY = 7,
};
enum SupportsResponseType : uint32_t {
  SUPPORTS_RESPONSE_NONE = 0,
  SUPPORTS_RESPONSE_OPTIONAL = 1,
  SUPPORTS_RESPONSE_ONLY = 2,
  SUPPORTS_RESPONSE_STATUS = 100,
};
#endif
enum TemperatureUnit : uint32_t {
  TEMPERATURE_UNIT_CELSIUS = 0,
  TEMPERATURE_UNIT_FAHRENHEIT = 1,
  TEMPERATURE_UNIT_KELVIN = 2,
};
#ifdef USE_CLIMATE
enum ClimateMode : uint32_t {
  CLIMATE_MODE_OFF = 0,
  CLIMATE_MODE_HEAT_COOL = 1,
  CLIMATE_MODE_COOL = 2,
  CLIMATE_MODE_HEAT = 3,
  CLIMATE_MODE_FAN_ONLY = 4,
  CLIMATE_MODE_DRY = 5,
  CLIMATE_MODE_AUTO = 6,
};
enum ClimateFanMode : uint32_t {
  CLIMATE_FAN_ON = 0,
  CLIMATE_FAN_OFF = 1,
  CLIMATE_FAN_AUTO = 2,
  CLIMATE_FAN_LOW = 3,
  CLIMATE_FAN_MEDIUM = 4,
  CLIMATE_FAN_HIGH = 5,
  CLIMATE_FAN_MIDDLE = 6,
  CLIMATE_FAN_FOCUS = 7,
  CLIMATE_FAN_DIFFUSE = 8,
  CLIMATE_FAN_QUIET = 9,
};
enum ClimateSwingMode : uint32_t {
  CLIMATE_SWING_OFF = 0,
  CLIMATE_SWING_BOTH = 1,
  CLIMATE_SWING_VERTICAL = 2,
  CLIMATE_SWING_HORIZONTAL = 3,
};
enum ClimateAction : uint32_t {
  CLIMATE_ACTION_OFF = 0,
  CLIMATE_ACTION_COOLING = 2,
  CLIMATE_ACTION_HEATING = 3,
  CLIMATE_ACTION_IDLE = 4,
  CLIMATE_ACTION_DRYING = 5,
  CLIMATE_ACTION_FAN = 6,
  CLIMATE_ACTION_DEFROSTING = 7,
};
enum ClimatePreset : uint32_t {
  CLIMATE_PRESET_NONE = 0,
  CLIMATE_PRESET_HOME = 1,
  CLIMATE_PRESET_AWAY = 2,
  CLIMATE_PRESET_BOOST = 3,
  CLIMATE_PRESET_COMFORT = 4,
  CLIMATE_PRESET_ECO = 5,
  CLIMATE_PRESET_SLEEP = 6,
  CLIMATE_PRESET_ACTIVITY = 7,
};
#endif
#ifdef USE_WATER_HEATER
enum WaterHeaterMode : uint32_t {
  WATER_HEATER_MODE_OFF = 0,
  WATER_HEATER_MODE_ECO = 1,
  WATER_HEATER_MODE_ELECTRIC = 2,
  WATER_HEATER_MODE_PERFORMANCE = 3,
  WATER_HEATER_MODE_HIGH_DEMAND = 4,
  WATER_HEATER_MODE_HEAT_PUMP = 5,
  WATER_HEATER_MODE_GAS = 6,
};
#endif
enum WaterHeaterCommandHasField : uint32_t {
  WATER_HEATER_COMMAND_HAS_NONE = 0,
  WATER_HEATER_COMMAND_HAS_MODE = 1,
  WATER_HEATER_COMMAND_HAS_TARGET_TEMPERATURE = 2,
  WATER_HEATER_COMMAND_HAS_STATE = 4,
  WATER_HEATER_COMMAND_HAS_TARGET_TEMPERATURE_LOW = 8,
  WATER_HEATER_COMMAND_HAS_TARGET_TEMPERATURE_HIGH = 16,
  WATER_HEATER_COMMAND_HAS_ON_STATE = 32,
  WATER_HEATER_COMMAND_HAS_AWAY_STATE = 64,
};
#ifdef USE_NUMBER
enum NumberMode : uint32_t {
  NUMBER_MODE_AUTO = 0,
  NUMBER_MODE_BOX = 1,
  NUMBER_MODE_SLIDER = 2,
};
#endif
#ifdef USE_LOCK
enum LockState : uint32_t {
  LOCK_STATE_NONE = 0,
  LOCK_STATE_LOCKED = 1,
  LOCK_STATE_UNLOCKED = 2,
  LOCK_STATE_JAMMED = 3,
  LOCK_STATE_LOCKING = 4,
  LOCK_STATE_UNLOCKING = 5,
  LOCK_STATE_OPENING = 6,
  LOCK_STATE_OPEN = 7,
};
enum LockCommand : uint32_t {
  LOCK_UNLOCK = 0,
  LOCK_LOCK = 1,
  LOCK_OPEN = 2,
};
#endif
#ifdef USE_MEDIA_PLAYER
enum MediaPlayerState : uint32_t {
  MEDIA_PLAYER_STATE_NONE = 0,
  MEDIA_PLAYER_STATE_IDLE = 1,
  MEDIA_PLAYER_STATE_PLAYING = 2,
  MEDIA_PLAYER_STATE_PAUSED = 3,
  MEDIA_PLAYER_STATE_ANNOUNCING = 4,
  MEDIA_PLAYER_STATE_OFF = 5,
  MEDIA_PLAYER_STATE_ON = 6,
};
enum MediaPlayerCommand : uint32_t {
  MEDIA_PLAYER_COMMAND_PLAY = 0,
  MEDIA_PLAYER_COMMAND_PAUSE = 1,
  MEDIA_PLAYER_COMMAND_STOP = 2,
  MEDIA_PLAYER_COMMAND_MUTE = 3,
  MEDIA_PLAYER_COMMAND_UNMUTE = 4,
  MEDIA_PLAYER_COMMAND_TOGGLE = 5,
  MEDIA_PLAYER_COMMAND_VOLUME_UP = 6,
  MEDIA_PLAYER_COMMAND_VOLUME_DOWN = 7,
  MEDIA_PLAYER_COMMAND_ENQUEUE = 8,
  MEDIA_PLAYER_COMMAND_REPEAT_ONE = 9,
  MEDIA_PLAYER_COMMAND_REPEAT_OFF = 10,
  MEDIA_PLAYER_COMMAND_CLEAR_PLAYLIST = 11,
  MEDIA_PLAYER_COMMAND_TURN_ON = 12,
  MEDIA_PLAYER_COMMAND_TURN_OFF = 13,
};
enum MediaPlayerFormatPurpose : uint32_t {
  MEDIA_PLAYER_FORMAT_PURPOSE_DEFAULT = 0,
  MEDIA_PLAYER_FORMAT_PURPOSE_ANNOUNCEMENT = 1,
};
#endif
#ifdef USE_BLUETOOTH_PROXY_CONNECTIONS
enum BluetoothDeviceRequestType : uint32_t {
  BLUETOOTH_DEVICE_REQUEST_TYPE_CONNECT = 0,
  BLUETOOTH_DEVICE_REQUEST_TYPE_DISCONNECT = 1,
  BLUETOOTH_DEVICE_REQUEST_TYPE_PAIR = 2,
  BLUETOOTH_DEVICE_REQUEST_TYPE_UNPAIR = 3,
  BLUETOOTH_DEVICE_REQUEST_TYPE_CONNECT_V3_WITH_CACHE = 4,
  BLUETOOTH_DEVICE_REQUEST_TYPE_CONNECT_V3_WITHOUT_CACHE = 5,
  BLUETOOTH_DEVICE_REQUEST_TYPE_CLEAR_CACHE = 6,
};
#endif
#ifdef USE_BLUETOOTH_PROXY
enum BluetoothScannerState : uint32_t {
  BLUETOOTH_SCANNER_STATE_IDLE = 0,
  BLUETOOTH_SCANNER_STATE_STARTING = 1,
  BLUETOOTH_SCANNER_STATE_RUNNING = 2,
  BLUETOOTH_SCANNER_STATE_FAILED = 3,
  BLUETOOTH_SCANNER_STATE_STOPPING = 4,
  BLUETOOTH_SCANNER_STATE_STOPPED = 5,
};
enum BluetoothScannerMode : uint32_t {
  BLUETOOTH_SCANNER_MODE_PASSIVE = 0,
  BLUETOOTH_SCANNER_MODE_ACTIVE = 1,
};
#endif
enum VoiceAssistantSubscribeFlag : uint32_t {
  VOICE_ASSISTANT_SUBSCRIBE_NONE = 0,
  VOICE_ASSISTANT_SUBSCRIBE_API_AUDIO = 1,
};
enum VoiceAssistantRequestFlag : uint32_t {
  VOICE_ASSISTANT_REQUEST_NONE = 0,
  VOICE_ASSISTANT_REQUEST_USE_VAD = 1,
  VOICE_ASSISTANT_REQUEST_USE_WAKE_WORD = 2,
};
#ifdef USE_VOICE_ASSISTANT
enum VoiceAssistantEvent : uint32_t {
  VOICE_ASSISTANT_ERROR = 0,
  VOICE_ASSISTANT_RUN_START = 1,
  VOICE_ASSISTANT_RUN_END = 2,
  VOICE_ASSISTANT_STT_START = 3,
  VOICE_ASSISTANT_STT_END = 4,
  VOICE_ASSISTANT_INTENT_START = 5,
  VOICE_ASSISTANT_INTENT_END = 6,
  VOICE_ASSISTANT_TTS_START = 7,
  VOICE_ASSISTANT_TTS_END = 8,
  VOICE_ASSISTANT_WAKE_WORD_START = 9,
  VOICE_ASSISTANT_WAKE_WORD_END = 10,
  VOICE_ASSISTANT_STT_VAD_START = 11,
  VOICE_ASSISTANT_STT_VAD_END = 12,
  VOICE_ASSISTANT_TTS_STREAM_START = 98,
  VOICE_ASSISTANT_TTS_STREAM_END = 99,
  VOICE_ASSISTANT_INTENT_PROGRESS = 100,
};
enum VoiceAssistantTimerEvent : uint32_t {
  VOICE_ASSISTANT_TIMER_STARTED = 0,
  VOICE_ASSISTANT_TIMER_UPDATED = 1,
  VOICE_ASSISTANT_TIMER_CANCELLED = 2,
  VOICE_ASSISTANT_TIMER_FINISHED = 3,
};
#endif
#ifdef USE_ALARM_CONTROL_PANEL
enum AlarmControlPanelState : uint32_t {
  ALARM_STATE_DISARMED = 0,
  ALARM_STATE_ARMED_HOME = 1,
  ALARM_STATE_ARMED_AWAY = 2,
  ALARM_STATE_ARMED_NIGHT = 3,
  ALARM_STATE_ARMED_VACATION = 4,
  ALARM_STATE_ARMED_CUSTOM_BYPASS = 5,
  ALARM_STATE_PENDING = 6,
  ALARM_STATE_ARMING = 7,
  ALARM_STATE_DISARMING = 8,
  ALARM_STATE_TRIGGERED = 9,
};
enum AlarmControlPanelStateCommand : uint32_t {
  ALARM_CONTROL_PANEL_DISARM = 0,
  ALARM_CONTROL_PANEL_ARM_AWAY = 1,
  ALARM_CONTROL_PANEL_ARM_HOME = 2,
  ALARM_CONTROL_PANEL_ARM_NIGHT = 3,
  ALARM_CONTROL_PANEL_ARM_VACATION = 4,
  ALARM_CONTROL_PANEL_ARM_CUSTOM_BYPASS = 5,
  ALARM_CONTROL_PANEL_TRIGGER = 6,
};
#endif
#ifdef USE_TEXT
enum TextMode : uint32_t {
  TEXT_MODE_TEXT = 0,
  TEXT_MODE_PASSWORD = 1,
};
#endif
#ifdef USE_VALVE
enum ValveOperation : uint32_t {
  VALVE_OPERATION_IDLE = 0,
  VALVE_OPERATION_IS_OPENING = 1,
  VALVE_OPERATION_IS_CLOSING = 2,
};
#endif
#ifdef USE_UPDATE
enum UpdateCommand : uint32_t {
  UPDATE_COMMAND_NONE = 0,
  UPDATE_COMMAND_UPDATE = 1,
  UPDATE_COMMAND_CHECK = 2,
};
#endif
#ifdef USE_ZWAVE_PROXY
enum ZWaveProxyRequestType : uint32_t {
  ZWAVE_PROXY_REQUEST_TYPE_SUBSCRIBE = 0,
  ZWAVE_PROXY_REQUEST_TYPE_UNSUBSCRIBE = 1,
  ZWAVE_PROXY_REQUEST_TYPE_HOME_ID_CHANGE = 2,
};
enum ZWaveProxyStatus : uint32_t {
  ZWAVE_PROXY_STATUS_OK = 0,
  ZWAVE_PROXY_STATUS_IN_USE = 1,
  ZWAVE_PROXY_STATUS_NOT_SUPPORTED = 2,
};
#endif
#ifdef USE_SERIAL_PROXY
enum SerialProxyParity : uint32_t {
  SERIAL_PROXY_PARITY_NONE = 0,
  SERIAL_PROXY_PARITY_EVEN = 1,
  SERIAL_PROXY_PARITY_ODD = 2,
};
enum SerialProxyRequestType : uint32_t {
  SERIAL_PROXY_REQUEST_TYPE_SUBSCRIBE = 0,
  SERIAL_PROXY_REQUEST_TYPE_UNSUBSCRIBE = 1,
  SERIAL_PROXY_REQUEST_TYPE_FLUSH = 2,
  SERIAL_PROXY_REQUEST_TYPE_CONFIGURE = 3,
  SERIAL_PROXY_REQUEST_TYPE_SET_MODEM_PINS = 4,
  SERIAL_PROXY_REQUEST_TYPE_SET_MODE = 5,
};
enum SerialProxyStatus : uint32_t {
  SERIAL_PROXY_STATUS_OK = 0,
  SERIAL_PROXY_STATUS_ASSUMED_SUCCESS = 1,
  SERIAL_PROXY_STATUS_ERROR = 2,
  SERIAL_PROXY_STATUS_TIMEOUT = 3,
  SERIAL_PROXY_STATUS_NOT_SUPPORTED = 4,
  SERIAL_PROXY_STATUS_PORT_IN_USE = 5,
  SERIAL_PROXY_STATUS_INVALID_ARGUMENT = 6,
};
enum SerialProxyMode : uint32_t {
  SERIAL_PROXY_MODE_RAW = 0,
  SERIAL_PROXY_MODE_PROTOCOL = 1,
};
enum SerialProxyIdentitySource : uint32_t {
  SERIAL_PROXY_IDENTITY_SOURCE_NONE = 0,
  SERIAL_PROXY_IDENTITY_SOURCE_CONFIGURED = 1,
  SERIAL_PROXY_IDENTITY_SOURCE_USB = 2,
};
#endif
enum SerialProxyIdentityFlag : uint32_t {
  SERIAL_PROXY_IDENTITY_FLAG_NONE = 0,
  SERIAL_PROXY_IDENTITY_FLAG_CONNECTED = 1,
  SERIAL_PROXY_IDENTITY_FLAG_ERROR = 2,
};
#ifdef USE_SENDSPIN
enum SendspinPairingTokenStatus : uint32_t {
  SENDSPIN_PAIRING_TOKEN_STATUS_NOT_READY = 0,
  SENDSPIN_PAIRING_TOKEN_STATUS_OK = 1,
  SENDSPIN_PAIRING_TOKEN_STATUS_ENCRYPTION_REQUIRED = 2,
  SENDSPIN_PAIRING_TOKEN_STATUS_DISABLED = 3,
  SENDSPIN_PAIRING_TOKEN_STATUS_FAILED = 4,
};
#endif

}  // namespace enums

class InfoResponseProtoMessage : public ProtoMessage {
 public:
  StringRef object_id{};
  uint32_t key{0};
  StringRef name{};
  bool disabled_by_default{false};
#ifdef USE_ENTITY_ICON
  StringRef icon{nullptr, 0};  // null until set, encode only
#endif
  enums::EntityCategory entity_category{};
#ifdef USE_DEVICES
  uint32_t device_id{0};
#endif

 protected:
  ~InfoResponseProtoMessage() = default;
};

class StateResponseProtoMessage : public ProtoMessage {
 public:
  uint32_t key{0};
#ifdef USE_DEVICES
  uint32_t device_id{0};
#endif

 protected:
  ~StateResponseProtoMessage() = default;
};

class CommandProtoMessage : public ProtoDecodableMessage {
 public:
  uint32_t key{0};
#ifdef USE_DEVICES
  uint32_t device_id{0};
#endif

 protected:
  ~CommandProtoMessage() = default;
};
class HelloRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 1;
  static constexpr uint8_t ESTIMATED_SIZE = 19;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("hello_request"); }
#endif
  StringRef client_info{};
  uint32_t api_version_major{0};
  uint32_t api_version_minor{0};
#ifdef USE_API_OUTGOING_CONNECTION
  bool outgoing_connection_target{false};
#endif
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class HelloResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 2;
  static constexpr uint8_t ESTIMATED_SIZE = 26;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("hello_response"); }
#endif
  uint32_t api_version_major{0};
  uint32_t api_version_minor{0};
  StringRef server_info{};
  StringRef name{};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class DisconnectRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 5;
  static constexpr uint8_t ESTIMATED_SIZE = 2;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("disconnect_request"); }
#endif
  enums::DisconnectReason reason{};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class DisconnectResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 6;
  static constexpr uint8_t ESTIMATED_SIZE = 0;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("disconnect_response"); }
#endif
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class PingRequest final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 7;
  static constexpr uint8_t ESTIMATED_SIZE = 0;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("ping_request"); }
#endif
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class PingResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 8;
  static constexpr uint8_t ESTIMATED_SIZE = 0;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("ping_response"); }
#endif
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#ifdef USE_AREAS
class AreaInfo final : public ProtoMessage {
 public:
  uint32_t area_id{0};
  StringRef name{};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#endif
#ifdef USE_DEVICES
class DeviceInfo final : public ProtoMessage {
 public:
  uint32_t device_id{0};
  StringRef name{};
  uint32_t area_id{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#endif
#ifdef USE_SERIAL_PROXY
class SerialProxyInfo final : public ProtoMessage {
 public:
  StringRef name{nullptr, 0};  // null until set, encode only
  enums::SerialProxyPortType port_type{};
  uint32_t configured_line_states{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#endif
class DeviceInfoResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 10;
  static constexpr uint16_t ESTIMATED_SIZE = 315;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("device_info_response"); }
#endif
  StringRef name{};
  StringRef mac_address{};
  StringRef esphome_version{};
  StringRef compilation_time{};
  StringRef model{};
#ifdef USE_DEEP_SLEEP
  bool has_deep_sleep{false};
#endif
#ifdef ESPHOME_PROJECT_NAME
  StringRef project_name{};
#endif
#ifdef ESPHOME_PROJECT_NAME
  StringRef project_version{};
#endif
#ifdef USE_WEBSERVER
  uint32_t webserver_port{0};
#endif
#ifdef USE_BLUETOOTH_PROXY
  uint32_t bluetooth_proxy_feature_flags{0};
#endif
  StringRef manufacturer{};
  StringRef friendly_name{};
#ifdef USE_VOICE_ASSISTANT
  uint32_t voice_assistant_feature_flags{0};
#endif
#ifdef USE_AREAS
  StringRef suggested_area{};
#endif
#ifdef USE_BLUETOOTH_PROXY
  StringRef bluetooth_mac_address{};
#endif
#ifdef USE_API_NOISE
  bool api_encryption_supported{false};
#endif
#ifdef USE_DEVICES
  std::array<DeviceInfo, ESPHOME_DEVICE_COUNT> devices{};
#endif
#ifdef USE_AREAS
  std::array<AreaInfo, ESPHOME_AREA_COUNT> areas{};
#endif
#ifdef USE_AREAS
  AreaInfo area{};
#endif
#ifdef USE_ZWAVE_PROXY
  uint32_t zwave_proxy_feature_flags{0};
#endif
#ifdef USE_ZWAVE_PROXY
  uint32_t zwave_home_id{0};
#endif
#ifdef USE_SERIAL_PROXY
  std::array<SerialProxyInfo, SERIAL_PROXY_COUNT> serial_proxies{};
#endif
#ifdef USE_API_NOISE
  bool api_encryption_provisionable{false};
#endif
#ifdef USE_API_OUTGOING_CONNECTION
  bool api_outgoing_connection_supported{false};
#endif
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#ifdef USE_BLUETOOTH_PROXY
class BluetoothProxyCapabilities final : public ProtoMessage {
 public:
  uint32_t feature_flags{0};
  StringRef mac_address{};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#endif
#ifdef USE_VOICE_ASSISTANT
class VoiceAssistantCapabilities final : public ProtoMessage {
 public:
  uint32_t feature_flags{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#endif
#ifdef USE_ZWAVE_PROXY
class ZWaveProxyCapabilities final : public ProtoMessage {
 public:
  uint32_t feature_flags{0};
  uint32_t home_id{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#endif
#ifdef USE_API_WIZARD
class WizardCapabilities final : public ProtoMessage {
 public:
  bool configured{false};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#endif
#ifdef USE_SENDSPIN
class SendspinCapabilities final : public ProtoMessage {
 public:
  uint32_t feature_flags{0};
  StringRef client_id{nullptr, 0};  // null until set, encode only
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#endif
class DeviceCapabilitiesResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 150;
  static constexpr uint8_t ESTIMATED_SIZE = 136;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("device_capabilities_response"); }
#endif
#ifdef USE_BLUETOOTH_PROXY
  BluetoothProxyCapabilities bluetooth_proxy{};
#endif
#ifdef USE_VOICE_ASSISTANT
  VoiceAssistantCapabilities voice_assistant{};
#endif
#ifdef USE_ZWAVE_PROXY
  ZWaveProxyCapabilities zwave_proxy{};
#endif
#ifdef USE_SERIAL_PROXY
  std::array<SerialProxyInfo, SERIAL_PROXY_COUNT> serial_proxies{};
#endif
#ifdef USE_API_WIZARD
  WizardCapabilities wizard{};
#endif
#ifdef USE_SENDSPIN
  SendspinCapabilities sendspin{};
#endif
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#ifdef USE_API_WIZARD
class DeviceWizardResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 157;
  static constexpr uint8_t ESTIMATED_SIZE = 19;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("device_wizard_response"); }
#endif
  const uint8_t *data{nullptr};
  uint16_t data_len{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#endif
#ifdef USE_API_WIZARD_INPUTS
class WizardInputSetRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 158;
  static constexpr uint8_t ESTIMATED_SIZE = 14;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("wizard_input_set_request"); }
#endif
  uint32_t key{0};
  StringRef entity_id{};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#endif
class ListEntitiesDoneResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 19;
  static constexpr uint8_t ESTIMATED_SIZE = 0;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_done_response"); }
#endif
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#ifdef USE_BINARY_SENSOR
class ListEntitiesBinarySensorResponse final : public InfoResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 12;
  static constexpr uint8_t ESTIMATED_SIZE = 51;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_binary_sensor_response"); }
#endif
  StringRef device_class{nullptr, 0};  // null until set, encode only
  bool is_status_binary_sensor{false};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class BinarySensorStateResponse final : public StateResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 21;
  static constexpr uint8_t ESTIMATED_SIZE = 13;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("binary_sensor_state_response"); }
#endif
  bool state{false};
  bool missing_state{false};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#endif
#ifdef USE_COVER
class ListEntitiesCoverResponse final : public InfoResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 13;
  static constexpr uint8_t ESTIMATED_SIZE = 57;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_cover_response"); }
#endif
  bool assumed_state{false};
  bool supports_position{false};
  bool supports_tilt{false};
  StringRef device_class{nullptr, 0};  // null until set, encode only
  bool supports_stop{false};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class CoverStateResponse final : public StateResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 22;
  static constexpr uint8_t ESTIMATED_SIZE = 21;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("cover_state_response"); }
#endif
  float position{0.0f};
  float tilt{0.0f};
  enums::CoverOperation current_operation{};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class CoverCommandRequest final : public CommandProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 30;
  static constexpr uint8_t ESTIMATED_SIZE = 25;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("cover_command_request"); }
#endif
  bool has_position{false};
  float position{0.0f};
  bool has_tilt{false};
  float tilt{0.0f};
  bool stop{false};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#endif
#ifdef USE_FAN
class ListEntitiesFanResponse final : public InfoResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 14;
  static constexpr uint8_t ESTIMATED_SIZE = 68;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_fan_response"); }
#endif
  bool supports_oscillation{false};
  bool supports_speed{false};
  bool supports_direction{false};
  int32_t supported_speed_count{0};
  const std::vector<const char *> *supported_preset_modes{};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class FanStateResponse final : public StateResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 23;
  static constexpr uint8_t ESTIMATED_SIZE = 28;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("fan_state_response"); }
#endif
  bool state{false};
  bool oscillating{false};
  enums::FanDirection direction{};
  int32_t speed_level{0};
  StringRef preset_mode{nullptr, 0};  // null until set, encode only
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class FanCommandRequest final : public CommandProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 31;
  static constexpr uint8_t ESTIMATED_SIZE = 38;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("fan_command_request"); }
#endif
  bool has_state{false};
  bool state{false};
  bool has_oscillating{false};
  bool oscillating{false};
  bool has_direction{false};
  enums::FanDirection direction{};
  bool has_speed_level{false};
  int32_t speed_level{0};
  bool has_preset_mode{false};
  StringRef preset_mode{};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#endif
#ifdef USE_LIGHT
class ListEntitiesLightResponse final : public InfoResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 15;
  static constexpr uint8_t ESTIMATED_SIZE = 73;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_light_response"); }
#endif
  const light::ColorModeMask *supported_color_modes{};
  float min_mireds{0.0f};
  float max_mireds{0.0f};
  const FixedVector<const char *> *effects{};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class LightStateResponse final : public StateResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 24;
  static constexpr uint8_t ESTIMATED_SIZE = 67;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("light_state_response"); }
#endif
  bool state{false};
  float brightness{0.0f};
  enums::ColorMode color_mode{};
  float color_brightness{0.0f};
  float red{0.0f};
  float green{0.0f};
  float blue{0.0f};
  float white{0.0f};
  float color_temperature{0.0f};
  float cold_white{0.0f};
  float warm_white{0.0f};
  StringRef effect{nullptr, 0};  // null until set, encode only
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class LightCommandRequest final : public CommandProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 32;
  static constexpr uint8_t ESTIMATED_SIZE = 112;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("light_command_request"); }
#endif
  bool has_state{false};
  bool state{false};
  bool has_brightness{false};
  float brightness{0.0f};
  bool has_color_mode{false};
  enums::ColorMode color_mode{};
  bool has_color_brightness{false};
  float color_brightness{0.0f};
  bool has_rgb{false};
  float red{0.0f};
  float green{0.0f};
  float blue{0.0f};
  bool has_white{false};
  float white{0.0f};
  bool has_color_temperature{false};
  float color_temperature{0.0f};
  bool has_cold_white{false};
  float cold_white{0.0f};
  bool has_warm_white{false};
  float warm_white{0.0f};
  bool has_transition_length{false};
  uint32_t transition_length{0};
  bool has_flash_length{false};
  uint32_t flash_length{0};
  bool has_effect{false};
  StringRef effect{};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#endif
#ifdef USE_SENSOR
class ListEntitiesSensorResponse final : public InfoResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 16;
  static constexpr uint8_t ESTIMATED_SIZE = 66;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_sensor_response"); }
#endif
  StringRef unit_of_measurement{nullptr, 0};  // null until set, encode only
  int32_t accuracy_decimals{0};
  bool force_update{false};
  StringRef device_class{nullptr, 0};  // null until set, encode only
  enums::SensorStateClass state_class{};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class SensorStateResponse final : public StateResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 25;
  static constexpr uint8_t ESTIMATED_SIZE = 16;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("sensor_state_response"); }
#endif
  float state{0.0f};
  bool missing_state{false};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#endif
#ifdef USE_SWITCH
class ListEntitiesSwitchResponse final : public InfoResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 17;
  static constexpr uint8_t ESTIMATED_SIZE = 51;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_switch_response"); }
#endif
  bool assumed_state{false};
  StringRef device_class{nullptr, 0};  // null until set, encode only
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class SwitchStateResponse final : public StateResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 26;
  static constexpr uint8_t ESTIMATED_SIZE = 13;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("switch_state_response"); }
#endif
  bool state{false};
  bool missing_state{false};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class SwitchCommandRequest final : public CommandProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 33;
  static constexpr uint8_t ESTIMATED_SIZE = 11;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("switch_command_request"); }
#endif
  bool state{false};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#endif
#ifdef USE_TEXT_SENSOR
class ListEntitiesTextSensorResponse final : public InfoResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 18;
  static constexpr uint8_t ESTIMATED_SIZE = 49;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_text_sensor_response"); }
#endif
  StringRef device_class{nullptr, 0};  // null until set, encode only
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class TextSensorStateResponse final : public StateResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 27;
  static constexpr uint8_t ESTIMATED_SIZE = 20;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("text_sensor_state_response"); }
#endif
  StringRef state{nullptr, 0};  // null until set, encode only
  bool missing_state{false};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#endif
class SubscribeLogsRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 28;
  static constexpr uint8_t ESTIMATED_SIZE = 4;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("subscribe_logs_request"); }
#endif
  enums::LogLevel level{};
  bool dump_config{false};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class SubscribeLogsResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 29;
  static constexpr uint8_t ESTIMATED_SIZE = 21;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("subscribe_logs_response"); }
#endif
  enums::LogLevel level{};
  const uint8_t *message_ptr_{nullptr};
  size_t message_len_{0};
  void set_message(const uint8_t *data, size_t len) {
    this->message_ptr_ = data;
    this->message_len_ = len;
  }
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#ifdef USE_API_NOISE
class NoiseEncryptionSetKeyRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 124;
  static constexpr uint8_t ESTIMATED_SIZE = 19;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("noise_encryption_set_key_request"); }
#endif
  const uint8_t *key{nullptr};
  uint16_t key_len{0};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class NoiseEncryptionSetKeyResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 125;
  static constexpr uint8_t ESTIMATED_SIZE = 2;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("noise_encryption_set_key_response"); }
#endif
  bool success{false};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#endif
#ifdef USE_API_HOMEASSISTANT_SERVICES
class HomeassistantServiceMap final : public ProtoMessage {
 public:
  StringRef key{nullptr, 0};    // null until set, encode only
  StringRef value{nullptr, 0};  // null until set, encode only
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class HomeassistantActionRequest final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 35;
  static constexpr uint8_t ESTIMATED_SIZE = 128;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("homeassistant_action_request"); }
#endif
  StringRef service{nullptr, 0};  // null until set, encode only
  FixedVector<HomeassistantServiceMap> data{};
  FixedVector<HomeassistantServiceMap> data_template{};
  FixedVector<HomeassistantServiceMap> variables{};
  bool is_event{false};
#ifdef USE_API_HOMEASSISTANT_ACTION_RESPONSES
  uint32_t call_id{0};
#endif
#ifdef USE_API_HOMEASSISTANT_ACTION_RESPONSES_JSON
  bool wants_response{false};
#endif
#ifdef USE_API_HOMEASSISTANT_ACTION_RESPONSES_JSON
  StringRef response_template{nullptr, 0};  // null until set, encode only
#endif
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#endif
#ifdef USE_API_HOMEASSISTANT_ACTION_RESPONSES
class HomeassistantActionResponse final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 130;
  static constexpr uint8_t ESTIMATED_SIZE = 34;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("homeassistant_action_response"); }
#endif
  uint32_t call_id{0};
  bool success{false};
  StringRef error_message{};
#ifdef USE_API_HOMEASSISTANT_ACTION_RESPONSES_JSON
  const uint8_t *response_data{nullptr};
  uint16_t response_data_len{0};
#endif
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#endif
#ifdef USE_API_HOMEASSISTANT_STATES
class SubscribeHomeAssistantStateResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 39;
  static constexpr uint8_t ESTIMATED_SIZE = 20;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("subscribe_home_assistant_state_response"); }
#endif
  StringRef entity_id{nullptr, 0};  // null until set, encode only
  StringRef attribute{nullptr, 0};  // null until set, encode only
  bool once{false};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class HomeAssistantStateResponse final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 40;
  static constexpr uint8_t ESTIMATED_SIZE = 27;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("home_assistant_state_response"); }
#endif
  StringRef entity_id{};
  StringRef state{};
  StringRef attribute{};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#endif
class GetTimeRequest final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 36;
  static constexpr uint8_t ESTIMATED_SIZE = 0;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("get_time_request"); }
#endif
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class DSTRule final : public ProtoDecodableMessage {
 public:
  int32_t time_seconds{0};
  uint32_t day{0};
  enums::DSTRuleType type{};
  uint32_t month{0};
  uint32_t week{0};
  uint32_t day_of_week{0};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class ParsedTimezone final : public ProtoDecodableMessage {
 public:
  int32_t std_offset_seconds{0};
  int32_t dst_offset_seconds{0};
  DSTRule dst_start{};
  DSTRule dst_end{};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class GetTimeResponse final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 37;
  static constexpr uint8_t ESTIMATED_SIZE = 22;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("get_time_response"); }
#endif
  uint32_t epoch_seconds{0};
  ParsedTimezone parsed_timezone{};
  bool has_parsed_timezone{false};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#ifdef USE_API_USER_DEFINED_ACTIONS
class ListEntitiesServicesArgument final : public ProtoMessage {
 public:
  StringRef name{nullptr, 0};  // null until set, encode only
  enums::ServiceArgType type{};
#ifdef USE_API_USER_DEFINED_ACTION_METADATA
  StringRef description{nullptr, 0};  // null until set, encode only
#endif
#ifdef USE_API_USER_DEFINED_ACTION_METADATA
  StringRef example{nullptr, 0};  // null until set, encode only
#endif
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class ListEntitiesServicesResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 41;
  static constexpr uint8_t ESTIMATED_SIZE = 59;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_services_response"); }
#endif
  StringRef name{nullptr, 0};  // null until set, encode only
  uint32_t key{0};
  FixedVector<ListEntitiesServicesArgument> args{};
  enums::SupportsResponseType supports_response{};
#ifdef USE_API_USER_DEFINED_ACTION_METADATA
  StringRef description{nullptr, 0};  // null until set, encode only
#endif
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class ExecuteServiceArgument final : public ProtoDecodableMessage {
 public:
  bool bool_{false};
  int32_t legacy_int{0};
  float float_{0.0f};
  StringRef string_{};
  int32_t int_{0};
  FixedVector<bool> bool_array{};
  FixedVector<int32_t> int_array{};
  FixedVector<float> float_array{};
  FixedVector<std::string> string_array{};
  void decode(const uint8_t *buffer, size_t length);
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class ExecuteServiceRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 42;
  static constexpr uint8_t ESTIMATED_SIZE = 45;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("execute_service_request"); }
#endif
  uint32_t key{0};
  FixedVector<ExecuteServiceArgument> args{};
#ifdef USE_API_USER_DEFINED_ACTION_RESPONSES
  uint32_t call_id{0};
#endif
#ifdef USE_API_USER_DEFINED_ACTION_RESPONSES
  bool return_response{false};
#endif
  void decode(const uint8_t *buffer, size_t length);
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#endif
#ifdef USE_API_USER_DEFINED_ACTION_RESPONSES
class ExecuteServiceResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 131;
  static constexpr uint8_t ESTIMATED_SIZE = 34;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("execute_service_response"); }
#endif
  uint32_t call_id{0};
  bool success{false};
  StringRef error_message{nullptr, 0};  // null until set, encode only
#ifdef USE_API_USER_DEFINED_ACTION_RESPONSES_JSON
  const uint8_t *response_data{nullptr};
  uint16_t response_data_len{0};
#endif
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#endif
#ifdef USE_CAMERA
class ListEntitiesCameraResponse final : public InfoResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 43;
  static constexpr uint8_t ESTIMATED_SIZE = 40;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_camera_response"); }
#endif
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class CameraImageResponse final : public StateResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 44;
  static constexpr uint8_t ESTIMATED_SIZE = 30;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("camera_image_response"); }
#endif
  const uint8_t *data_ptr_{nullptr};
  size_t data_len_{0};
  void set_data(const uint8_t *data, size_t len) {
    this->data_ptr_ = data;
    this->data_len_ = len;
  }
  bool done{false};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class CameraImageRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 45;
  static constexpr uint8_t ESTIMATED_SIZE = 4;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("camera_image_request"); }
#endif
  bool single{false};
  bool stream{false};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#endif
#ifdef USE_CLIMATE
class ListEntitiesClimateResponse final : public InfoResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 46;
  static constexpr uint8_t ESTIMATED_SIZE = 153;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_climate_response"); }
#endif
  bool supports_current_temperature{false};
  bool supports_two_point_target_temperature{false};
  const climate::ClimateModeMask *supported_modes{};
  float visual_min_temperature{0.0f};
  float visual_max_temperature{0.0f};
  float visual_target_temperature_step{0.0f};
  bool supports_action{false};
  const climate::ClimateFanModeMask *supported_fan_modes{};
  const climate::ClimateSwingModeMask *supported_swing_modes{};
  const std::vector<const char *> *supported_custom_fan_modes{};
  const climate::ClimatePresetMask *supported_presets{};
  const std::vector<const char *> *supported_custom_presets{};
  float visual_current_temperature_step{0.0f};
  bool supports_current_humidity{false};
  bool supports_target_humidity{false};
  float visual_min_humidity{0.0f};
  float visual_max_humidity{0.0f};
  uint32_t feature_flags{0};
  enums::TemperatureUnit temperature_unit{};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class ClimateStateResponse final : public StateResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 47;
  static constexpr uint8_t ESTIMATED_SIZE = 71;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("climate_state_response"); }
#endif
  enums::ClimateMode mode{};
  float current_temperature{0.0f};
  float target_temperature{0.0f};
  float target_temperature_low{0.0f};
  float target_temperature_high{0.0f};
  enums::ClimateAction action{};
  enums::ClimateFanMode fan_mode{};
  enums::ClimateSwingMode swing_mode{};
  StringRef custom_fan_mode{nullptr, 0};  // null until set, encode only
  enums::ClimatePreset preset{};
  StringRef custom_preset{nullptr, 0};  // null until set, encode only
  float current_humidity{0.0f};
  float target_humidity{0.0f};
  bool missing_state{false};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class ClimateCommandRequest final : public CommandProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 48;
  static constexpr uint8_t ESTIMATED_SIZE = 84;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("climate_command_request"); }
#endif
  bool has_mode{false};
  enums::ClimateMode mode{};
  bool has_target_temperature{false};
  float target_temperature{0.0f};
  bool has_target_temperature_low{false};
  float target_temperature_low{0.0f};
  bool has_target_temperature_high{false};
  float target_temperature_high{0.0f};
  bool has_fan_mode{false};
  enums::ClimateFanMode fan_mode{};
  bool has_swing_mode{false};
  enums::ClimateSwingMode swing_mode{};
  bool has_custom_fan_mode{false};
  StringRef custom_fan_mode{};
  bool has_preset{false};
  enums::ClimatePreset preset{};
  bool has_custom_preset{false};
  StringRef custom_preset{};
  bool has_target_humidity{false};
  float target_humidity{0.0f};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#endif
#ifdef USE_WATER_HEATER
class ListEntitiesWaterHeaterResponse final : public InfoResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 132;
  static constexpr uint8_t ESTIMATED_SIZE = 65;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_water_heater_response"); }
#endif
  float min_temperature{0.0f};
  float max_temperature{0.0f};
  float target_temperature_step{0.0f};
  const water_heater::WaterHeaterModeMask *supported_modes{};
  uint32_t supported_features{0};
  enums::TemperatureUnit temperature_unit{};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class WaterHeaterStateResponse final : public StateResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 133;
  static constexpr uint8_t ESTIMATED_SIZE = 37;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("water_heater_state_response"); }
#endif
  float current_temperature{0.0f};
  float target_temperature{0.0f};
  enums::WaterHeaterMode mode{};
  uint32_t state{0};
  float target_temperature_low{0.0f};
  float target_temperature_high{0.0f};
  bool missing_state{false};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class WaterHeaterCommandRequest final : public CommandProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 134;
  static constexpr uint8_t ESTIMATED_SIZE = 34;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("water_heater_command_request"); }
#endif
  uint32_t has_fields{0};
  enums::WaterHeaterMode mode{};
  float target_temperature{0.0f};
  uint32_t state{0};
  float target_temperature_low{0.0f};
  float target_temperature_high{0.0f};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#endif
#ifdef USE_NUMBER
class ListEntitiesNumberResponse final : public InfoResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 49;
  static constexpr uint8_t ESTIMATED_SIZE = 75;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_number_response"); }
#endif
  float min_value{0.0f};
  float max_value{0.0f};
  float step{0.0f};
  StringRef unit_of_measurement{nullptr, 0};  // null until set, encode only
  enums::NumberMode mode{};
  StringRef device_class{nullptr, 0};  // null until set, encode only
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class NumberStateResponse final : public StateResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 50;
  static constexpr uint8_t ESTIMATED_SIZE = 16;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("number_state_response"); }
#endif
  float state{0.0f};
  bool missing_state{false};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class NumberCommandRequest final : public CommandProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 51;
  static constexpr uint8_t ESTIMATED_SIZE = 14;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("number_command_request"); }
#endif
  float state{0.0f};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#endif
#ifdef USE_SELECT
class ListEntitiesSelectResponse final : public InfoResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 52;
  static constexpr uint8_t ESTIMATED_SIZE = 58;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_select_response"); }
#endif
  const std::span<const char *const> *options{};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class SelectStateResponse final : public StateResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 53;
  static constexpr uint8_t ESTIMATED_SIZE = 20;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("select_state_response"); }
#endif
  StringRef state{nullptr, 0};  // null until set, encode only
  bool missing_state{false};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class SelectCommandRequest final : public CommandProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 54;
  static constexpr uint8_t ESTIMATED_SIZE = 18;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("select_command_request"); }
#endif
  StringRef state{};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#endif
#ifdef USE_SIREN
class ListEntitiesSirenResponse final : public InfoResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 55;
  static constexpr uint8_t ESTIMATED_SIZE = 62;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_siren_response"); }
#endif
  const FixedVector<const char *> *tones{};
  bool supports_duration{false};
  bool supports_volume{false};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class SirenStateResponse final : public StateResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 56;
  static constexpr uint8_t ESTIMATED_SIZE = 11;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("siren_state_response"); }
#endif
  bool state{false};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class SirenCommandRequest final : public CommandProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 57;
  static constexpr uint8_t ESTIMATED_SIZE = 37;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("siren_command_request"); }
#endif
  bool has_state{false};
  bool state{false};
  bool has_tone{false};
  StringRef tone{};
  bool has_duration{false};
  uint32_t duration{0};
  bool has_volume{false};
  float volume{0.0f};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#endif
#ifdef USE_LOCK
class ListEntitiesLockResponse final : public InfoResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 58;
  static constexpr uint8_t ESTIMATED_SIZE = 55;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_lock_response"); }
#endif
  bool assumed_state{false};
  bool supports_open{false};
  bool requires_code{false};
  StringRef code_format{nullptr, 0};  // null until set, encode only
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class LockStateResponse final : public StateResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 59;
  static constexpr uint8_t ESTIMATED_SIZE = 11;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("lock_state_response"); }
#endif
  enums::LockState state{};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class LockCommandRequest final : public CommandProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 60;
  static constexpr uint8_t ESTIMATED_SIZE = 22;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("lock_command_request"); }
#endif
  enums::LockCommand command{};
  bool has_code{false};
  StringRef code{};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#endif
#ifdef USE_BUTTON
class ListEntitiesButtonResponse final : public InfoResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 61;
  static constexpr uint8_t ESTIMATED_SIZE = 49;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_button_response"); }
#endif
  StringRef device_class{nullptr, 0};  // null until set, encode only
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class ButtonCommandRequest final : public CommandProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 62;
  static constexpr uint8_t ESTIMATED_SIZE = 9;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("button_command_request"); }
#endif
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#endif
#ifdef USE_MEDIA_PLAYER
class MediaPlayerSupportedFormat final : public ProtoMessage {
 public:
  StringRef format{nullptr, 0};  // null until set, encode only
  uint32_t sample_rate{0};
  uint32_t num_channels{0};
  enums::MediaPlayerFormatPurpose purpose{};
  uint32_t sample_bytes{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class ListEntitiesMediaPlayerResponse final : public InfoResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 63;
  static constexpr uint8_t ESTIMATED_SIZE = 78;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_media_player_response"); }
#endif
  std::vector<MediaPlayerSupportedFormat> supported_formats{};
  uint32_t feature_flags{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class MediaPlayerStateResponse final : public StateResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 64;
  static constexpr uint8_t ESTIMATED_SIZE = 18;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("media_player_state_response"); }
#endif
  enums::MediaPlayerState state{};
  float volume{0.0f};
  bool muted{false};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class MediaPlayerCommandRequest final : public CommandProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 65;
  static constexpr uint8_t ESTIMATED_SIZE = 35;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("media_player_command_request"); }
#endif
  bool has_command{false};
  enums::MediaPlayerCommand command{};
  bool has_volume{false};
  float volume{0.0f};
  bool has_media_url{false};
  StringRef media_url{};
  bool has_announcement{false};
  bool announcement{false};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#endif
#ifdef USE_BLUETOOTH_PROXY
class SubscribeBluetoothLEAdvertisementsRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 66;
  static constexpr uint8_t ESTIMATED_SIZE = 4;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("subscribe_bluetooth_le_advertisements_request"); }
#endif
  uint32_t flags{0};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class BluetoothLERawAdvertisement final : public ProtoMessage {
 public:
  uint64_t address{0};
  int32_t rssi{0};
  uint32_t address_type{0};
  uint8_t data[62]{};
  uint8_t data_len{0};
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class BluetoothLERawAdvertisementsResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 93;
  static constexpr uint8_t ESTIMATED_SIZE = 136;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("bluetooth_le_raw_advertisements_response"); }
#endif
  std::array<BluetoothLERawAdvertisement, BLUETOOTH_PROXY_ADVERTISEMENT_BATCH_SIZE> advertisements{};
  uint16_t advertisements_len{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#endif
#ifdef USE_BLUETOOTH_PROXY_CONNECTIONS
class BluetoothDeviceRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 68;
  static constexpr uint8_t ESTIMATED_SIZE = 12;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("bluetooth_device_request"); }
#endif
  uint64_t address{0};
  enums::BluetoothDeviceRequestType request_type{};
  bool has_address_type{false};
  uint32_t address_type{0};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class BluetoothDeviceConnectionResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 69;
  static constexpr uint8_t ESTIMATED_SIZE = 14;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("bluetooth_device_connection_response"); }
#endif
  uint64_t address{0};
  bool connected{false};
  uint32_t mtu{0};
  int32_t error{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class BluetoothGATTGetServicesRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 70;
  static constexpr uint8_t ESTIMATED_SIZE = 4;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("bluetooth_gatt_get_services_request"); }
#endif
  uint64_t address{0};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class BluetoothGATTDescriptor final : public ProtoMessage {
 public:
  std::array<uint64_t, 2> uuid{};
  uint32_t handle{0};
  uint32_t short_uuid{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class BluetoothGATTCharacteristic final : public ProtoMessage {
 public:
  std::array<uint64_t, 2> uuid{};
  uint32_t handle{0};
  uint32_t properties{0};
  FixedVector<BluetoothGATTDescriptor> descriptors{};
  uint32_t short_uuid{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class BluetoothGATTService final : public ProtoMessage {
 public:
  std::array<uint64_t, 2> uuid{};
  uint32_t handle{0};
  FixedVector<BluetoothGATTCharacteristic> characteristics{};
  uint32_t short_uuid{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class BluetoothGATTGetServicesResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 71;
  static constexpr uint8_t ESTIMATED_SIZE = 38;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("bluetooth_gatt_get_services_response"); }
#endif
  uint64_t address{0};
  std::vector<BluetoothGATTService> services{};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class BluetoothGATTGetServicesDoneResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 72;
  static constexpr uint8_t ESTIMATED_SIZE = 4;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("bluetooth_gatt_get_services_done_response"); }
#endif
  uint64_t address{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class BluetoothGATTReadRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 73;
  static constexpr uint8_t ESTIMATED_SIZE = 8;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("bluetooth_gatt_read_request"); }
#endif
  uint64_t address{0};
  uint32_t handle{0};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class BluetoothGATTReadResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 74;
  static constexpr uint8_t ESTIMATED_SIZE = 27;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("bluetooth_gatt_read_response"); }
#endif
  uint64_t address{0};
  uint32_t handle{0};
  const uint8_t *data_ptr_{nullptr};
  size_t data_len_{0};
  void set_data(const uint8_t *data, size_t len) {
    this->data_ptr_ = data;
    this->data_len_ = len;
  }
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class BluetoothGATTWriteRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 75;
  static constexpr uint8_t ESTIMATED_SIZE = 29;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("bluetooth_gatt_write_request"); }
#endif
  uint64_t address{0};
  uint32_t handle{0};
  bool response{false};
  const uint8_t *data{nullptr};
  uint16_t data_len{0};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class BluetoothGATTReadDescriptorRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 76;
  static constexpr uint8_t ESTIMATED_SIZE = 8;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("bluetooth_gatt_read_descriptor_request"); }
#endif
  uint64_t address{0};
  uint32_t handle{0};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class BluetoothGATTWriteDescriptorRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 77;
  static constexpr uint8_t ESTIMATED_SIZE = 27;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("bluetooth_gatt_write_descriptor_request"); }
#endif
  uint64_t address{0};
  uint32_t handle{0};
  const uint8_t *data{nullptr};
  uint16_t data_len{0};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class BluetoothGATTNotifyRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 78;
  static constexpr uint8_t ESTIMATED_SIZE = 10;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("bluetooth_gatt_notify_request"); }
#endif
  uint64_t address{0};
  uint32_t handle{0};
  bool enable{false};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class BluetoothGATTNotifyDataResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 79;
  static constexpr uint8_t ESTIMATED_SIZE = 27;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("bluetooth_gatt_notify_data_response"); }
#endif
  uint64_t address{0};
  uint32_t handle{0};
  const uint8_t *data_ptr_{nullptr};
  size_t data_len_{0};
  void set_data(const uint8_t *data, size_t len) {
    this->data_ptr_ = data;
    this->data_len_ = len;
  }
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class BluetoothConnectionsFreeResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 81;
  static constexpr uint8_t ESTIMATED_SIZE = 20;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("bluetooth_connections_free_response"); }
#endif
  uint32_t free{0};
  uint32_t limit{0};
  std::array<uint64_t, BLUETOOTH_PROXY_MAX_CONNECTIONS> allocated{};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class BluetoothGATTErrorResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 82;
  static constexpr uint8_t ESTIMATED_SIZE = 12;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("bluetooth_gatt_error_response"); }
#endif
  uint64_t address{0};
  uint32_t handle{0};
  int32_t error{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class BluetoothGATTWriteResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 83;
  static constexpr uint8_t ESTIMATED_SIZE = 8;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("bluetooth_gatt_write_response"); }
#endif
  uint64_t address{0};
  uint32_t handle{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class BluetoothGATTNotifyResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 84;
  static constexpr uint8_t ESTIMATED_SIZE = 8;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("bluetooth_gatt_notify_response"); }
#endif
  uint64_t address{0};
  uint32_t handle{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class BluetoothDevicePairingResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 85;
  static constexpr uint8_t ESTIMATED_SIZE = 10;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("bluetooth_device_pairing_response"); }
#endif
  uint64_t address{0};
  bool paired{false};
  int32_t error{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class BluetoothDeviceUnpairingResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 86;
  static constexpr uint8_t ESTIMATED_SIZE = 10;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("bluetooth_device_unpairing_response"); }
#endif
  uint64_t address{0};
  bool success{false};
  int32_t error{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class BluetoothDeviceClearCacheResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 88;
  static constexpr uint8_t ESTIMATED_SIZE = 10;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("bluetooth_device_clear_cache_response"); }
#endif
  uint64_t address{0};
  bool success{false};
  int32_t error{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#endif
#ifdef USE_BLUETOOTH_PROXY
class BluetoothScannerStateResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 126;
  static constexpr uint8_t ESTIMATED_SIZE = 6;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("bluetooth_scanner_state_response"); }
#endif
  enums::BluetoothScannerState state{};
  enums::BluetoothScannerMode mode{};
  enums::BluetoothScannerMode configured_mode{};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class BluetoothScannerSetModeRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 127;
  static constexpr uint8_t ESTIMATED_SIZE = 2;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("bluetooth_scanner_set_mode_request"); }
#endif
  enums::BluetoothScannerMode mode{};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#endif
#ifdef USE_VOICE_ASSISTANT
class SubscribeVoiceAssistantRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 89;
  static constexpr uint8_t ESTIMATED_SIZE = 6;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("subscribe_voice_assistant_request"); }
#endif
  bool subscribe{false};
  uint32_t flags{0};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class VoiceAssistantAudioSettings final : public ProtoMessage {
 public:
  uint32_t noise_suppression_level{0};
  uint32_t auto_gain{0};
  float volume_multiplier{0.0f};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class VoiceAssistantRequest final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 90;
  static constexpr uint8_t ESTIMATED_SIZE = 41;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("voice_assistant_request"); }
#endif
  bool start{false};
  StringRef conversation_id{nullptr, 0};  // null until set, encode only
  uint32_t flags{0};
  VoiceAssistantAudioSettings audio_settings{};
  StringRef wake_word_phrase{nullptr, 0};  // null until set, encode only
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class VoiceAssistantResponse final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 91;
  static constexpr uint8_t ESTIMATED_SIZE = 6;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("voice_assistant_response"); }
#endif
  uint32_t port{0};
  bool error{false};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class VoiceAssistantEventData final : public ProtoDecodableMessage {
 public:
  StringRef name{};
  StringRef value{};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class VoiceAssistantEventResponse final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 92;
  static constexpr uint8_t ESTIMATED_SIZE = 36;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("voice_assistant_event_response"); }
#endif
  enums::VoiceAssistantEvent event_type{};
  std::vector<VoiceAssistantEventData> data{};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class VoiceAssistantAudio final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 106;
  static constexpr uint8_t ESTIMATED_SIZE = 40;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("voice_assistant_audio"); }
#endif
  const uint8_t *data{nullptr};
  uint16_t data_len{0};
  bool end{false};
  const uint8_t *data2{nullptr};
  uint16_t data2_len{0};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class VoiceAssistantTimerEventResponse final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 115;
  static constexpr uint8_t ESTIMATED_SIZE = 30;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("voice_assistant_timer_event_response"); }
#endif
  enums::VoiceAssistantTimerEvent event_type{};
  StringRef timer_id{};
  StringRef name{};
  uint32_t total_seconds{0};
  uint32_t seconds_left{0};
  bool is_active{false};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class VoiceAssistantAnnounceRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 119;
  static constexpr uint8_t ESTIMATED_SIZE = 29;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("voice_assistant_announce_request"); }
#endif
  StringRef media_id{};
  StringRef text{};
  StringRef preannounce_media_id{};
  bool start_conversation{false};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class VoiceAssistantAnnounceFinished final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 120;
  static constexpr uint8_t ESTIMATED_SIZE = 2;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("voice_assistant_announce_finished"); }
#endif
  bool success{false};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class VoiceAssistantWakeWord final : public ProtoMessage {
 public:
  StringRef id{nullptr, 0};         // null until set, encode only
  StringRef wake_word{nullptr, 0};  // null until set, encode only
  std::vector<std::string> trained_languages{};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class VoiceAssistantExternalWakeWord final : public ProtoDecodableMessage {
 public:
  StringRef id{};
  StringRef wake_word{};
  std::vector<std::string> trained_languages{};
  StringRef model_type{};
  uint32_t model_size{0};
  StringRef model_hash{};
  StringRef url{};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class VoiceAssistantConfigurationRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 121;
  static constexpr uint8_t ESTIMATED_SIZE = 34;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("voice_assistant_configuration_request"); }
#endif
  std::vector<VoiceAssistantExternalWakeWord> external_wake_words{};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class VoiceAssistantConfigurationResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 122;
  static constexpr uint8_t ESTIMATED_SIZE = 56;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("voice_assistant_configuration_response"); }
#endif
  std::vector<VoiceAssistantWakeWord> available_wake_words{};
  const std::vector<std::string> *active_wake_words{};
  uint32_t max_active_wake_words{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class VoiceAssistantSetConfiguration final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 123;
  static constexpr uint8_t ESTIMATED_SIZE = 18;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("voice_assistant_set_configuration"); }
#endif
  std::vector<std::string> active_wake_words{};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#endif
#ifdef USE_ALARM_CONTROL_PANEL
class ListEntitiesAlarmControlPanelResponse final : public InfoResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 94;
  static constexpr uint8_t ESTIMATED_SIZE = 48;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_alarm_control_panel_response"); }
#endif
  uint32_t supported_features{0};
  bool requires_code{false};
  bool requires_code_to_arm{false};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class AlarmControlPanelStateResponse final : public StateResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 95;
  static constexpr uint8_t ESTIMATED_SIZE = 11;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("alarm_control_panel_state_response"); }
#endif
  enums::AlarmControlPanelState state{};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class AlarmControlPanelCommandRequest final : public CommandProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 96;
  static constexpr uint8_t ESTIMATED_SIZE = 20;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("alarm_control_panel_command_request"); }
#endif
  enums::AlarmControlPanelStateCommand command{};
  StringRef code{};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#endif
#ifdef USE_TEXT
class ListEntitiesTextResponse final : public InfoResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 97;
  static constexpr uint8_t ESTIMATED_SIZE = 59;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_text_response"); }
#endif
  uint32_t min_length{0};
  uint32_t max_length{0};
  StringRef pattern{nullptr, 0};  // null until set, encode only
  enums::TextMode mode{};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class TextStateResponse final : public StateResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 98;
  static constexpr uint8_t ESTIMATED_SIZE = 20;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("text_state_response"); }
#endif
  StringRef state{nullptr, 0};  // null until set, encode only
  bool missing_state{false};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class TextCommandRequest final : public CommandProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 99;
  static constexpr uint8_t ESTIMATED_SIZE = 18;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("text_command_request"); }
#endif
  StringRef state{};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#endif
#ifdef USE_DATETIME_DATE
class ListEntitiesDateResponse final : public InfoResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 100;
  static constexpr uint8_t ESTIMATED_SIZE = 40;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_date_response"); }
#endif
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class DateStateResponse final : public StateResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 101;
  static constexpr uint8_t ESTIMATED_SIZE = 23;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("date_state_response"); }
#endif
  bool missing_state{false};
  uint32_t year{0};
  uint32_t month{0};
  uint32_t day{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class DateCommandRequest final : public CommandProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 102;
  static constexpr uint8_t ESTIMATED_SIZE = 21;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("date_command_request"); }
#endif
  uint32_t year{0};
  uint32_t month{0};
  uint32_t day{0};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#endif
#ifdef USE_DATETIME_TIME
class ListEntitiesTimeResponse final : public InfoResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 103;
  static constexpr uint8_t ESTIMATED_SIZE = 40;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_time_response"); }
#endif
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class TimeStateResponse final : public StateResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 104;
  static constexpr uint8_t ESTIMATED_SIZE = 23;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("time_state_response"); }
#endif
  bool missing_state{false};
  uint32_t hour{0};
  uint32_t minute{0};
  uint32_t second{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class TimeCommandRequest final : public CommandProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 105;
  static constexpr uint8_t ESTIMATED_SIZE = 21;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("time_command_request"); }
#endif
  uint32_t hour{0};
  uint32_t minute{0};
  uint32_t second{0};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#endif
#ifdef USE_EVENT
class ListEntitiesEventResponse final : public InfoResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 107;
  static constexpr uint8_t ESTIMATED_SIZE = 67;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_event_response"); }
#endif
  StringRef device_class{nullptr, 0};  // null until set, encode only
  const FixedVector<const char *> *event_types{};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class EventResponse final : public StateResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 108;
  static constexpr uint8_t ESTIMATED_SIZE = 18;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("event_response"); }
#endif
  StringRef event_type{nullptr, 0};  // null until set, encode only
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#endif
#ifdef USE_VALVE
class ListEntitiesValveResponse final : public InfoResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 109;
  static constexpr uint8_t ESTIMATED_SIZE = 55;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_valve_response"); }
#endif
  StringRef device_class{nullptr, 0};  // null until set, encode only
  bool assumed_state{false};
  bool supports_position{false};
  bool supports_stop{false};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class ValveStateResponse final : public StateResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 110;
  static constexpr uint8_t ESTIMATED_SIZE = 16;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("valve_state_response"); }
#endif
  float position{0.0f};
  enums::ValveOperation current_operation{};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class ValveCommandRequest final : public CommandProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 111;
  static constexpr uint8_t ESTIMATED_SIZE = 18;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("valve_command_request"); }
#endif
  bool has_position{false};
  float position{0.0f};
  bool stop{false};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#endif
#ifdef USE_DATETIME_DATETIME
class ListEntitiesDateTimeResponse final : public InfoResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 112;
  static constexpr uint8_t ESTIMATED_SIZE = 40;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_date_time_response"); }
#endif
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class DateTimeStateResponse final : public StateResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 113;
  static constexpr uint8_t ESTIMATED_SIZE = 16;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("date_time_state_response"); }
#endif
  bool missing_state{false};
  uint32_t epoch_seconds{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class DateTimeCommandRequest final : public CommandProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 114;
  static constexpr uint8_t ESTIMATED_SIZE = 14;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("date_time_command_request"); }
#endif
  uint32_t epoch_seconds{0};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#endif
#ifdef USE_UPDATE
class ListEntitiesUpdateResponse final : public InfoResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 116;
  static constexpr uint8_t ESTIMATED_SIZE = 49;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_update_response"); }
#endif
  StringRef device_class{nullptr, 0};  // null until set, encode only
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class UpdateStateResponse final : public StateResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 117;
  static constexpr uint8_t ESTIMATED_SIZE = 65;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("update_state_response"); }
#endif
  bool missing_state{false};
  bool in_progress{false};
  bool has_progress{false};
  float progress{0.0f};
  StringRef current_version{nullptr, 0};  // null until set, encode only
  StringRef latest_version{nullptr, 0};   // null until set, encode only
  StringRef title{nullptr, 0};            // null until set, encode only
  StringRef release_summary{nullptr, 0};  // null until set, encode only
  StringRef release_url{nullptr, 0};      // null until set, encode only
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class UpdateCommandRequest final : public CommandProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 118;
  static constexpr uint8_t ESTIMATED_SIZE = 11;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("update_command_request"); }
#endif
  enums::UpdateCommand command{};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
#endif
#ifdef USE_ZWAVE_PROXY
class ZWaveProxyFrame final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 128;
  static constexpr uint8_t ESTIMATED_SIZE = 19;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("z_wave_proxy_frame"); }
#endif
  const uint8_t *data{nullptr};
  uint16_t data_len{0};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class ZWaveProxyRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 129;
  static constexpr uint8_t ESTIMATED_SIZE = 21;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("z_wave_proxy_request"); }
#endif
  enums::ZWaveProxyRequestType type{};
  const uint8_t *data{nullptr};
  uint16_t data_len{0};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class ZWaveProxyRequestResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 151;
  static constexpr uint8_t ESTIMATED_SIZE = 4;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("z_wave_proxy_request_response"); }
#endif
  enums::ZWaveProxyRequestType type{};
  enums::ZWaveProxyStatus status{};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#endif
#ifdef USE_INFRARED
class ListEntitiesInfraredResponse final : public InfoResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 135;
  static constexpr uint8_t ESTIMATED_SIZE = 48;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_infrared_response"); }
#endif
  uint32_t capabilities{0};
  uint32_t receiver_frequency{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#endif
#ifdef USE_IR_RF
class InfraredRFTransmitRawTimingsRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 136;
  static constexpr uint8_t ESTIMATED_SIZE = 224;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("infrared_rf_transmit_raw_timings_request"); }
#endif
#ifdef USE_DEVICES
  uint32_t device_id{0};
#endif
  uint32_t key{0};
  uint32_t carrier_frequency{0};
  uint32_t repeat_count{0};
  const uint8_t *timings_data_{nullptr};
  uint16_t timings_length_{0};
  uint16_t timings_count_{0};
  uint32_t modulation{0};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class InfraredRFReceiveEvent final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 137;
  static constexpr uint8_t ESTIMATED_SIZE = 17;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("infrared_rf_receive_event"); }
#endif
#ifdef USE_DEVICES
  uint32_t device_id{0};
#endif
  uint32_t key{0};
  const std::vector<int32_t> *timings{};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class InfraredRFTransmitCompleteResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 153;
  static constexpr uint8_t ESTIMATED_SIZE = 11;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("infrared_rf_transmit_complete_response"); }
#endif
#ifdef USE_DEVICES
  uint32_t device_id{0};
#endif
  uint32_t key{0};
  bool success{false};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#endif
#ifdef USE_RADIO_FREQUENCY
class ListEntitiesRadioFrequencyResponse final : public InfoResponseProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 148;
  static constexpr uint8_t ESTIMATED_SIZE = 56;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("list_entities_radio_frequency_response"); }
#endif
  uint32_t capabilities{0};
  uint32_t frequency_min{0};
  uint32_t frequency_max{0};
  uint32_t supported_modulations{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#endif
#ifdef USE_SERIAL_PROXY
class SerialProxyConfigureRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 138;
  static constexpr uint8_t ESTIMATED_SIZE = 20;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("serial_proxy_configure_request"); }
#endif
  uint32_t instance{0};
  uint32_t baudrate{0};
  bool flow_control{false};
  enums::SerialProxyParity parity{};
  uint32_t stop_bits{0};
  uint32_t data_size{0};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class SerialProxyDataReceived final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 139;
  static constexpr uint8_t ESTIMATED_SIZE = 23;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("serial_proxy_data_received"); }
#endif
  uint32_t instance{0};
  const uint8_t *data_ptr_{nullptr};
  size_t data_len_{0};
  void set_data(const uint8_t *data, size_t len) {
    this->data_ptr_ = data;
    this->data_len_ = len;
  }
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class SerialProxyWriteRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 140;
  static constexpr uint8_t ESTIMATED_SIZE = 23;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("serial_proxy_write_request"); }
#endif
  uint32_t instance{0};
  const uint8_t *data{nullptr};
  uint16_t data_len{0};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class SerialProxySetModemPinsRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 141;
  static constexpr uint8_t ESTIMATED_SIZE = 8;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("serial_proxy_set_modem_pins_request"); }
#endif
  uint32_t instance{0};
  uint32_t line_states{0};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class SerialProxyGetModemPinsRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 142;
  static constexpr uint8_t ESTIMATED_SIZE = 4;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("serial_proxy_get_modem_pins_request"); }
#endif
  uint32_t instance{0};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class SerialProxyGetModemPinsResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 143;
  static constexpr uint8_t ESTIMATED_SIZE = 10;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("serial_proxy_get_modem_pins_response"); }
#endif
  uint32_t instance{0};
  uint32_t line_states{0};
  enums::SerialProxyStatus status{};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class SerialProxyRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 144;
  static constexpr uint8_t ESTIMATED_SIZE = 6;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("serial_proxy_request"); }
#endif
  uint32_t instance{0};
  enums::SerialProxyRequestType type{};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class SerialProxyRequestResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 147;
  static constexpr uint8_t ESTIMATED_SIZE = 17;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("serial_proxy_request_response"); }
#endif
  uint32_t instance{0};
  enums::SerialProxyRequestType type{};
  enums::SerialProxyStatus status{};
  StringRef error_message{nullptr, 0};  // null until set, encode only
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class SerialProxySetModeRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 152;
  static constexpr uint8_t ESTIMATED_SIZE = 6;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("serial_proxy_set_mode_request"); }
#endif
  uint32_t instance{0};
  enums::SerialProxyMode mode{};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class UsbDeviceDescriptor final : public ProtoMessage {
 public:
  uint32_t vendor_id{0};
  uint32_t product_id{0};
  uint32_t bcd_device{0};
  uint32_t interface_number{0};
  uint32_t interface_class{0};
  uint32_t port_number{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
class SerialProxyIdentity final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 155;
  static constexpr uint8_t ESTIMATED_SIZE = 54;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("serial_proxy_identity"); }
#endif
  uint32_t instance{0};
  enums::SerialProxyIdentitySource source{};
  uint32_t flags{0};
  StringRef manufacturer{nullptr, 0};   // null until set, encode only
  StringRef product{nullptr, 0};        // null until set, encode only
  StringRef serial_number{nullptr, 0};  // null until set, encode only
  UsbDeviceDescriptor usb{};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#endif
#ifdef USE_BLUETOOTH_PROXY_CONNECTIONS
class BluetoothSetConnectionParamsRequest final : public ProtoDecodableMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 145;
  static constexpr uint8_t ESTIMATED_SIZE = 20;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("bluetooth_set_connection_params_request"); }
#endif
  uint64_t address{0};
  uint32_t min_interval{0};
  uint32_t max_interval{0};
  uint32_t latency{0};
  uint32_t timeout{0};
  void decode(const uint8_t *buffer, size_t length) {
    ProtoDecodableMessage::decode_fields(this, buffer, length, &decode_field);
  }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
  static void decode_field(void *self, uint32_t tag, const uint8_t *data, proto_varint_value_t scalar);
};
class BluetoothSetConnectionParamsResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 146;
  static constexpr uint8_t ESTIMATED_SIZE = 8;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("bluetooth_set_connection_params_response"); }
#endif
  uint64_t address{0};
  int32_t error{0};
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#endif
#ifdef USE_SENDSPIN
class SendspinPairingTokenResponse final : public ProtoMessage {
 public:
  static constexpr uint16_t MESSAGE_TYPE = 160;
  static constexpr uint8_t ESTIMATED_SIZE = 11;
#ifdef HAS_PROTO_MESSAGE_DUMP
  const LogString *message_name() const override { return LOG_STR("sendspin_pairing_token_response"); }
#endif
  enums::SendspinPairingTokenStatus status{};
  StringRef token{nullptr, 0};  // null until set, encode only
  static uint8_t *encode_msg(const void *self, uint8_t *pos PROTO_ENCODE_DEBUG_PARAM);
  uint8_t *encode(ProtoWriteBuffer &buffer PROTO_ENCODE_DEBUG_PARAM) const {
    return encode_msg(this, buffer.get_pos() PROTO_ENCODE_DEBUG_ARG);
  }
  static uint32_t calc_size_msg(const void *self);
  uint32_t calculate_size() const { return calc_size_msg(this); }
#ifdef HAS_PROTO_MESSAGE_DUMP
  const char *dump_to(DumpBuffer &out) const override;
#endif

 protected:
};
#endif

}  // namespace esphome::api
