#pragma once
#include "esphome/core/defines.h"
#ifdef USE_NETWORK
#include <span>
#include <string>
#include "esphome/core/helpers.h"
#include "ip_address.h"

#ifdef USE_ETHERNET
#include "esphome/components/ethernet/ethernet_component.h"
#endif
#ifdef USE_MODEM
#include "esphome/components/modem/modem_component.h"
#endif
#ifdef USE_WIFI
#include "esphome/components/wifi/wifi_component.h"
#endif
#ifdef USE_OPENTHREAD
#include "esphome/components/openthread/openthread.h"
#endif

namespace esphome::network {

// The order of the components is important: WiFi should come after any possible main interfaces (it may be used as
// an AP that uses a previous interface for NAT).

/// Return whether the node is connected to the network (through wifi, eth, ...)
ESPHOME_ALWAYS_INLINE inline bool is_connected() {
  // With a single interface enabled the checks below collapse to `if (x) return true; return false;`, which
  // clang-tidy wants folded into one return. Keep the per-interface form so every enabled interface is checked.
  // NOLINTBEGIN(readability-simplify-boolean-expr)
#ifdef USE_ETHERNET
  if (ethernet::global_eth_component != nullptr && ethernet::global_eth_component->is_connected())
    return true;
#endif

#ifdef USE_MODEM
  if (modem::global_modem_component != nullptr && modem::global_modem_component->is_connected())
    return true;
#endif

#ifdef USE_WIFI
  if (wifi::global_wifi_component != nullptr && wifi::global_wifi_component->is_connected())
    return true;
#endif

#ifdef USE_OPENTHREAD
  if (openthread::global_openthread_component != nullptr && openthread::global_openthread_component->is_connected())
    return true;
#endif

#ifdef USE_HOST
  return true;  // Assume it's connected
#endif
  return false;
  // NOLINTEND(readability-simplify-boolean-expr)
}

/// Return whether the network is disabled: every configured interface with a
/// disable() lifecycle (modem, wifi, ethernet) is disabled.
bool is_disabled();
/// Buffer size for get_use_address_to(): 63-char DNS label + ".local" + null terminator
static constexpr size_t USE_ADDRESS_BUFFER_SIZE = 70;
/// Get the active network address for logging. Returns the explicitly configured
/// use_address when one was set (from the highest-priority interface when
/// network: priority: is configured), otherwise formats "<name>.local" from the runtime
/// device name into buf (so it includes the MAC suffix from name_add_mac_suffix).
const char *get_use_address_to(std::span<char, USE_ADDRESS_BUFFER_SIZE> buf);
IPAddresses get_ip_addresses();

}  // namespace esphome::network
#endif
