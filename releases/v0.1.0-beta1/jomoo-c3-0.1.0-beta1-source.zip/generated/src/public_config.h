#pragma once
#include <string>
#include <cstdint>
namespace sq9650 {
constexpr bool parse_mac_bytes(const char *s,size_t size,uint64_t &out){
 if(size!=17)return false;
 uint64_t value=0;
 for(size_t i=0;i<17;++i){
  if(i%3==2){if(s[i]!=':')return false;continue;}
  char c=s[i];int n=c>='0'&&c<='9'?c-'0':c>='a'&&c<='f'?c-'a'+10:c>='A'&&c<='F'?c-'A'+10:-1;
  if(n<0)return false;
  value=(value<<4)|n;
 }
 if(value==0 || value==0xffffffffffffULL || ((value>>40)&1))return false;
 out=value;return true;
}
inline bool parse_mac(const std::string &s,uint64_t &out){return parse_mac_bytes(s.data(),s.size(),out);}
}
