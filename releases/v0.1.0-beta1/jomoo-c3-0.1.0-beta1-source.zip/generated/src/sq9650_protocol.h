#pragma once
#include <cstdint>
#include <cstddef>
namespace sq9650 {
struct Frame { uint8_t data[128]{}; size_t size{0}; };
constexpr bool valid(const Frame &f) {
  if (f.size<8 || f.size>128 || f.data[0]!=0xFC || f.data[f.size-1]!=0xFC) return false;
  uint8_t sum=0;
  for (size_t i=2;i+1<f.size;++i) sum+=f.data[i];
  return sum==f.data[1];
}
// No allocation; maximum decoded frame 128 bytes. Notification boundaries are immaterial.
struct Parser {
  Frame frame{}, incoming{};
  bool escaped{false};
  constexpr void reset() { incoming.size=0; escaped=false; }
  constexpr bool feed(uint8_t b) {
    if (b==0xFC) {
      bool complete=false;
      if (!escaped && incoming.size>1 && incoming.size<128) {
        incoming.data[incoming.size++]=0xFC;
        if (valid(incoming)) { frame=incoming; complete=true; }
      }
      reset(); incoming.data[0]=0xFC; incoming.size=1;
      return complete;
    }
    if (!incoming.size) return false;
    if (escaped) {
      escaped=false;
      if (b==1) b=0xFC;
      else if (b==2) b=0xFD;
      else { reset(); return false; }
    } else if (b==0xFD) { escaped=true; return false; }
    if (incoming.size>=127) { reset(); return false; }
    incoming.data[incoming.size++]=b;
    return false;
  }
};
struct State {
  bool foot{false},night{false},light_sensor{false},occupied{false},ready{false};
  bool lid{false},ring{false},bubble{false};
  uint8_t work{0},motion{0},flush{0},seat{0};
};
constexpr bool response_address(const Frame &f) {
  return valid(f) && f.data[2]==0 && (f.data[3]==0xFF || f.data[3]==1) && f.data[4]==0 && f.data[5]==0;
}
constexpr bool decode_state(const Frame &f,State &s) {
  if (f.size!=26 || !response_address(f) || f.data[6]!=0x30) return false;
  s.work=f.data[7]&31; s.foot=f.data[11]&8; s.lid=f.data[11]&16;
  s.ring=f.data[11]&32; s.occupied=f.data[11]&128; s.flush=f.data[12]&3;
  s.motion=f.data[13]&3; s.ready=f.data[13]&128;
  s.night=f.data[16]&64; s.light_sensor=f.data[16]&128;
  s.seat=(f.data[17]>>3)&7; s.bubble=f.data[20]&32;
  return true;
}
constexpr bool supported(int cmd,int value,int index=-1) {
  if (index>=0) return (value==0 || value==1) && ((cmd==0x41 && index==0) || (cmd==0x40 && (index==2 || index==14)));
  switch(cmd) {
    case 0x11: case 1: return value==0;
    case 0x33: case 0x34: return value==0 || value==1;
    case 0x35: return value==1 || value==2;
    case 0x46: case 0x17: return value==1;
    case 0x3C: return value==0 || value==3 || value==5;
    default:return false;
  }
}
constexpr Frame command(int cmd,int value,int index=-1) {
  Frame f{};
  if (!supported(cmd,value,index)) return f;
  f.size=index<0?9:10;
  f.data[0]=0xFC; f.data[2]=1; f.data[6]=static_cast<uint8_t>(cmd);
  f.data[7]=static_cast<uint8_t>(index<0?value:index);
  if (index>=0) f.data[8]=static_cast<uint8_t>(value);
  f.data[f.size-1]=0xFC;
  for (size_t i=2;i+1<f.size;++i) f.data[1]+=f.data[i];
  return f;
}
constexpr bool query(int cmd) { return cmd==1 || cmd==0x11; }
struct Controller {
  Parser parser{};
  State state{};
  bool connected{false},have_state{false};
  uint32_t state_at{0},last_action{0},hold_ms{0},rx_at{0},state_sequence{0};
  constexpr bool fresh(uint32_t now) const { return connected && have_state && uint32_t(now-state_at)<15000; }
  constexpr void disconnect() { connected=false;have_state=false;parser.reset(); }
  constexpr void connect() { connected=true;have_state=false;parser.reset(); }
  constexpr bool ingest(uint8_t b,uint32_t now) {
    if (uint32_t(now-rx_at)>2000) parser.reset();
    rx_at=now;
    if (!parser.feed(b)) return false;
    State next{};
    if (decode_state(parser.frame,next)) { state=next;have_state=true;state_at=now;++state_sequence; }
    return true;
  }
  constexpr const char *reject(int cmd,int value,int index,uint32_t now) const {
    if (!supported(cmd,value,index)) return "unsupported_command";
    if (!connected) return "ble_offline";
    if (query(cmd)) return nullptr;
    if (!fresh(now)) return "state_stale";
    if (uint32_t(now-last_action)<hold_ms) return "cooldown";
    if (state.work!=2 || state.motion || state.flush || state.bubble) return "device_busy";
    if (state.occupied) return "occupied";
    if (cmd==0x34 && value==1 && !state.lid) return "open_lid_first";
    if (((cmd==0x33 && value==0) || cmd==0x35) && state.ring) return "lower_ring_first";
    if ((cmd==0x35 || cmd==0x46) && !state.ready) return "water_not_ready";
    return nullptr;
  }
  constexpr void sent(int cmd,uint32_t now) {
    if (query(cmd)) return;
    last_action=now;
    hold_ms=cmd==0x35?45000:cmd==0x46?20000:(cmd==0x33 || cmd==0x34)?5000:1000;
  }
  constexpr bool matches(int cmd,int value,int index) const {
    switch(cmd) {
      case 0x33:return state.lid==bool(value) && !(state.motion&2);
      case 0x34:return state.ring==bool(value) && !(state.motion&1);
      case 0x35:return state.flush==value;
      case 0x46:return state.bubble;
      case 0x17:return state.work==1;
      case 0x3C:return state.seat==value;
      case 0x41:return index==0 && state.night==bool(value);
      case 0x40:return index==2?state.light_sensor==bool(value):index==14 && state.foot==bool(value);
      default:return false;
    }
  }
};
struct Version { char hardware[40]{};char firmware[64]{}; };
// RAM only: a reboot never restores a pending command or cached live state.
inline Controller bridge{};
constexpr bool decode_version(const Frame &f,Version &v) {
  if (f.size<11 || !response_address(f) || f.data[6]!=1) return false;
  size_t h=f.data[8];
  if (h>=sizeof(v.hardware) || 9+h>=f.size-1) return false;
  size_t n=f.data[9+h];
  if (n>=sizeof(v.firmware) || 10+h+n>f.size-1) return false;
  for(size_t i=0;i<h;++i) { if(f.data[9+i]<32 || f.data[9+i]>126)return false;v.hardware[i]=f.data[9+i]; }
  v.hardware[h]=0;
  for(size_t i=0;i<n;++i) { if(f.data[10+h+i]<32 || f.data[10+h+i]>126)return false;v.firmware[i]=f.data[10+h+i]; }
  v.firmware[n]=0;
  return true;
}
}
