#include "public_config.h"
constexpr bool valid(){uint64_t a=0;return sq9650::parse_mac_bytes("AA:BB:CC:DD:EE:FF",17,a)&&a==0xaabbccddeeffULL;}
constexpr bool invalid(){uint64_t a=0;return !sq9650::parse_mac_bytes("00:00:00:00:00:00",17,a)&&!sq9650::parse_mac_bytes("FF:FF:FF:FF:FF:FF",17,a)&&!sq9650::parse_mac_bytes("AB:BB:CC:DD:EE:FF",17,a)&&!sq9650::parse_mac_bytes("AA-BB-CC-DD-EE-FF",17,a)&&!sq9650::parse_mac_bytes("AA:BB:CC:DD:EE:GG",17,a)&&!sq9650::parse_mac_bytes("",0,a);}
static_assert(valid());static_assert(invalid());
