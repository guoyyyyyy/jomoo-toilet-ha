# Matching source for 0.1.0-beta1

Build: Python3.14, esphome2026.10.0, ESP-IDF5.5.6, ESP32-C3 4MB. Install esphome==2026.10.0 then run python -m esphome compile jomoo-public.yaml. No secrets.yaml is needed. Generated runtime sources and pinned dependencies are included for inspection; use config at archive root for normal rebuild. ESP-IDF source: https://github.com/espressif/esp-idf/tree/v5.5.6 . ESPHome source: https://github.com/esphome/esphome/tree/2026.10.0 . Managed dependency source and locks included. ESP-IDF and system toolchain are independently available SDK/build tools. Runtime and integrated bridge modifications are provided under GPLv3; see LICENSE-ESPHome.txt. Third-party files retain their own notices.

Provision on trusted LAN only. API and local web UI have no authentication/encryption. No home credentials or default target address are included. This release is not hardware-tested.
