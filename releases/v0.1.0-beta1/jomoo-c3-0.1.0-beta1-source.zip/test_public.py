from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'jomoo-public.yaml').read_text(encoding='utf8')
assert '!secret' not in s
assert 'A4:C1:38:2B:77:17' not in s
assert 'mac_address: 00:00:00:00:00:00' in s
assert 'id: target_mac' in s
assert 'sq9650::parse_mac' in s
assert 'captive_portal:' in s
assert '\nota:' not in s
assert '  ota: false' in s
print('PASS public privacy and configuration contracts')
